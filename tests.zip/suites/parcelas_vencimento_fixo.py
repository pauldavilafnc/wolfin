"""v7.12: vencimento fixo no parcelamento (dia do mês), exceção por parcela, um só calendário (pagamento). Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
BASE="""{owner:'T',opening:{c:100000,d:'2026-01-01'},items:[],inst:[{id:'n1',n:'Celular',c:null,np:3,day:5,paid:false},{id:'n2',n:'Sofá',c:null,np:2,day:null,paid:false}],parc:[
{id:'q1',iid:'n1',ym:'2026-06',c:20000,due:'2026-06-05',paid:true,paidOn:'2026-11-15'},
{id:'q2',iid:'n1',ym:'2026-07',c:20000,due:'2026-07-05',paid:false},
{id:'q3',iid:'n1',ym:'2026-08',c:20000,paid:false},
{id:'q4',iid:'n2',ym:'2026-09',c:10000,due:'2026-09-20',paid:false},
{id:'q5',iid:'n2',ym:'2026-10',c:10000,paid:false}],debts:[],boxes:[],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light',base=True):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'T')
        pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref()"%th)
        if base:pg.evaluate("S=migrate("+BASE+");save();render()")
        return c,pg
    q=lambda pg,i:pg.evaluate("(()=>{const p=S.parc.find(x=>x.id==='%s');return{paid:p.paid,paidOn:p.paidOn===undefined?null:p.paidOn,due:p.due===undefined?null:p.due,ym:p.ym}})()"%i)
    def save(pg):pg.click('#f .b1');pg.wait_for_timeout(250)
    # A. cadastro com vencimento fixo (dia 31) em meses de tamanhos diferentes, incl. bissexto
    c,pg=app(base=False)
    for fm,np_,exp in (('2027-01',4,['2027-01-31','2027-02-28','2027-03-31','2027-04-30']),('2028-01',3,['2028-01-31','2028-02-29','2028-03-31'])):
        pg.evaluate("instForm()");pg.wait_for_selector('#f')
        pg.fill('#f [name=n]','Teste '+fm);pg.fill('#f [name=day]','31');pg.fill('#f [name=np]',str(np_));pg.fill('#f [name=pc]','100,00');pg.fill('#f [name=fm]',fm);save(pg)
        d=pg.evaluate("S.parc.filter(p=>p.iid===S.inst[S.inst.length-1].id).sort((a,b)=>a.ym<b.ym?-1:1).map(p=>p.due)")
        ok(f'A. Dia 31 aplicado automaticamente a todos os meses a partir de {fm} (fev → último dia)',d==exp,d)
    pg.evaluate("instForm()");ok('A. Cadastro pede só o DIA do vencimento (campo numérico, sem calendário)',pg.evaluate("!!document.querySelector('#f [name=day]') && !document.querySelector('#f .calw')"))
    c.close()
    # B. tela de edição: um calendário só, ordem, valor calculado
    c,pg=app();pg.evaluate("ACT.edp('q1')");pg.wait_for_selector('#dueTxt')
    ok('B. Edição individual tem UM só calendário (o do pagamento) e nenhum campo de data completa de vencimento',pg.evaluate("document.querySelectorAll('#f .calw').length")==1 and pg.evaluate("document.querySelector('#f .calw').dataset.k")=='pd')
    ok('B. Mostra "Dia de vencimento: 05/06/2026" como informação',pg.inner_text('#dueTxt')=='Dia de vencimento: 05/06/2026',pg.inner_text('#dueTxt'))
    order=pg.evaluate("[...document.querySelectorAll('#f .lab, #f label, #f .dueinfo')].map(e=>e.textContent.trim().slice(0,12))")
    ok('B. Ordem: Mês, vencimento, pagamento, valor, status',[o[:5] for o in order][:5]==['Mês','Dia d','Data ','Valor','Statu'],order)
    ok('B. Pagamento continua editável (calendário completo com setas) e vem com a data guardada',pg.evaluate("document.querySelector('#f input[name=pd]').value")=='2026-11-15' and pg.locator('#pdw .calnv').count()==2)
    # exceção
    pg.evaluate("closeOv();ACT.edp('q2')");pg.wait_for_selector('#dueTxt')
    ok('B. Exceção escondida por padrão (discreta)',pg.evaluate("document.getElementById('dueSel').hidden"))
    pg.click('#dueBtn');pg.select_option('#dueSel select','10')
    ok('B. Escolher dia 10 mostra "10/07/2026 (exceção desta parcela)"','10/07/2026' in pg.inner_text('#dueTxt') and 'exceção' in pg.inner_text('#dueTxt'),pg.inner_text('#dueTxt'))
    save(pg);ok('C. Exceção grava só nessa parcela (q2=10/07); as demais ficam como estavam',q(pg,'q2')['due']=='2026-07-10' and q(pg,'q1')['due']=='2026-06-05' and q(pg,'q3')['due'] is None)
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#dueTxt');pg.click('#dueBtn');pg.select_option('#dueSel select','')
    ok('C. "Padrão do parcelamento" volta ao dia 05',pg.inner_text('#dueTxt')=='Dia de vencimento: 05/07/2026',pg.inner_text('#dueTxt'));save(pg)
    ok('C. Voltar ao padrão regrava 05/07 sem tocar nas outras',q(pg,'q2')['due']=='2026-07-05')
    # D. parcela antiga sem vencimento guardado: mostra calculado, não escreve ao salvar
    pg.evaluate("ACT.edp('q3')");pg.wait_for_selector('#dueTxt')
    ok('D. Parcela antiga sem vencimento guardado mostra o calculado (05/08/2026)',pg.inner_text('#dueTxt')=='Dia de vencimento: 05/08/2026')
    save(pg);ok('D. Salvar sem mexer não grava vencimento novo (dado antigo preservado)',q(pg,'q3')['due'] is None)
    # D2. vencimento individual antigo (dia 20 em parcelamento sem dia) preservado
    pg.evaluate("ACT.edp('q4')");pg.wait_for_selector('#dueTxt');t=pg.inner_text('#dueTxt');save(pg)
    ok('D. Vencimento individual antigo (20/09) preservado e exibido',t.startswith('Dia de vencimento: 20/09/2026') and q(pg,'q4')['due']=='2026-09-20',t)
    pg.evaluate("ACT.edp('q5')");pg.wait_for_selector('#dueTxt')
    ok('D. Parcelamento sem dia e parcela sem vencimento: "não definido", nada presumido',pg.inner_text('#dueTxt')=='Dia de vencimento: não definido');save(pg)
    ok('D. ...e continua sem vencimento depois de salvar',q(pg,'q5')['due'] is None)
    # E. trocar o mês recalcula
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#dueTxt');pg.fill('#f input[name=ym]','2026-09');pg.dispatch_event('#f input[name=ym]','change')
    ok('E. Trocar o mês da parcela recalcula o vencimento (05/09/2026)',pg.inner_text('#dueTxt')=='Dia de vencimento: 05/09/2026',pg.inner_text('#dueTxt'));save(pg)
    ok('E. Parcela movida para setembro com vencimento 05/09',q(pg,'q2')['ym']=='2026-09' and q(pg,'q2')['due']=='2026-09-05',q(pg,'q2'))
    c.close()
    # F. pagamento: antecipado, atrasado, editar antigo, pago↔pendente, mapa de calor
    c,pg=app()
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#pdw',state='attached');pg.select_option('#f select[name=paid]','1')
    for _ in range(4):pg.click('#pdw .calnv[data-nv="-1"]')
    pg.click('#pdw .cd[data-d="2026-07-04"]');save(pg);r=q(pg,'q2')
    ok('F. Pagamento antecipado (venc. 05/07, pago 04/07)',r['paidOn']=='2026-07-04' and r['due']=='2026-07-05',r)
    pg.evaluate("ACT.payp('q3')");pg.wait_for_selector('#f .calw')
    for _ in range(3):pg.click('#f .calnv[data-nv="-1"]')
    pg.click('#f .cd[data-d="2026-08-08"]');save(pg);r=q(pg,'q3')
    ok('F. Pagamento atrasado (venc. 05/08 calculado, pago 08/08); vencimento não foi gravado à força',r['paidOn']=='2026-08-08' and r['due'] is None,r)
    pg.evaluate("ACT.edp('q1')");pg.wait_for_selector('#pdw .calw')
    for _ in range(5):pg.click('#pdw .calnv[data-nv="-1"]')
    pg.click('#pdw .cd[data-d="2026-06-05"]');save(pg)
    ok('F. Pagamento antigo editado (15/11 → 05/06)',q(pg,'q1')['paidOn']=='2026-06-05')
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#f select[name=paid]');pg.select_option('#f select[name=paid]','0');save(pg)
    ok('F. Pago → Pendente limpa a data de pagamento e mantém o vencimento',q(pg,'q2')['paidOn'] is None and not q(pg,'q2')['paid'] and q(pg,'q2')['due']=='2026-07-05')
    pg.evaluate("(()=>{HMS.main.m='2026-08';HMS.main.sel=0;go('rel')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('F. Mapa de calor: R$ 200 no dia 8 de agosto (pagamento), nada no dia 5 (vencimento)',pg.inner_text('.hmw[data-hm=main] [data-d="8"] span')=='200' and pg.inner_text('.hmw[data-hm=main] [data-d="5"] span')=='')
    pg.evaluate("(()=>{HMS.main.m='2026-06';go('rel')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('F. Mapa de calor de junho: dia 5',pg.inner_text('.hmw[data-hm=main] [data-d="5"] span')=='200')
    t=pg.evaluate("({jun:relFlow('2026-06').exp,jul:relFlow('2026-07').exp,ago:relFlow('2026-08').exp,n:S.parc.length,it:S.items.length})")
    ok('F. Totais mensais e sem duplicação (jun 200, jul 0, ago 200; 5 parcelas; 0 despesas avulsas)',t==dict(jun=20000,jul=0,ago=20000,n=5,it=0),t)
    ok('F. Indicadores: parcelas pagas/pendentes coerentes',pg.evaluate("S.parc.filter(p=>p.paid).length")==2 and pg.evaluate("S.parc.filter(p=>!p.paid).length")==3)
    # G. mudar o dia do parcelamento: só pendentes sem exceção acompanham
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#dueBtn');pg.click('#dueBtn');pg.select_option('#dueSel select','12');save(pg)
    pg.evaluate("S.parc.push({id:'q6',iid:'n1',ym:'2026-12',c:20000,due:'2026-12-05',paid:false});save()")
    pg.evaluate("instForm('n1')");pg.wait_for_selector('#f [name=day]');pg.fill('#f [name=day]','10');save(pg)
    r=pg.evaluate("Object.fromEntries(S.parc.map(p=>[p.id,p.due||null]))")
    ok('G. Trocar o dia do parcelamento (05→10): pendente sem exceção acompanha; exceção (12/07), pagas e o que não tinha data ficam intactos',r['q6']=='2026-12-10' and r['q2']=='2026-07-12' and r['q1']=='2026-06-05' and r['q3'] is None,r)
    ok('Sem erros de JS',pg.errs==[],pg.errs);c.close()
    # H. temas e celulares
    for th in('light','dark'):
        for w,h in((360,740),(393,851),(768,1024)):
            c,pg=app(w,h,th);pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#dueTxt');pg.click('#dueBtn');pg.wait_for_timeout(200)
            m=pg.evaluate("""(()=>{const r=e=>e.getBoundingClientRect(),bt=r(document.getElementById('dueBtn')),sl=r(document.querySelector('#dueSel select')),sh=r(document.querySelector('#ov .sheet'));return{cal:document.querySelectorAll('#f .calw').length,bh:bt.height,sh:sl.height,ovx:document.documentElement.scrollWidth>innerWidth,inside:sh.left>=0&&sh.right<=innerWidth,txt:getComputedStyle(document.getElementById('dueTxt')).color,bg:getComputedStyle(document.querySelector('#ov .sheet')).backgroundColor}})()""")
            ok(f'H. {th} {w}px: um calendário, botão/lista ≥44px, sem rolagem lateral',m['cal']==1 and m['bh']>=43.5 and m['sh']>=43.5 and not m['ovx'] and m['inside'],m)
            c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
