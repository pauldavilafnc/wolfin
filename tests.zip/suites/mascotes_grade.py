"""Tela de escolha de mascotes (v7.5): grade, só nome e cargo, link "Já tem conta? Entrar", Continuar em destaque, sem gradiente preto embaixo.
Só dados fictícios; Chromium simulado (sem celular real)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
ROLES=['CEO','Rei','Magnata','Analista','Investidor','Negociador','Planejador','Poupadora','Hacker','Detetive']
NAMES=['Wolfin','Leônidas','Don Vito','Oráculo','Brutus','Mako','Bento','Penny','Nyx','Elliot']
ANIMAIS=['Lobo','Leão','Raposa','Coruja','Touro','Tubarão','Castor','Esquilo','Pantera','Guaxinim']
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th='light'):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        pg.goto(URL);pg.wait_for_selector('#mf');pg.evaluate(f"S.pref.theme='{th}';applyPref()");pg.wait_for_timeout(500);return c,pg
    # --- conteúdo ---
    c,pg=ctx()
    rows=pg.evaluate("[...document.querySelectorAll('#mf .mcrow')].map(r=>({n:r.querySelector('b').textContent,f:r.querySelector('small').textContent,img:!!r.querySelector('img'),t:r.innerText.replace('✓','').trim().split('\\n').map(x=>x.trim()).filter(Boolean)}))")
    ok('1. Os 10 cartões mostram somente nome e cargo (nenhum animal, descrição ou selo extra)',[r['n'] for r in rows]==NAMES and [r['f'] for r in rows]==ROLES and all(r['img'] and r['t']==[r['n'],r['f']] for r in rows),rows[:3])
    txt=pg.inner_text('#mf')+pg.inner_text('#mname')
    ok('1. Nenhum nome de animal nem frase de descrição na tela',not any(a in txt for a in ANIMAIS) and 'Inteligente' not in txt and 'Principal' not in txt,txt[:100])
    ok('1. Ajustes continua com a lista completa (animal e descrição) para trocar o mascote depois',pg.evaluate("(()=>{const h=mcRows('wolfin','data-act','mcpick');return h.includes('Lobo')&&h.includes('mcd')})()"))
    # --- grade ---
    for w,h in ((393,851),(360,640),(320,568),(1280,800)):
        c2,p2=ctx(w,h)
        g=p2.evaluate("(()=>{const r=[...document.querySelectorAll('#mf .mcrow')].map(x=>x.getBoundingClientRect());const cols=[...new Set(r.map(x=>Math.round(x.left)))].length;const ov=r.some((a,i)=>r.some((b,j)=>j>i&&a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1));const cut=[...document.querySelectorAll('#mf .mcrow b,#mf .mcrow small')].filter(e=>e.scrollWidth>e.clientWidth+1||e.getBoundingClientRect().right>e.closest('.mcrow').getBoundingClientRect().right-1||e.getBoundingClientRect().left<e.closest('.mcrow').getBoundingClientRect().left+1).length;const lines=Math.max(...[...document.querySelectorAll('#mf .mcrow b,#mf .mcrow small')].map(e=>Math.round(e.getBoundingClientRect().height/parseFloat(getComputedStyle(e).lineHeight))));return{cols,ov,cut,lines,sx:document.documentElement.scrollWidth>innerWidth+1,w:r[0].width}})()")
        ok(f'2. {w}x{h}: grade de 3 colunas, sem sobreposição, sem texto cortado nem quebrado e sem rolagem lateral',g['cols']==3 and not g['ov'] and g['cut']==0 and g['lines']==1 and not g['sx'],g);c2.close()
    # --- seleção ---
    pg.click('#mf .mcrow[data-id=nyx]');pg.wait_for_timeout(450)
    s=pg.evaluate("(()=>{const o=document.querySelector('#mf .mcrow.on'),ck=getComputedStyle(o.querySelector('.mcck'));return{id:o.dataset.id,n:document.querySelectorAll('#mf .mcrow.on').length,bw:getComputedStyle(o).borderTopWidth,ck:ck.opacity,ar:o.getAttribute('aria-checked'),mc:S.pref.mc,nm:document.getElementById('mname').innerText,go:document.getElementById('mgo').disabled}})()")
    ok('3. Selecionar destaca só um cartão (borda azul, ✓, aria-checked) e libera Continuar; o resumo mostra "Nome · cargo"',s['id']=='nyx' and s['n']==1 and s['bw']=='2px' and s['ck']=='1' and s['ar']=='true' and s['mc']=='nyx' and s['nm']=='Nyx · Hacker' and not s['go'],s)
    # --- todos acessíveis na rolagem ---
    res=[]
    for i,idn in enumerate(['wolfin','leonidas','vito','oraculo','brutus','mako','bento','penny','nyx','elliot']):
        pg.locator(f'#mf .mcrow >> nth={i}').scroll_into_view_if_needed();pg.wait_for_timeout(80)
        ids=pg.evaluate(f"(()=>{{const r=document.querySelectorAll('#mf .mcrow')[{i}],a=r.getBoundingClientRect(),g=document.getElementById('mgo').getBoundingClientRect();const top=document.elementFromPoint(a.left+a.width/2,a.top+6);return{{id:r.dataset.id,vis:a.top>=0&&a.bottom<=innerHeight,hit:r.contains(top)}}}})()")
        pg.locator(f'#mf .mcrow >> nth={i}').click();pg.wait_for_timeout(60)
        res.append((ids['id'],pg.evaluate("S.pref.mc")==ids['id']))
    ok('4. Todos os 10 personagens são alcançáveis pela rolagem e selecionáveis',len(res)==10 and all(x[1] for x in res),res)
    # --- Continuar ---
    pg.evaluate("document.getElementById('lock').scrollTo(0,0);window.scrollTo(0,0)");pg.wait_for_timeout(200)
    k=pg.evaluate("(()=>{const g=document.getElementById('mgo'),r=g.getBoundingClientRect(),cs=getComputedStyle(g);return{h:r.height,w:r.width,vis:r.top>=0&&r.bottom<=innerHeight,pos:cs.position,bgi:cs.backgroundImage.slice(0,60),fs:parseFloat(cs.fontSize)}})()")
    ok('5. Continuar: grande (≥ 52 px), azul principal, visível na parte inferior mesmo no topo da rolagem',k['h']>=52 and k['vis'] and k['pos']=='sticky' and 'gradient' in k['bgi'] and k['fs']>=16,k)
    pg.evaluate("document.getElementById('lock').scrollTo(0,99999);window.scrollTo(0,99999)");pg.wait_for_timeout(250)
    e=pg.evaluate("(()=>{const g=document.getElementById('mgo').getBoundingClientRect(),l=document.querySelector('[data-lk=enter]'),a=l.getBoundingClientRect(),cs=getComputedStyle(l),pc=getComputedStyle(l.parentElement);const last=document.querySelector('#mf .mcrow:last-child').getBoundingClientRect();return{semSobrep:a.top>=g.bottom-1&&g.top>=last.bottom-1,td:cs.textDecorationLine,bg:cs.backgroundColor,bw:cs.borderTopWidth,fs:parseFloat(pc.fontSize),pos:cs.position,par:l.parentElement.textContent.trim(),vis:a.bottom<=innerHeight&&a.top>=0,btnFs:parseFloat(getComputedStyle(document.getElementById('mgo')).fontSize)}})()")
    ok('6. No fim da rolagem: último cartão, Continuar e o link ficam em sequência, sem sobreposição e dentro da tela',e['semSobrep'] and e['vis'],e)
    ok('6. "Já tem conta? Entrar": texto pequeno, "Entrar" sublinhado, sem fundo/borda/botão e bem menor que o Continuar',e['par']=='Já tem conta? Entrar' and 'underline' in e['td'] and e['bg']=='rgba(0, 0, 0, 0)' and e['bw']=='0px' and e['pos']!='fixed' and e['fs']<=14 and e['btnFs']>e['fs'],e)
    nb=pg.evaluate("document.querySelectorAll('.obenter').length+[...document.querySelectorAll('#lock *')].filter(x=>getComputedStyle(x).position==='fixed'&&x.className!=='lkth'&&!x.classList.contains('lkth')).length")
    ok('7. Não existe mais o botão grande ENTRAR fixo embaixo, nem outro elemento fixo na tela',nb==0 and 'ENTRAR' not in pg.inner_text('#lock'),nb)
    gr=pg.evaluate("(()=>{const out=[];for(const e of document.querySelectorAll('#lock *')){for(const ps of [null,'::before','::after']){const cs=getComputedStyle(e,ps);if(cs.position==='fixed'&&cs.backgroundImage.includes('gradient')&&e.className!=='lkth')out.push(e.className)}}const L=getComputedStyle(document.getElementById('lock'),'::after');return{out,after:L.content}})()")
    ok('7. Sem camada/gradiente sobreposto na parte inferior',not gr['out'] and gr['after'] in('none','normal'),gr)
    # pixel: faixa inferior não é escura demais comparada ao fundo logo acima do cartão
    pg.screenshot(path=os.path.join(TMP,'mg_bot.png'))
    from PIL import Image
    im=Image.open(os.path.join(TMP,'mg_bot.png')).convert('RGB');W,H=im.size
    # amostra o fundo à esquerda do cartão (fora dele) em cima e embaixo: devem ser parecidos
    top=im.getpixel((6,int(H*.55)));bot=im.getpixel((6,H-8))
    lum=lambda c:.2126*c[0]+.7152*c[1]+.0722*c[2]
    ok('7. Fundo da parte inferior continua o mesmo do resto da tela (sem escurecer)',lum(bot)>=lum(top)*0.75-6,(top,bot))
    # --- link funciona ---
    pg.click('[data-lk=enter]');pg.wait_for_timeout(300)
    ok('8. Tocar em "Entrar" leva à tela de entrada (conta existente / importar backup)','Entrar na sua conta' in pg.inner_text('#lock') and pg.locator('[data-lk=pickbk]').count()==1)
    pg.click('[data-lk=backob]');pg.wait_for_selector('#mf');
    ok('8. Voltar retorna à escolha de mascotes com a seleção preservada',pg.evaluate("S.pref.mc")=='elliot' and pg.evaluate("document.querySelector('#mf .mcrow.on').dataset.id")=='elliot')
    pg.click('#mgo');pg.wait_for_selector('#cf')
    ok('9. Continuar leva à etapa 2 (aparência) e o resto do onboarding segue igual',pg.locator('.obdots[aria-label="Etapa 2 de 3"]').count()==1 and pg.locator('[data-lk=enter]').count()==1)
    ok('10. Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    # --- temas e celulares: contraste e visibilidade ---
    for th in ('light','dark'):
        for w,h in ((393,851),(360,640),(320,568),(851,393)):
            c2,p2=ctx(w,h,th)
            p2.wait_for_timeout(900);r=p2.evaluate("""(()=>{const g=document.getElementById('mgo');const a=g.getBoundingClientRect();return{vis:a.top>=0&&a.bottom<=innerHeight&&a.height>=48,sx:document.documentElement.scrollWidth>innerWidth+1,small:[...document.querySelectorAll('#lock button')].filter(x=>{const q=x.getBoundingClientRect();return q.width>0&&q.height<40&&!x.classList.contains('lkth')}).length}})()""")
            ok(f'11. {th} {w}x{h}: Continuar visível/funcional, alvos ≥ 40 px, sem rolagem lateral',r['vis'] and not r['sx'] and r['small']==0,r)
            p2.click('#mf .mcrow >> nth=1');p2.wait_for_timeout(100)
            ok(f'11. {th} {w}x{h}: selecionar e continuar funciona',p2.evaluate("S.pref.mc")=='leonidas' and not p2.locator('#mgo').is_disabled());c2.close()
    b.close()
print(sum(R),'/',len(R))
