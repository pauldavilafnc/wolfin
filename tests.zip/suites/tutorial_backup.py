"""Mini tutorial de backups (v7.4): 1ª visita às Configurações, sem repetição, botão "Como fazer backup?", 5 etapas ilustradas,
claro/escuro, celulares, offline e lógica de backup intacta. Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,io,json,statistics,tempfile
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
from PIL import Image
from contrast import lum,ratio,parse
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
PW="Senha-Forte-123"
TITULOS=['Seus dados merecem proteção.','Crie sua cópia de segurança.','Guarde em um lugar seguro.','Recupere seus dados quando precisar.','Backup feito, tranquilidade maior.']
EMOJI=re.compile('[\U0001F300-\U0001FAFF☀-➿⭐⭕️]')
TMP=tempfile.mkdtemp(prefix='bkt_')
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th=None,**k):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,accept_downloads=True,**k)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_BKT=1")
        pg=c.new_page();pg.errs=[];pg.logs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:(pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None,pg.logs.append(m.text)))
        return c,pg
    def conta(w=393,h=851,th=None,nome='Paul',**k):
        c,pg=ctx(w,h,**k);pg.goto(URL);OB_NOSEC(pg,nome);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(700)
        if th:pg.evaluate(f"S.pref.theme='{th}';save();render()")
        return c,pg
    nav=lambda pg,v:pg.click(f'#nav [data-id={v}]')
    flag=lambda pg:pg.evaluate("S.flags&&S.flags.bkt")
    aberto=lambda pg:pg.locator('#bkt').count()==1
    def passos(pg):
        r=[]
        for i in range(5):
            r.append(pg.inner_text('#bkt h3'))
            if i<4:pg.click('[data-bk=next]');pg.wait_for_timeout(120)
        return r
    # ---------- estático ----------
    html=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
    m=re.search(r"BUILD='([^']{3,90})'",html);mm=re.search(r"const KEY='wallstreet.v1',BUILD='([^']*)'",html)
    ok('Versão (BUILD) ≤ 90 caracteres (senão a verificação de atualização acusa "nova versão" sempre)',bool(m) and bool(mm) and m.group(1)==mm.group(1),mm and mm.group(1))
    ok('Nenhum recurso externo foi adicionado (ilustrações são SVG próprios, sem imagens/CDN)',not re.findall(r'<img[^>]+src="https?://',html) and 'class="bi"' in html)
    # ---------- 1. primeira visita ----------
    c,pg=conta()
    ok('Fora das Configurações o tutorial não aparece (Home, Receitas, Despesas, Dívidas, Caixinhas, Relatórios, Anotações)',all((nav(pg,v),pg.wait_for_timeout(150))[0] is None and not aberto(pg) for v in ('home','rec','des','div','cx','rel')))
    r=pg.evaluate("(()=>{go('cfg');const d=document.getElementById('bkt');return{aberto:!!d,dlg:d&&d.getAttribute('role')==='dialog'&&d.getAttribute('aria-modal')==='true',lab:d&&document.getElementById(d.getAttribute('aria-labelledby'))&&document.getElementById(d.getAttribute('aria-labelledby')).textContent,cobre:d&&d.getBoundingClientRect().width>=innerWidth&&d.getBoundingClientRect().height>=innerHeight}})()")
    ok('1. Na 1ª visita às Configurações o tutorial abre ANTES de mostrar a tela (no mesmo instante da navegação), como diálogo modal',r['aberto'] and r['dlg'] and r['cobre'] and r['lab'],r)
    pg.wait_for_timeout(500)
    ok('1. O foco vai para dentro do tutorial',pg.evaluate("document.getElementById('bkt').contains(document.activeElement)"))
    ok('1. Começa na etapa 1 de 5',pg.inner_text('#bkt .bkn2').strip().lower()=='etapa 1 de 5' and pg.inner_text('#bkt h3')==TITULOS[0])
    ok('1. Sem erros no console',not pg.errs,pg.errs[:3])
    c.close()
    # ---------- 2. fechar de 4 formas: registra e não repete ----------
    for modo in ('pular','esc','fundo','entendi'):
        c,pg=conta();nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(450)
        if modo=='pular':pg.click('.bkx')
        elif modo=='esc':pg.keyboard.press('Escape')
        elif modo=='fundo':pg.click('.bkbg',position={'x':5,'y':5})
        else:
            for _ in range(4):pg.click('[data-bk=next]');pg.wait_for_timeout(100)
            pg.click('[data-bk=next]')
        pg.wait_for_timeout(300)
        toast=pg.evaluate("document.getElementById('toast').className==='s'?document.getElementById('toast').textContent:''")
        ok(f'2. [{modo}] fecha o tutorial e libera as Configurações (nada bloqueado)',not aberto(pg) and pg.locator('#v-cfg:not([hidden]), #cfg:not([hidden])').count()+pg.locator('h2:has-text("Configurações")').count()>=1)
        ok(f'2. [{modo}] registra permanentemente na conta (S.flags.bkt)',flag(pg)==1)
        if modo=='entendi':ok('2. [entendi] concluir não mostra o aviso de "pulou"','Faça backups' not in toast,toast)
        else:ok(f'2. [{modo}] ao pular/fechar mostra um aviso discreto sobre a importância do backup','Faça backups' in toast and 'Como fazer backup?' in toast,toast)
        nav(pg,'home');nav(pg,'cfg');pg.wait_for_timeout(500)
        ok(f'2. [{modo}] ao voltar às Configurações não repete',not aberto(pg))
        pg.reload();pg.wait_for_selector('#nav [data-id=cfg]');pg.wait_for_timeout(600);nav(pg,'cfg');pg.wait_for_timeout(500)
        ok(f'2. [{modo}] depois de recarregar o site não repete',not aberto(pg) and flag(pg)==1)
        c.close()
    # ---------- 3. conta protegida: sair e entrar ----------
    c,pg=ctx();pg.goto(URL);OB_TO_SETUP(pg,'Bia');pg.fill('#sf [name=p]',PW);pg.fill('#sf [name=c]',PW);pg.click('#sf .b1');pg.wait_for_selector('#skcode',timeout=25000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=25000);pg.wait_for_timeout(800)
    nav(pg,'cfg');pg.wait_for_selector('#bkt',timeout=5000);pg.wait_for_timeout(400)
    for _ in range(5):pg.click('[data-bk=next]');pg.wait_for_timeout(100)
    pg.wait_for_timeout(400);pg.evaluate("lockNow()");pg.wait_for_selector('#lf');pg.fill('#lf [name=p]',PW);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=25000);pg.wait_for_timeout(600)
    nav(pg,'cfg');pg.wait_for_timeout(600)
    ok('3. Conta protegida: concluiu, saiu e entrou de novo → não repete (registro está dentro da conta)',not aberto(pg) and flag(pg)==1)
    pg.reload();pg.wait_for_selector('#lf');pg.fill('#lf [name=p]',PW);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=25000);pg.wait_for_timeout(600);nav(pg,'cfg');pg.wait_for_timeout(600)
    ok('3. Conta protegida: depois de recarregar e entrar → não repete',not aberto(pg))
    ok('3. O registro fica na própria conta, não em chave global do navegador',pg.evaluate("Object.keys(localStorage).filter(k=>/bkt|tutorial/i.test(k)).length")==0)
    pg.evaluate("S.flags.bkt=0;save()");ok('3. Controle é por conta: uma conta sem o registro (ex.: outra conta/backup antigo) vê o tutorial na 1ª visita',(nav(pg,'home'),nav(pg,'cfg'),pg.wait_for_selector('#bkt',timeout=4000))is not None)
    c.close()
    # ---------- 4. botão "Como fazer backup?" ----------
    c,pg=conta();nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(400);pg.click('.bkx');pg.wait_for_timeout(300);pg.wait_for_function("document.getElementById('toast').className!=='s'",timeout=9000)
    bt=pg.locator('.card:has(h3:text-is("Backup")) [data-act=bkt]')
    ok('4. "Como fazer backup?" fica dentro do cartão de BACKUP, discreto, uma só vez na tela',bt.count()==1 and bt.inner_text().strip()=='Como fazer backup?' and pg.locator('[data-act=bkt]').count()==1)
    bx=bt.bounding_box();ok('4. Alvo de toque ≥ 44 px e sem rolagem lateral',bx['height']>=44 and pg.evaluate("document.documentElement.scrollWidth<=document.documentElement.clientWidth+1"),bx)
    for vez in (1,2,3):
        bt.scroll_into_view_if_needed();bt.click();pg.wait_for_selector('#bkt');pg.wait_for_timeout(450)
        okp=pg.inner_text('#bkt h3')==TITULOS[0]
        pg.click('.bkx');pg.wait_for_timeout(300)
        t=pg.evaluate("document.getElementById('toast').className==='s'?document.getElementById('toast').textContent:''")
        ok(f'4. Revendo pela {vez}ª vez (mesmo já tendo visto): abre na etapa 1, fecha sem o aviso de 1ª visita e devolve o foco ao botão',okp and not aberto(pg) and 'Faça backups' not in t and pg.evaluate("document.activeElement&&document.activeElement.dataset.act")=='bkt',t)
    nav(pg,'home');nav(pg,'cfg');pg.wait_for_timeout(400);ok('4. Rever manualmente não faz o tutorial voltar sozinho',not aberto(pg))
    pg.evaluate("ACT.own&&0");pg.click('[data-act=own]');pg.wait_for_timeout(200);ok('4. Depois de fechar, as Configurações continuam normais (Salvar nome funciona)',not aberto(pg) and pg.locator('[data-act=exp]').is_visible())
    c.close()
    # ---------- 5/6. navegação, textos, ilustrações ----------
    c,pg=conta();nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(450)
    ok('5. Etapa 1: botão Voltar escondido e "Pular" visível',pg.evaluate("getComputedStyle(document.querySelector('[data-bk=prev]')).visibility")=='hidden' and pg.locator('.bkx').is_visible())
    tt=[];info=[]
    for i in range(5):
        pg.wait_for_timeout(420)
        tt.append(pg.inner_text('#bkt h3'))
        svg=pg.evaluate("(()=>{const s=document.querySelector('#bkt .bki svg'),r=s&&s.getBoundingClientRect(),c=document.querySelector('.bkc').getBoundingClientRect();return s?{w:r.width,h:r.height,n:s.querySelectorAll('path,rect,circle,g').length,dentro:r.left>=c.left-1&&r.right<=c.right+1,vazio:[...s.querySelectorAll('.bi-ph,.bi-fl,.bi-r')].length}:null})()")
        info.append(svg)
        ok(f'6. Etapa {i+1}: ilustração SVG própria aparece, inteira dentro do cartão',bool(svg) and svg['w']>=200 and svg['h']>=90 and svg['n']>=8 and svg['dentro'],svg)
        ok(f'5. Etapa {i+1}: indicador "Etapa {i+1} de 5" e {i+1} marcador(es) preenchido(s)',pg.inner_text('#bkt .bkn2').strip().lower()==f'etapa {i+1} de 5' and pg.locator('.bkd i.on, .bkd i.dn').count()==i+1)
        if i<4:pg.click('[data-bk=next]')
    ok('5. Os 5 títulos pedidos, na ordem',tt==TITULOS,tt)
    ok('5. Na etapa 5 o botão final é "ENTENDI" e o "Pular" some',pg.inner_text('[data-bk=next]')=='ENTENDI' and pg.evaluate("getComputedStyle(document.querySelector('.bkx')).visibility")=='hidden')
    t5=pg.inner_text('#bkt .bkb')
    ok('5. Mensagem final exatamente como pedida','Seus dados financeiros fazem parte da sua história. Proteja essa informação. Crie backups regularmente e mantenha uma cópia segura.' in t5)
    pg.click('[data-bk=prev]');pg.wait_for_timeout(450);pg.click('[data-bk=prev]');pg.wait_for_timeout(450);t3=pg.inner_text('#bkt .bkb')
    ok('5. Voltar funciona e a etapa 3 traz o aviso pedido e a orientação de senha/não compartilhar','Não deixe sua única cópia de segurança no mesmo dispositivo onde utiliza o aplicativo.' in t3 and 'Google Drive' in t3 and 'pasta de arquivos do celular' in t3 and 'outro local seguro' in t3.lower() and 'senha' in t3.lower() and 'Nunca compartilhe' in t3,t3[:200])
    pg.click('[data-bk=prev]');pg.wait_for_timeout(450);t2=pg.inner_text('#bkt .bkb')
    ok('5. Etapa 2 usa os botões reais ("Exportar backup", cartão "Backup") e diz que o app NÃO envia o arquivo sozinho','Exportar backup' in t2 and 'Backup' in t2 and 'não envia' in t2 and 'Quem escolhe o destino' in t2 and 'automaticamente' not in t2,t2[:240])
    pg.click('[data-bk=next]');pg.wait_for_timeout(300);pg.click('[data-bk=next]');pg.wait_for_timeout(450);t4=pg.inner_text('#bkt .bkb')
    ok('5. Etapa 4 usa o fluxo real ("Importar backup", conferir, confirmar) e avisa que SUBSTITUI e não mescla','Importar backup' in t4 and 'Confira' in t4 and 'confirme' in t4 and 'substitui' in t4 and 'não são mesclados' in t4 and 'não pode ser desfeito' in t4,t4[:260])
    alltxt=' '.join(pg.evaluate("[...document.querySelectorAll('#bkt h3,#bkt .bkb p,#bkt .bkb li,#bkt .bkb span')].map(e=>e.textContent)"))
    ok('6. Nenhum emoji usado no lugar de ilustração',not EMOJI.search(alltxt),EMOJI.findall(alltxt)[:3])
    # foco preso (Tab) e Esc
    pg.focus('[data-bk=next]');pg.keyboard.press('Tab');pg.keyboard.press('Tab');pg.keyboard.press('Tab');pg.keyboard.press('Tab')
    ok('5. O foco do teclado fica preso dentro do tutorial (Tab não escapa)',pg.evaluate("document.getElementById('bkt').contains(document.activeElement)"))
    pg.keyboard.press('Escape');pg.wait_for_timeout(250);ok('5. Esc fecha',not aberto(pg));c.close()
    # ---------- 7. claro e escuro (contraste medido na imagem) ----------
    def contraste(pg):
        itens=pg.evaluate("""(()=>{const out=[];const root=document.querySelector('.bkc');root.querySelectorAll('h3,p,li,span,button,b').forEach(e=>{if(e.closest('svg')||e.closest('[hidden]'))return;
          const own=[...e.childNodes].filter(n=>n.nodeType===3&&n.textContent.trim()).length;if(!own)return;const cs=getComputedStyle(e);if(cs.visibility==='hidden'||+cs.opacity===0)return;const r=e.getBoundingClientRect();if(r.width<2||r.height<2||r.bottom<0||r.top>innerHeight)return;
          out.push({t:e.textContent.trim().slice(0,28),c:cs.color,x0:r.left,y0:r.top,x1:r.right,y1:r.bottom,fs:parseFloat(cs.fontSize),fw:+cs.fontWeight})});return out})()""")
        pg.add_style_tag(content="#bkt .bkc *{color:transparent!important;text-decoration-color:transparent!important}#bkt svg text{fill:transparent!important}");pg.wait_for_timeout(120)
        im=Image.open(io.BytesIO(pg.screenshot())).convert('RGB');sx=im.size[0]/pg.evaluate('innerWidth');bad=[]
        pg.evaluate("document.querySelectorAll('style').forEach(s=>{if(s.textContent.startsWith('#bkt .bkc *{color:transparent'))s.remove()})")
        for it in itens:
            box=(int(it['x0']*sx),int(it['y0']*sx),max(int(it['x1']*sx),int(it['x0']*sx)+2),max(int(it['y1']*sx),int(it['y0']*sx)+2));px=list(im.crop(box).getdata())
            if not px:continue
            med=tuple(statistics.median(q[i] for q in px) for i in range(3));col,al=parse(it['c']);fg=tuple(col[i]*al+med[i]*(1-al) for i in range(3));rt=ratio(fg,med)
            need=3.0 if (it['fs']>=24 or (it['fs']>=18.66 and it['fw']>=700)) else 4.5
            if rt<need:bad.append((it['t'],round(rt,2)))
        return len(itens),bad
    for th in ('light','dark'):
        c,pg=conta(th=th);nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(500);pg.emulate_media(reduced_motion='reduce');tot=0;ruins=[]
        for i in range(5):
            pg.wait_for_timeout(450);n,bad=contraste(pg);tot+=n;ruins+=bad
            if i<4:pg.click('[data-bk=next]')
        fills=pg.evaluate("getComputedStyle(document.querySelector('#bkt .bi-pl')).fill")
        ok(f'7. Tema {th}: contraste mínimo de {tot} textos do tutorial (4,5:1; 3:1 se grande)',not ruins and tot>25,ruins[:4])
        ok(f'7. Tema {th}: as ilustrações usam a paleta azul do tema ({fills})',(fills=='rgb(234, 241, 255)')==(th=='light'),fills)
        pg.screenshot(path=os.path.join(TMP,f'bk_{th}.png'));c.close()
    # ---------- 8. celulares e computador ----------
    for w,h in ((393,851),(360,640),(320,568),(851,393),(1280,800)):
        c,pg=conta(w,h);nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(500);prob=[]
        for i in range(5):
            pg.wait_for_timeout(420)
            r=pg.evaluate("""(()=>{const c=document.querySelector('.bkc').getBoundingClientRect(),n=document.querySelector('[data-bk=next]'),nr=n.getBoundingClientRect(),t=document.elementFromPoint(nr.left+nr.width/2,nr.top+nr.height/2),b=document.querySelector('.bkb'),k=document.querySelector('.bkc');
              return{dentro:c.left>=-1&&c.top>=-1&&c.right<=innerWidth+1&&c.bottom<=innerHeight+1,btn:n.contains(t),alt:nr.height,sx:k.scrollWidth>k.clientWidth+1||b.scrollWidth>b.clientWidth+1||document.documentElement.scrollWidth>document.documentElement.clientWidth+1,rolavel:b.scrollHeight>b.clientHeight}})()""")
            if not(r['dentro'] and r['btn'] and r['alt']>=44 and not r['sx']):prob.append((i+1,r))
            # texto longo: dá para rolar até o fim
            if r['rolavel']:pg.evaluate("document.querySelector('.bkb').scrollTop=1e5")
            if i<4:pg.click('[data-bk=next]')
        ok(f'8. {w}x{h}: as 5 etapas cabem na tela, botões visíveis (≥ 44 px) e sem rolagem lateral; texto longo rola dentro do cartão',not prob,prob[:2]);c.close()
    # ---------- 9. offline ----------
    c,pg=ctx(service_workers='allow');pg.goto(URL);OB_NOSEC(pg,'Off');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.evaluate("navigator.serviceWorker.ready.then(()=>1)");pg.wait_for_timeout(2500)
    c.set_offline(True);pg.reload();pg.wait_for_selector('#nav [data-id=cfg]',timeout=15000);pg.wait_for_timeout(700);nav(pg,'cfg');pg.wait_for_selector('#bkt',timeout=5000);pg.wait_for_timeout(400)
    ok('9. Offline (service worker ativo): o tutorial abre e as ilustrações aparecem',pg.locator('#bkt .bki svg').count()==1)
    for _ in range(4):pg.click('[data-bk=next]');pg.wait_for_timeout(100)
    ok('9. Offline: navega até a etapa 5 e conclui',pg.inner_text('#bkt h3')==TITULOS[4]);pg.click('[data-bk=next]');pg.wait_for_timeout(300);ok('9. Offline: ENTENDI registra',not aberto(pg) and flag(pg)==1);c.close()
    # ---------- 10. não interfere com o tour inicial e outras telas ----------
    c,pg=conta();pg.evaluate("TOUR={i:0}");pg.evaluate("go('cfg')");pg.wait_for_timeout(500)
    ok('10. Com o tutorial geral do app em andamento, o de backup espera (não abre por cima)',not aberto(pg))
    pg.evaluate("TOUR=null;render()");pg.wait_for_timeout(300);ok('10. Terminado o tutorial geral, abre na próxima visita/atualização das Configurações',aberto(pg));c.close()
    # ---------- 11. lógica de backup intacta ----------
    c,pg=conta();nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(400);pg.click('.bkx');pg.wait_for_timeout(300)
    pg.evaluate("S.items.push({id:'t1',t:'exp',d:'Teste backup',c:12345,day:5,fixed:true,from:'2026-01',done:{},cat:'Outros',pay:'Pix'});save();render()")
    with pg.expect_download(timeout=20000) as dl:pg.click('[data-act=exp]')
    f=os.path.join(TMP,'bk.json');dl.value.save_as(f);o=json.load(open(f,encoding='utf-8'))
    ok('11. Exportar continua igual: arquivo wolfin-backup-AAAA-MM-DD.json com marca do app e os dados',re.fullmatch(r'wolfin-backup-\d{4}-\d{2}-\d{2}\.json',dl.value.suggested_filename) and o.get('__backup',{}).get('app')=='wallstreet-backup' and any(i.get('d')=='Teste backup' for i in o['items']),dl.value.suggested_filename)
    pg.evaluate("S.items=S.items.filter(i=>i.id!=='t1');save();render()")
    pg.evaluate("document.getElementById('file').value=''");pg.set_input_files('#file',f);pg.wait_for_selector('#ov [data-act=yes]',timeout=8000);msg=pg.inner_text('#ov')
    ok('11. Importar continua igual: mostra confirmação avisando que os dados atuais serão SUBSTITUÍDOS','SUBSTITUÍDOS' in msg,msg[:200])
    pg.click('#ov [data-act=yes]');pg.wait_for_timeout(500)
    ok('11. Importar restaura os dados do arquivo',pg.evaluate("S.items.some(i=>i.d==='Teste backup')"))
    ok('11. O conteúdo do backup nunca vai para o console/log',not any('Teste backup' in l or '"items"' in l for l in pg.logs))
    ok('11. Sem erros no console durante exportar/importar',not pg.errs,pg.errs[:3]);c.close()
    # ---------- zerar dados mantém o registro ----------
    c,pg=conta();nav(pg,'cfg');pg.wait_for_selector('#bkt');pg.wait_for_timeout(400);pg.click('.bkx');pg.wait_for_timeout(300)
    pg.click('[data-act=reset]');pg.wait_for_selector('#f [name=t]',timeout=5000);pg.fill('#f [name=t]','ZERAR');pg.click('#f button[type=submit]');pg.wait_for_timeout(700);pg.evaluate("go('home')");pg.evaluate("go('cfg')");pg.wait_for_timeout(500)
    ok('Zerar dados não faz o tutorial reaparecer (o registro de que já viu é mantido)',flag(pg)==1 and not aberto(pg));c.close()
    b.close()
print(sum(R),'/',len(R))
