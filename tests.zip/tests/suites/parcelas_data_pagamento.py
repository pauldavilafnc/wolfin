"""v7.11: data real do pagamento das parcelas (editar, pagar com data, pendente, mapa de calor, totais). Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
BASE="""{owner:'T',opening:{c:100000,d:'2026-01-01'},items:[],inst:[{id:'n1',n:'Celular',c:null,np:4,day:5,paid:false}],parc:[
{id:'q1',iid:'n1',ym:'2026-06',c:20000,due:'2026-06-05',paid:true,paidOn:'2026-11-15'},
{id:'q2',iid:'n1',ym:'2026-07',c:20000,due:'2026-07-05',paid:false},
{id:'q3',iid:'n1',ym:'2026-08',c:20000,due:'2026-08-05',paid:false},
{id:'q4',iid:'n1',ym:'2026-09',c:20000,paid:true}],debts:[],boxes:[],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light'):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'T')
        pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref()"%th)
        pg.evaluate("S=migrate("+BASE+");save();render()");return c,pg
    q=lambda pg,i:pg.evaluate("(()=>{const p=S.parc.find(x=>x.id==='%s');return{paid:p.paid,paidOn:p.paidOn===undefined?null:p.paidOn,due:p.due===undefined?null:p.due,ym:p.ym,c:p.c}})()"%i)
    def pick(pg,sel,ym_from,ym_to,day):
        """navega o calendário livre até ym_to e toca no dia"""
        n=(int(ym_to[:4])-int(ym_from[:4]))*12+int(ym_to[5:])-int(ym_from[5:])
        for _ in range(abs(n)):pg.click(sel+' .calnv[data-nv="%d"]'%(1 if n>0 else -1))
        pg.click(sel+' .cd[data-d="%s-%02d"]'%(ym_to,day))
    def save(pg):pg.click('#f .b1');pg.wait_for_timeout(250)
    # 1. pagar hoje pelo ✓ (data sugerida = hoje, mas editável)
    c,pg=app()
    pg.evaluate("ACT.payp('q2')");pg.wait_for_selector('#f .calw')
    ok('1. Ao pagar, o calendário abre já com a data de hoje (15/11/2026) escolhida',pg.evaluate("document.querySelector('#f input[name=pd]').value")=='2026-11-15')
    save(pg);r=q(pg,'q2')
    ok('1. Confirmar sem mexer registra pagamento em hoje; vencimento intacto',r['paid'] and r['paidOn']=='2026-11-15' and r['due']=='2026-07-05',r)
    # 2/5. parcela antiga: pagar numa data passada pelo ✓ (atrasado: venc 05/08, pago 08/08)
    pg.evaluate("ACT.payp('q3')");pg.wait_for_selector('#f .calw');pick(pg,'#f .calw','2026-11','2026-08',8);save(pg);r=q(pg,'q3')
    ok('2/5. Pagamento passado e atrasado (venc. 05/08, pago 08/08): data própria, vencimento inalterado',r['paidOn']=='2026-08-08' and r['due']=='2026-08-05',r)
    # 3. alterar data de parcela já paga (q1: 15/11 → 05/06) pelo Editar parcela
    pg.evaluate("ACT.edp('q1')");pg.wait_for_selector('#pdw .calw')
    vis=pg.evaluate("!document.getElementById('pdw').hidden")
    ok('3. Editar parcela paga: campo "Data do pagamento" visível, carrega a data guardada (15/11/2026)',vis and pg.evaluate("document.querySelector('#f input[name=pd]').value")=='2026-11-15')
    order=pg.evaluate("[...document.querySelectorAll('#f .lab, #f label, #f .dueinfo')].map(e=>e.textContent.trim().slice(0,12))")
    ok('3. Campo de pagamento fica logo após o de vencimento',order.index('Data do paga')==order.index('Dia de venci')+1,order)
    pick(pg,'#pdw .calw','2026-11','2026-06',5);save(pg);r=q(pg,'q1')
    ok('3. Data alterada para 05/06/2026; vencimento e valor preservados',r['paidOn']=='2026-06-05' and r['due']=='2026-06-05' and r['c']==20000,r)
    # 4. antecipado: q2 venc 05/07 → pago 03/07
    pg.evaluate("ACT.edp('q2')");pg.wait_for_selector('#pdw .calw');pick(pg,'#pdw .calw','2026-11','2026-07',3);save(pg);r=q(pg,'q2')
    ok('4. Pagamento antecipado (venc. 05/07, pago 03/07): datas independentes',r['paidOn']=='2026-07-03' and r['due']=='2026-07-05',r)
    # 6. pago → pendente remove data; campo some
    pg.evaluate("ACT.edp('q3')");pg.wait_for_selector('#f select[name=paid]');pg.select_option('#f select[name=paid]','0')
    ok('6. Mudar para Pendente esconde o campo de pagamento',pg.evaluate("document.getElementById('pdw').hidden"))
    save(pg);r=q(pg,'q3')
    ok('6. Pago → Pendente remove a data de pagamento; vencimento intacto',(not r['paid']) and r['paidOn'] is None and r['due']=='2026-08-05',r)
    # pendente → pago pelo formulário: campo aparece com hoje
    pg.evaluate("ACT.edp('q3')");pg.wait_for_selector('#f select[name=paid]')
    ok('6. Parcela pendente abre sem campo de pagamento',pg.evaluate("document.getElementById('pdw').hidden"))
    pg.select_option('#f select[name=paid]','1')
    ok('6. Ao marcar Pago, o campo aparece sugerindo hoje',pg.evaluate("!document.getElementById('pdw').hidden && document.querySelector('#f input[name=pd]').value")=='2026-11-15')
    pick(pg,'#pdw .calw','2026-11','2026-12',2);save(pg);r=q(pg,'q3')
    ok('Pagamento futuro permitido (02/12/2026)',r['paidOn']=='2026-12-02',r)
    # legado: paga sem data continua sem data e não é inventada
    pg.evaluate("ACT.edp('q4')");pg.wait_for_selector('#f select[name=paid]')
    ok('10. Parcela antiga paga sem data: nada é inventado ao abrir',pg.evaluate("document.querySelector('#f input[name=pd]').value")=='')
    save(pg);ok('10. Salvar sem data nova mantém a parcela como estava',q(pg,'q4')['paidOn'] is None and q(pg,'q4')['paid'])
    pg.evaluate("ACT.edp('q4')");pg.wait_for_selector('#pdw .calw');pick(pg,'#pdw .calw','2026-11','2026-09',9);save(pg)
    ok('Dá para informar a data real de uma parcela antiga sem data (09/09/2026)',q(pg,'q4')['paidOn']=='2026-09-09')
    ok('Sem erros de JS',pg.errs==[],pg.errs)
    # 7. mapa de calor
    pg.evaluate("(()=>{HMS.main.m='2026-06';HMS.main.sel=0;RPT='hm';go('rpt')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('7. Mapa de calor de junho mostra R$ 200 no dia 5',pg.inner_text('.hmw[data-hm=main] [data-d="5"] span')=='200')
    pg.evaluate("(()=>{HMS.main.m='2026-11';RPT='hm';go('rpt')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('7. Mapa de novembro não tem mais parcelas (todas foram pagas em outras datas): nenhum dia com valor',pg.evaluate("[...document.querySelectorAll('.hmw[data-hm=main] .hmc')].filter(e=>e.querySelector('span')&&e.querySelector('span').textContent).length")==0)
    pg.evaluate("(()=>{HMS.main.m='2026-07';RPT='hm';go('rpt')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('7. Mapa de julho: R$ 200 no dia 3 (pago antecipado), não no dia do vencimento (5)',pg.inner_text('.hmw[data-hm=main] [data-d="3"] span')=='200' and pg.inner_text('.hmw[data-hm=main] [data-d="5"] span')=='')
    # 8/9 totais e duplicidade
    t=pg.evaluate("({jun:relFlow('2026-06').exp,jul:relFlow('2026-07').exp,ago:relFlow('2026-08').exp,set:relFlow('2026-09').exp,nov:relFlow('2026-11').exp,dez:relFlow('2026-12').exp,n:S.parc.length,ni:S.inst.length,it:S.items.length})")
    ok('8. Totais mensais seguem a data real: jun 200, jul 200, ago 0, set 200, nov 0, dez 200',t['jun']==20000 and t['jul']==20000 and t['ago']==0 and t['set']==20000 and t['nov']==0 and t['dez']==20000,t)
    ok('9. Sem duplicação: continuam 4 parcelas, 1 plano, 0 despesas avulsas criadas',t['n']==4 and t['ni']==1 and t['it']==0,t)
    # 10. preservação: backup/restauração mantém campos
    s=pg.evaluate("JSON.stringify(S.parc.map(x=>[x.id,x.iid,x.ym,x.c,x.due||null,x.paid,x.paidOn||null]))");pg.reload();OB_NOSEC(pg,'T') if False else None
    ok('10. Nenhuma parcela perdeu valor/mês/plano',pg.evaluate("S.parc.every(x=>x.c===20000&&x.iid==='n1')") )
    c.close()
    # claro/escuro e celulares: calendário legível e botões ≥44px
    for th in ('light','dark'):
        for w,h in ((360,740),(393,851),(768,1024)):
            c,pg=app(w,h,th);pg.evaluate("ACT.edp('q1')");pg.wait_for_selector('#pdw .calw')
            m=pg.evaluate("""(()=>{const sh=document.querySelector('#ov .sheet'),r=e=>e.getBoundingClientRect(),nv=[...document.querySelectorAll('#pdw .calnv')].map(e=>[r(e).width,r(e).height]),cd=document.querySelector('#pdw .cd'),on=document.querySelector('#pdw .cd.on');
              const bg=getComputedStyle(document.body).backgroundColor,col=e=>getComputedStyle(e).color;return{nv,cdw:r(cd).width,cdh:r(cd).height,ovx:document.documentElement.scrollWidth>innerWidth,sh:[r(sh).left>=0,r(sh).right<=innerWidth],onbg:getComputedStyle(on).backgroundColor,onc:col(on)}})()""")
            ok(f'Calendário {th} {w}px: setas ≥44px, dias ≥33px, sem rolagem lateral, selecionado destacado',all(a>=43.5 and b>=43.5 for a,b in m['nv']) and m['cdw']>=33 and m['cdh']>=33 and not m['ovx'] and all(m['sh']) and m['onbg']!=m['onc'],m)
            if w==393:pg.screenshot(path=f'/tmp/pd_{th}.png')
            c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
