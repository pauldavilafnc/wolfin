"""v7.39: ícone de calculadora no tutorial, cartão de avisos do mascote (→ Relatórios / Loja), Aparência em 2 cartões e 3 níveis de Qualidade visual. Dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,**kw):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,timezone_id='America/Sao_Paulo',**kw);c.add_init_script("window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(HTTP_URL);OB_NOSEC(pg,'Maria Teste');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500);return c,pg
    # ---------- 1. tutorial
    TX8='Use a calculadora flutuante, o sino de avisos e as Anotações na Home. Dá para rever este tutorial em Ajustes. Bem-vindo ao Wolfin: domine seu dinheiro!'
    for th in('dark','light'):
        for pal in('midnight','blue'):
            c,pg=app();pg.evaluate(f"S.pref.theme='{th}';S.pref.pal='{pal}';save();applyPref();go('home')");pg.wait_for_timeout(300)
            pg.evaluate("TOUR={i:0};document.body.insertAdjacentHTML('beforeend',tourHtml?tourHtml():'')") if False else None
            pg.evaluate("tourStart?tourStart():0") if False else None
            pg.evaluate("go('cfg',{cat:'sobre'})");pg.wait_for_timeout(200);pg.click('#s-cfg [data-act=tourgo]');pg.wait_for_selector('#tour .tcard');pg.wait_for_timeout(500)
            info=[]
            for i in range(8):
                info.append(pg.evaluate("(()=>{const t=document.querySelector('#tour .tic'),r=t.getBoundingClientRect(),cs=getComputedStyle(t);return{i:TOUR.i,hid:t.hidden,disp:cs.display,w:Math.round(r.width),h:Math.round(r.height),svg:!!t.querySelector('svg'),col:cs.color,tx:document.querySelector('#tour .tx').textContent}})()"))
                if i<7:pg.click('#tour [data-tr=next]');pg.wait_for_timeout(350)
            last=info[7]
            ok(f'1. Última etapa (8 de 8) mostra o ícone de calculadora — tema {th}, paleta {pal}',last['svg'] and not last['hid'] and last['disp']!='none' and last['w']==36 and last['h']==36 and 'rect' in pg.evaluate("document.querySelector('#tour .tic').innerHTML"),last)
            ok(f'1. Mesmo tamanho/cor dos ícones das outras etapas ({th}/{pal})',all((x['w'],x['h'])==(36,36) and x['col']==last['col'] for x in info if x['svg']),[(x['i'],x['w'],x['col']) for x in info])
            ok(f'1. Texto da etapa 8 não mudou ({th}/{pal})',last['tx']==TX8)
            ok(f'1. Etapas sem ícone não deixam quadrado vazio ({th}/{pal})',all(x['disp']=='none' for x in info if not x['svg']) and sum(1 for x in info if not x['svg'])>=1,[(x['i'],x['disp']) for x in info if not x['svg']])
            c.close()
    # ---------- 2/3/4 cartão de avisos do mascote
    c,pg=app();pg.evaluate("go('home')");pg.wait_for_timeout(400)
    on=pg.evaluate("wfOn()")
    ok('2. Home com mascote ativo: cartão de avisos tem área de texto clicável e botão do mascote separado',pg.locator('#s-home .mq2 .mqn').count()==1 and pg.locator('#s-home .mq2 .mqb').count()==1,pg.evaluate("document.querySelector('#s-home .mqc')?.outerHTML.slice(0,200)"))
    if not on: pg.evaluate("S.wc.on=true;save();render()") if False else None
    pg.click('#s-home .mq2 .mqn');pg.wait_for_timeout(500)
    ok('2. Tocar no texto de avisos abre Relatórios',pg.evaluate("view")=='rel')
    ok('2. ...e Relatórios mostra o cartão "Minha situação financeira" no topo',pg.locator('#s-rel .sith').count()==1)
    pg.evaluate("go('home')");pg.wait_for_timeout(300)
    pg.click('#s-home .mq2 .mqb');pg.wait_for_timeout(500)
    ok('3. Tocar diretamente no mascote abre a Loja do Wolfin',pg.evaluate("view")=='loja')
    ok('3. Os dois toques não interferem (cada um só navega uma vez)',pg.evaluate("NSTK.length")==1,pg.evaluate("NSTK"))
    pg.evaluate("go('home')");pg.wait_for_timeout(200)
    # texto das mensagens e critério intactos
    t_card=pg.evaluate("document.querySelector('#s-home .mq2 .mqn .mt').textContent.trim()");t_say=pg.evaluate("mqSay()[1]")
    ok('2. Conteúdo da mensagem continua o mesmo (vem de mqSay)',t_card.replace(' ','')[:30]==re.sub(r'\s','',t_say)[:30] or t_say.startswith(t_card[:20]) or t_card.startswith(t_say[:20]),(t_card,t_say))
    css=open(_os.path.join(ROOT,'index.html'),encoding='utf-8').read()
    ok('2. Feedback discreto ao toque (:active) no texto de avisos',re.search(r'\.mq2 \.mqn:active',css) is not None and re.search(r'button\.mqc:active',css) is not None)
    # saldo negativo (mesma rota)
    pg.evaluate("S.opening={c:-5000,d:todayStr()};save();go('home')");pg.wait_for_timeout(400)
    pg.click('#s-home .mq2 .mqn');pg.wait_for_timeout(400);ok('2. Mensagem de saldo negativo também abre Relatórios',pg.evaluate("view")=='rel')
    # mascote desativado
    pg.evaluate("S.opening=null;save()");pg.evaluate("go('cfg',{cat:'mascote'})");pg.wait_for_timeout(300);pg.click('[data-act=wfon]');pg.wait_for_timeout(300)
    pg.evaluate("go('home')");pg.wait_for_timeout(400)
    ok('4. Com o mascote desativado não existe botão do mascote nem da Loja no cartão',not pg.evaluate("wfOn()") and pg.locator('#s-home .mqb').count()==0)
    ok('4. ...mas o cartão de avisos continua clicável e abre Relatórios',pg.locator('#s-home button.mqc').count()==1)
    pg.click('#s-home button.mqc');pg.wait_for_timeout(400);ok('4. Toque no cartão (mascote desativado) → Relatórios',pg.evaluate("view")=='rel')
    c.close()
    # ---------- 5. Aparência em dois cartões
    c,pg=app();OPEN_CFG(pg,'aparencia')
    ok('5. Cartão 1 "Tema": só Claro e Escuro',pg.locator('#cs-tema h3').inner_text()=='Tema' and pg.locator('#cs-tema [data-act=theme]').count()==2 and pg.locator('#cs-tema select,#cs-tema [data-act=pal]').count()==0)
    ok('5. Cartão 2 "Personalização visual": paletas, Qualidade visual e Animações dos ícones',pg.locator('#cs-apa h3').inner_text()=='Personalização visual' and pg.locator('#cs-apa [data-act=pal]').count()==9 and pg.locator('#cs-apa #glSel').count()==1 and pg.locator('#cs-apa #anSel').count()==1 and pg.locator('#cs-apa [data-act=theme]').count()==0)
    ok('5. Midnight Violet continua entre as paletas',pg.locator('#cs-apa [data-act=pal][data-id=midnight]').count()==1)
    ok('5. Rótulo "Efeito de vidro" foi trocado por "Qualidade visual"','Efeito de vidro' not in pg.inner_text('#s-cfg') and 'Qualidade visual' in pg.inner_text('#cs-apa'))
    pg.click('#cs-tema [data-act=theme][data-id=light]');pg.wait_for_timeout(300);t1=pg.evaluate("document.documentElement.dataset.theme")
    pg.click('#cs-tema [data-act=theme][data-id=dark]');pg.wait_for_timeout(300)
    ok('5. Alternar tema claro/escuro funciona',t1=='light' and pg.evaluate("document.documentElement.dataset.theme")=='dark')
    pals=[];
    for k in ['azul','violet','teal','rose','orange','gold','emerald','graphite','midnight']:pass
    ids=pg.evaluate("[...document.querySelectorAll('#cs-apa [data-act=pal]')].map(b=>b.dataset.id)")
    seq=[]
    for i in ids:
        pg.click(f'#cs-apa [data-act=pal][data-id={i}]');pg.wait_for_timeout(120);seq.append(pg.evaluate("document.documentElement.dataset.pal")==i and pg.evaluate("S.pref.pal")==i)
    ok('5. Cada uma das 9 paletas é selecionada e salva',all(seq) and len(ids)==9,ids)
    # ---------- 6. Qualidade visual
    opts=pg.evaluate("[...document.querySelectorAll('#glSel option')].map(o=>[o.value,o.textContent])")
    ok('6. Três níveis: Alta — Visual completo / Equilibrada — Recomendada / Econômica — Maior desempenho',opts==[['hi','Alta — Visual completo'],['mid','Equilibrada — Recomendada'],['lo','Econômica — Maior desempenho']],opts)
    MEAS="""(()=>{let n=0,mx=0,sum=0,sh=0;for(const e of document.querySelectorAll('*')){const cs=getComputedStyle(e),f=cs.backdropFilter||cs.webkitBackdropFilter||'none';if(f&&f!=='none'){n++;const m=/blur\\(([\\d.]+)px\\)/.exec(f);if(m){const v=+m[1];mx=Math.max(mx,v);sum+=v}}if(cs.boxShadow&&cs.boxShadow!=='none')sh+=cs.boxShadow.split('),').length}
      const card=document.querySelector('.card');return{g:document.documentElement.dataset.glass,n,mx,sum,sh,bg:getComputedStyle(card).backgroundColor,bs:getComputedStyle(card).boxShadow.slice(0,90)}})()"""
    M={}
    pg.evaluate("go('home')");pg.wait_for_timeout(300);pg.evaluate("go('cfg',{cat:'aparencia'})");pg.wait_for_timeout(300)
    for q in('hi','mid','lo'):
        pg.select_option('#glSel',q);pg.wait_for_timeout(350);M[q]=pg.evaluate(MEAS)
    ok('6. data-glass muda por nível (on / mid / off)',[M[q]['g'] for q in('hi','mid','lo')]==['on','mid','off'],M)
    ok('6. Diferença real: Econômica não usa nenhum desfoque; Equilibrada usa desfoque menor que a Alta',M['lo']['n']==0 and M['lo']['mx']==0 and 0<M['mid']['mx']<M['hi']['mx'] and M['mid']['sum']<M['hi']['sum'],{q:(M[q]['n'],M[q]['mx'],M[q]['sum']) for q in M})
    ok('6. Econômica simplifica sombras e superfícies (fundo sólido, sombra simples)',M['lo']['bg']!=M['hi']['bg'] and M['lo']['bs']!=M['hi']['bs'] and M['mid']['bs']!=M['hi']['bs'],{q:(M[q]['bg'],M[q]['bs']) for q in M})
    pg.select_option('#glSel','lo');pg.wait_for_timeout(300)
    ok('6. Mudar a qualidade não altera a paleta selecionada',pg.evaluate("S.pref.pal")==ids[-1] and pg.evaluate("document.documentElement.dataset.pal")==ids[-1])
    ok('6. Econômica não desliga as animações dos ícones (controle próprio)',pg.evaluate("S.pref.av.an")==1 and 'Ligadas' in pg.evaluate("document.querySelector('#anSel').selectedOptions[0].textContent"))
    pg.select_option('#anSel','0');pg.wait_for_timeout(250);pg.select_option('#glSel','hi');pg.wait_for_timeout(250)
    ok('6. Animações dos ícones ficam como o usuário escolheu quando a qualidade muda',pg.evaluate("S.pref.av.an")==0)
    pg.select_option('#anSel','1');pg.wait_for_timeout(200)
    ok('6. Legenda do nível muda junto com a escolha',all(x in pg.inner_text('#qdesc') for x in['Liquid Glass']) )
    pg.select_option('#glSel','lo');pg.wait_for_timeout(300)
    ok('6. Legibilidade: textos continuam visíveis no nível Econômico (contraste do texto sobre o cartão ≥ 4,5:1)',pg.evaluate("""(()=>{const L=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};const e=document.querySelector('#cs-apa h3'),cs=getComputedStyle(e),card=getComputedStyle(document.querySelector('#cs-apa')).backgroundColor;const a=L(cs.color),bb=L(card.startsWith('rgba')&&/,\\s*0\\)$/.test(card)?getComputedStyle(document.body).backgroundColor:card);const hi=Math.max(a,bb),lo=Math.min(a,bb);return (hi+.05)/(lo+.05)>=4.5})()"""))
    # persistência
    pg.reload();pg.wait_for_selector('#lock',state='attached');pg.wait_for_timeout(1500)
    ok('6. Persistência: nível Econômico restaurado ao reabrir (data-glass=off e preferência salva)',pg.evaluate("document.documentElement.dataset.glass")=='off' and pg.evaluate("JSON.parse(localStorage.getItem(KEY)).pref.q")=='lo')
    c.close()
    # migração de preferências antigas e compatibilidade de backup
    c,pg=app()
    r=pg.evaluate("""(()=>{const o=[];for(const p of [{gl:0},{gl:1},{},{gl:1,q:'mid'},{gl:0,q:'hi'},{q:'xyz'}])o.push(qual(p));return o})()""")
    ok('6. Preferências antigas: gl=0 → Econômica; gl=1/sem valor → Alta; q salvo vale; valor inválido → Alta',r==['lo','hi','hi','mid','hi','hi'],r)
    pg.evaluate("S.pref.q='mid';S.pref.gl=1;save()");txt=pg.evaluate("bkpExportText()");ok('6. Backup exportado leva a qualidade escolhida',json.loads(txt)['pref'].get('q')=='mid' if 'pref' in json.loads(txt) else 'mid' in txt)
    ok('6. Qualidade visual só mexe em S.pref (sem tocar em dados financeiros)',pg.evaluate("(()=>{const a=JSON.stringify([S.items,S.debts,S.boxes,S.parc,S.opening]);const b0=balance();S.pref.q='lo';save();render();return a===JSON.stringify([S.items,S.debts,S.boxes,S.parc,S.opening])&&b0===balance()})()"))
    c.close()
    # acessibilidade: movimento reduzido e transparência reduzida
    c,pg=app(reduced_motion='reduce');OPEN_CFG(pg,'aparencia');pg.select_option('#glSel','hi');pg.wait_for_timeout(300)
    ok('6. Movimento reduzido continua respeitado (animações do app seguem a preferência do sistema)',pg.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches") and 'prefers-reduced-motion:reduce' in css.replace(' ',''))
    ok('6. Transparência reduzida do sistema continua tendo prioridade (regra mantida no CSS)','prefers-reduced-transparency:reduce' in css.replace(' ','') and 'backdrop-filter:none!important' in css.replace(' ',''))
    c.close()
    # sem erros e sem rolagem horizontal
    for w in(320,360,393,768):
        c,pg=app(w,800);OPEN_CFG(pg,'aparencia');pg.select_option('#glSel','mid');pg.wait_for_timeout(250)
        ok(f'10. Aparência em {w}px: sem rolagem horizontal, sem erros, controles dentro da tela',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1") and not pg.errs and pg.evaluate("[...document.querySelectorAll('#cs-tema button,#cs-apa button,#cs-apa select')].every(e=>{const r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1})"),pg.errs[:1])
        c.close()
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
