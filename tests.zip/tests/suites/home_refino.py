"""v7.20: Home refinada (só visual). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
ST={'pos':"",'neg':"S.opening.c=-900000;",'zero':"S.items=[];S.debts=[];S.boxes=[];S.inst=[];S.parc=[];S.cards=[];S.opening.c=0;S.org={notes:[],rems:[],lists:[]};",
    'big':"S.opening.c=99999999999;",'long':"S.pref.name='Maria Aparecida de Nazaré Albuquerque Montenegro';"}
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(st='pos',w=393,h=851,th='light',pal=None):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,timezone_id='America/Sao_Paulo')
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};"+ST[st]+"S.pref.theme='%s';"%th+("S.pref.pal='%s';"%pal if pal else '')+"save();applyPref();go('home')");pg.wait_for_timeout(600);return c,pg
    # layout em várias larguras/temas/estados
    for w,h in((320,568),(360,740),(393,851),(430,932),(768,1024)):
        for th in('light','dark'):
            for st in('pos','neg','zero','big','long'):
                c,pg=home(st,w,h,th)
                m=pg.evaluate("""()=>{const de=document.documentElement,H=document.querySelector('#s-home'),bad=[];
                 H.querySelectorAll('.hero,.mqc,.qa button,.nth0,.tile,.sqb,.top').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>innerWidth+0.5||r.left<-0.5)bad.push(e.className)});
                 H.querySelectorAll('.pill,.big,.v,.mqc p,.nth0 .lbl,.qa button,.hello').forEach(e=>{if(e.scrollWidth>e.clientWidth+1&&getComputedStyle(e).overflow!=='visible'&&getComputedStyle(e).textOverflow!=='ellipsis')bad.push('clip:'+e.className)});
                 const q=[...H.querySelectorAll('.tb .ib,.qa button,.mqc button,.nth0,.sqb,.av')].filter(e=>{const r=e.getBoundingClientRect();return r.height<43.5||r.width<43.5});
                 const o=[...H.querySelectorAll('.top,.sqb,.hero,.mqc,.qa,.nth0')].map(e=>e.getBoundingClientRect()),ov=[];for(let i=0;i<o.length;i++)for(let j=i+1;j<o.length;j++)if(o[i].bottom>o[j].top+1&&o[i].top<o[j].bottom-1&&o[i].right>o[j].left&&o[i].left<o[j].right)ov.push(i+'/'+j);
                 return{sx:de.scrollWidth>innerWidth,bad,small:q.map(e=>e.className+' '+Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height)),ov}}""")
                ok(f'B. {w}px {th} {st}: sem rolagem horizontal, sem texto cortado/fora da tela, sem sobreposição, alvos ≥44px',not m['sx'] and not m['bad'] and not m['ov'] and not m['small'] and not pg.errs,m)
                c.close()
    # ordem e altura (393)
    c,pg=home('pos')
    y=pg.evaluate("""()=>{const g=s=>{const e=document.querySelector(s);return e?Math.round(e.getBoundingClientRect().top):-1};return{top:g('#s-home .top'),sq:g('#s-home .sqb'),hero:g('#s-home .hero'),mq:g('#s-home .mqc'),qa:g('#s-home .qa'),nt:g('#s-home .nth0'),tile:g('#s-home .g2'),heroH:Math.round(document.querySelector('#s-home .hero').getBoundingClientRect().height),qaH:Math.round(document.querySelector('#s-home .qa').getBoundingClientRect().height),sqH:Math.round(document.querySelector('#s-home .sqb').getBoundingClientRect().height)}}""")
    ok('C. Ordem: cabeçalho, busca, saldo, aviso, ações rápidas, anotações, resumo',y['top']<y['sq']<y['hero']<y['mq']<y['qa']<y['nt']<y['tile'],y)
    ok('C. Alturas compactas: busca ≤48, ações ≤56, saldo ≤230',y['sqH']<=48 and y['qaH']<=56 and y['heroH']<=230,y)
    ok('C. Saldo, ações e anotações visíveis sem rolar (393×851)',pg.evaluate("[...document.querySelectorAll('#s-home .hero,#s-home .qa,#s-home .nth0')].every(e=>e.getBoundingClientRect().bottom<innerHeight-70)"))
    ok('C. Texto do saldo: Recebido/Pago/Guardado e explicação preservados',all(t in pg.inner_text('#s-home .hero') for t in('Recebido','Pago','Guardado','Só conta o que já aconteceu')))
    ok('C. Ações rápidas lado a lado (mesma linha), três botões',pg.evaluate("(()=>{const t=[...document.querySelectorAll('#s-home .qa button')].map(b=>Math.round(b.getBoundingClientRect().top));return t.length===3&&t.every(x=>x===t[0])})()"))
    ok('C. Anotações mostra contagem de notas e tarefas pendentes',bool(re.search(r'\d+ notas? · \d+ tarefas? pendentes?',pg.inner_text('#s-home .nth0'))),pg.inner_text('#s-home .nth0'))
    # funcionamento dos botões
    pg.click('#s-home .qa button:nth-child(1)');pg.wait_for_selector('#ov .sheet,#ov form,#ov');pg.wait_for_timeout(500);ok('D. Receita abre o formulário',pg.locator('#ov:not([hidden])').count()>=1 and 'eceita' in pg.inner_text('#ov'));pg.evaluate("closeOv()");pg.wait_for_timeout(300)
    pg.click('#s-home .qa button:nth-child(2)');pg.wait_for_timeout(500);ok('D. Despesa abre o formulário',pg.locator('#ov:not([hidden])').count()>=1 and 'espesa' in pg.inner_text('#ov'));pg.evaluate("closeOv()");pg.wait_for_timeout(300)
    pg.click('#s-home .qa button:nth-child(3)');pg.wait_for_timeout(400);ok('D. Guardar abre Caixinhas',pg.locator('#s-cx:not([hidden])').count()==1 or pg.evaluate("view")=='cx');pg.evaluate("go('home')");pg.wait_for_timeout(300)
    pg.click('#s-home .mqc .cl');pg.wait_for_timeout(400);ok('D. Acesso discreto às conquistas funciona',pg.evaluate("view")=='conq');pg.evaluate("go('home')");pg.wait_for_timeout(300)
    pg.click('#s-home .nth0');pg.wait_for_timeout(400);ok('D. Anotações abre a aba de notas',pg.evaluate("view")=='nt');pg.evaluate("go('home')");pg.wait_for_timeout(300)
    pg.click('#s-home .sqb');pg.wait_for_timeout(500);ok('D. Busca continua abrindo',pg.locator('#ov:not([hidden])').count()>=1);pg.evaluate("closeOv()")
    c.close()
    # aviso: estados
    c,pg=home('neg');t=pg.inner_text('#s-home .mqc');bal=pg.evaluate("brl(balance())")
    ok('E. Saldo negativo: aviso compacto "Seu saldo está negativo", sem repetir o valor, com "Ver detalhes"',('Seu saldo está negativo' in t) and bal not in t and 'Ver detalhes' in t and 'Conquista' not in t,t)
    ok('E. Aviso negativo é compacto (≤110px)',pg.evaluate("document.querySelector('#s-home .mqc').getBoundingClientRect().height")<=110)
    pg.click('#s-home .mqc .dl');pg.wait_for_timeout(400);ok('E. "Ver detalhes" abre os relatórios',pg.evaluate("view")=='rel');c.close()
    c,pg=home('pos');t=pg.inner_text('#s-home .mqc');ok('E. Saldo positivo: nenhum aviso de saldo negativo',pg.evaluate("balance()")>=0 and 'saldo está negativo' not in t.lower(),t);c.close()
    c,pg=home('zero');t=pg.inner_text('#s-home .mqc');ok('E. Saldo zerado/neutro: sem alerta de negativo',pg.evaluate("balance()")==0 and 'negativo' not in t.lower() and pg.locator('#s-home .mqc.neg').count()==0,t);c.close()
    # temas: paletas, claro/escuro, contraste do texto principal
    for pal in('azul','violet','teal','ouro','grafite'):
        for th in('light','dark'):
            c,pg=home('neg',393,851,th,pal)
            r=pg.evaluate("""()=>{const L=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};
             const h=document.querySelector('#s-home .hero'),b=getComputedStyle(h).backgroundImage,cs=b.match(/rgba?\\([^)]*\\)/g)||[],fg=L(getComputedStyle(h.querySelector('.big')).color);
             return cs.map(c=>{const l=L(c);return+(((Math.max(fg,l)+.05)/(Math.min(fg,l)+.05)).toFixed(2))})}""")
            ok(f'F. Tema {pal}/{th}: texto do saldo com contraste ≥4.5:1 sobre o gradiente',bool(r) and min(r)>=4.5 and not pg.errs,r);c.close()
    # nav / botão flutuante não cobrem o último conteúdo (320x568)
    c,pg=home('pos',320,568);pg.evaluate("document.querySelector('main').scrollTo(0,1e6);window.scrollTo(0,1e6)");pg.wait_for_timeout(300)
    r=pg.evaluate("""()=>{const n=document.querySelector('#nav').getBoundingClientRect(),l=[...document.querySelectorAll('#s-home > *')].filter(e=>e.getBoundingClientRect().height>0).pop().getBoundingClientRect();return{navTop:Math.round(n.top),lastBottom:Math.round(l.bottom)}}""")
    ok('G. Rolando até o fim, o último conteúdo fica acima da barra inferior',r['lastBottom']<=r['navTop']+1,r)
    ok('G. Barra inferior mantém as 7 abas e o botão flutuante existe',pg.locator('#nav button').count()==7 and pg.locator('#cfab').count()==1)
    pg.click('#cfab');pg.wait_for_timeout(500);ok('G. Botão flutuante abre o mini painel (320×568)',pg.locator('#tpan').is_visible() and pg.locator('#tpan button,#tpan [data-act]').count()>=3)
    c.close()
    # persistência: nada mudou nos dados ao renderizar a Home
    c,pg=home('pos');a=pg.evaluate("JSON.stringify(S)");pg.evaluate("go('rec');go('home')");pg.wait_for_timeout(300);bb=pg.evaluate("JSON.stringify(S)")
    ok('H. Renderizar a Home não altera os dados',a==bb);c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
