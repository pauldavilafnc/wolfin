"""v7.34: "Conferir meu saldo" (conciliação por ajuste), Home simplificada, avisos e mascote (sem botão flutuante). Só dados fictícios (centavos)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json,copy
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
NOW='2026-11-24T20:00:00-03:00'
N=[0]
def uid():N[0]+=1;return 'y%d'%N[0]
def it(t,c,day,done=None,paid=None,fixed=True,ym='2026-11',d=None):
    o={'id':uid(),'t':t,'d':d or ('Salário' if t=='inc' else 'Conta'),'c':c,'day':day,'fixed':fixed,'cat':'Salário' if t=='inc' else 'Outros','pay':'Pix'}
    if fixed:o['from']=ym
    else:o['ym']=ym
    if done is not None:o['done']={ym:done};o['paidOn']={ym:paid or '%s-%02d'%(ym,day)}
    return o
def st(items=(),opening=None,debts=(),recon=None):
    s={'v':2,'owner':'T','opening':opening,'limits':{},'ntf':{'read':{}},'pref':{'theme':'dark','pal':'midnight','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':list(items),'inst':[],'parc':[],'debts':list(debts),'boxes':[]}
    if recon is not None:s['recon']=recon
    return s
# Cenário do usuário (fictício): -902,90 calculado; 148,62 reais; Academia 95,00 + Internet 59,90 atrasadas
def real():
    return st([it('inc',81100,5,done=81100,paid='2026-11-05',d='Salário'),it('inc',81100,28,d='Quinzena'),
      it('exp',76390,10,done=76390,paid='2026-11-10',d='Contas pagas'),
      it('exp',95000,10,done=95000,paid='2026-10-10',ym='2026-10',fixed=False,d='Gastos de outubro'),
      it('exp',9500,20,d='Academia'),it('exp',5990,17,d='Internet')][:4]+[it('exp',9500,8,d='Academia'),it('exp',5990,7,d='Internet')])
LOAD="(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};save();go('home')}"
Q="()=>({b:balance(),p:prevSaldo(),f:flows(),rc:(S.recon||[]).length})"
SAVE_FORM="(a)=>reconSave(a[0],a[1])"
with sync_playwright() as p:
    b=p.chromium.launch()
    def page(w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo')
        c.add_init_script("window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time(NOW);pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(600);return c,pg
    def load(pg,s):pg.evaluate(LOAD,json.dumps(s));pg.wait_for_timeout(250);return pg.evaluate(Q)
    def conf(pg,c,d='2026-11-24',note='',i=None):return pg.evaluate("(a)=>reconSave({c:a[0],d:a[1],note:a[2]},a[3])",[c,d,note,i])
    c,pg=page()
    r=load(pg,real());items0=pg.evaluate("JSON.stringify(S.items)");flo0=pg.evaluate("JSON.stringify(Object.values(flows()).map(x=>[x.inc,x.exp,x.dp,x.bx]))")
    ok('1. Cenário: saldo calculado −902,90; duas contas atrasadas somam 154,90 e continuam pendentes',r['b']==-90290 and r['p']['aPag']==15490 and r['p']['late']==2,(r['b'],r['p']['aPag'],r['p']['late']))
    h=pg.inner_text('#s-home .hero')
    ok('2. Home simplificada: só "Saldo atual" e "Saldo previsto até o fim do mês" visíveis; Recebido/Pago/A receber/A pagar ficam nos detalhes (ⓘ)',('Saldo atual' in h and 'Saldo previsto até o fim do mês' in h) and not pg.evaluate("document.querySelector('#s-home .hero .hdet').open") and not pg.locator('#s-home .hero > .pills').count(),h.replace('\n',' | ')[:160])
    # abrir detalhes pelo ⓘ
    pg.click('#s-home .hero .hdet summary');pg.wait_for_timeout(300)
    dt=pg.inner_text('#s-home .hero .hdc')
    ok('3. Detalhes (ⓘ): Recebido, Pago, A receber, A pagar, Origem do saldo, Conferir meu saldo e Histórico de conferências',all(x in dt for x in ('Recebido no mês','Pago no mês','A receber','A pagar','Origem do saldo atual','Saldo inicial','Movimentações de meses anteriores','Conferir meu saldo','Histórico de conferências')),dt.replace('\n',' | ')[:300])
    # conferir
    pg.click('#s-home .hero .hconf');pg.wait_for_timeout(300)
    pg.fill('#f input[name=c]','148,62');pg.wait_for_timeout(150)
    pv=pg.inner_text('#rcprev')
    ok('4. Formulário "Conferir meu saldo": valor, data (hoje), observação e prévia do saldo calculado e do ajuste (+1.051,52)',pg.locator('#f input[name=d]').input_value()=='2026-11-24' and pg.locator('#f input[name=note]').count()==1 and '-R$ 902,90' in pv.replace('−','-') and '1.051,52' in pv and 'não é receita nem despesa' in pg.inner_text('#f'),pv)
    pg.fill('#f input[name=note]','Saldo do banco');pg.click('#f button[type=submit]');pg.wait_for_timeout(400)
    r=pg.evaluate(Q);rec=pg.evaluate("S.recon[0]")
    ok('5. Conciliação feita: saldo atual = R$ 148,62; registro com data, valor informado, calculado, ajuste (105152), observação e carimbo',r['b']==14862 and r['rc']==1 and rec['c']==14862 and rec['calc']==-90290 and rec['adj']==105152 and rec['d']=='2026-11-24' and rec['note']=='Saldo do banco' and rec.get('at') and rec.get('id'),rec)
    ok('6. Histórico preservado: nenhum lançamento alterado; totais mensais de receitas/despesas iguais; ajuste não vira receita nem despesa',pg.evaluate("JSON.stringify(S.items)")==items0 and pg.evaluate("JSON.stringify(Object.values(flows()).map(x=>[x.inc,x.exp,x.dp,x.bx]))")==flo0 and pg.evaluate("flows()['2026-11'].aj")==105152)
    ok('7. As contas atrasadas continuam pendentes: a pagar 154,90; saldo atual continua R$ 148,62 antes de pagá-las',r['p']['aPag']==15490 and r['b']==14862 and r['p']['late']==2)
    ok('8. Previsto = 148,62 + a receber 811,00 − a pagar 154,90 = 804,72',r['p']['prev']==80472,r['p']['prev'])
    # repetir
    n0=pg.evaluate("S.recon.length");conf(pg,'148,62');ok('9. Repetir a conferência com o mesmo valor não duplica ajuste',pg.evaluate("S.recon.length")==n0==1 and pg.evaluate("balance()")==14862)
    # pagar as duas
    ids=pg.evaluate("S.items.filter(i=>i.d==='Academia'||i.d==='Internet').map(i=>i.id)")
    pg.evaluate("(a)=>a.forEach(id=>ACT.tog(id,{dataset:{m:'2026-11'}}))",ids);pg.wait_for_timeout(300);r=pg.evaluate(Q)
    ok('10. Pagando as duas contas atrasadas o saldo vira −R$ 6,28',r['b']==-628 and r['p']['late']==0,(r['b'],r['p']['late']))
    # receita recebida depois
    qid=pg.evaluate("S.items.find(i=>i.d==='Quinzena').id");pg.evaluate("(i)=>ACT.tog(i,{dataset:{m:'2026-11'}})",qid);pg.wait_for_timeout(250)
    ok('11. Receita recebida depois da conferência soma uma vez (−6,28 + 811,00 = 804,72)',pg.evaluate("balance()")==80472,pg.evaluate("balance()"))
    # dívida parcelada
    pg.evaluate("S.debts.push({id:'dv1',n:'Empréstimo',o:30000,pays:[]});save();render()");b1=pg.evaluate("balance()")
    pg.evaluate("S.debts[0].pays.push({d:'2026-11-24',c:10000});save();render()");b2=pg.evaluate("balance()")
    ok('12. Pagamento de dívida parcelada após a conferência desconta uma vez só',b1==80472 and b2==70472,(b1,b2))
    # correção
    rid=pg.evaluate("S.recon[0].id");pg.evaluate("go('home')");pg.wait_for_timeout(200)
    pg.evaluate("ACT.rcedit(S.recon[0].id)");pg.wait_for_timeout(250);pg.fill('#f input[name=c]','100,00');pg.click('#f button[type=submit]');pg.wait_for_timeout(350)
    rec=pg.evaluate("S.recon[0]");bb=pg.evaluate("balance()")
    ok('13. Corrigir a conferência (148,62 → 100,00): mesmo registro, ajuste recalculado, revisão guardada, saldo atual passa a ser exatamente 100,00 (a conferência vale para a data informada)',pg.evaluate("S.recon.length")==1 and rec['id']==rid and rec['c']==10000 and rec['adj']==10000+34680 and len(rec['rev'])==1 and rec['rev'][0]['c']==14862 and bb==10000,(rec['adj'],bb))
    pg.evaluate("ACT.rcvoid(S.recon[0].id)");pg.wait_for_timeout(200);pg.click('#ov [data-act=yes]');pg.wait_for_timeout(350)
    ok('14. Desfazer: ajuste deixa de valer, fica no histórico como desfeito e o saldo volta ao calculado pelos lançamentos',pg.evaluate("S.recon[0].void")==True and pg.evaluate("balance()")==pg.evaluate("balAsOf('2026-11-24')") and pg.evaluate("balance()")==-90290+15490*0+(-15490)+81100-10000,(pg.evaluate("balance()")))
    ok('14b. Validações: data futura, anterior ao saldo inicial e valor vazio são recusadas',conf(pg,'10,00','2026-12-31')!='' and conf(pg,'')!='' and pg.evaluate("S.recon.length")==1)
    # negativo legítimo e aviso
    load(pg,real());txt=pg.evaluate("(()=>{let o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()")
    ok('15. Saldo negativo legítimo (sem conferência): continua negativo e o aviso é "Seu saldo registrado está negativo. Confira suas movimentações."',pg.evaluate("balance()")==-90290 and 'Seu saldo registrado está negativo. Confira suas movimentações.' in txt and 'Seu saldo registrado está negativo' in pg.inner_text('#s-home .mqc'),txt[:2])
    load(pg,st([it('exp',15000,20)],{'c':10000,'d':'2026-01-01','note':''}));txt=pg.evaluate("(()=>{let o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()")
    ok('16. Saldo positivo e previsão negativa: "Você possui dinheiro disponível, mas seus próximos compromissos podem ultrapassar esse valor."',any(t=='Você possui dinheiro disponível, mas seus próximos compromissos podem ultrapassar esse valor.' for t in txt) and not any('registrado está negativo' in t for t in txt))
    load(pg,st([it('exp',3000,5),it('inc',90000,28)],{'c':50000,'d':'2026-01-01','note':''}));txt=pg.evaluate("(()=>{let o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()")
    ok('17. Contas atrasadas (sem saldo/previsão negativos): "Você possui compromissos atrasados que precisam de atenção."',any(t=='Você possui compromissos atrasados que precisam de atenção.' for t in txt),txt[:2])
    # mudança de mês
    load(pg,real());conf(pg,'148,62');pg.clock.set_fixed_time('2026-12-02T10:00:00-03:00');pg.evaluate("render()");pg.wait_for_timeout(250)
    ok('18. Mudança de mês (02/12): a conferência de novembro continua valendo e o saldo atual não muda; previsão passa a ser de dezembro',pg.evaluate("balance()")==14862 and pg.evaluate("prevSaldo().cm")=='2026-12' and pg.evaluate("prevSaldo().end")=='2026-12-31',(pg.evaluate("balance()"),pg.evaluate("prevSaldo().cm")))
    pg.clock.set_fixed_time(NOW)
    # backup e restauração
    load(pg,real());conf(pg,'148,62','2026-11-24','Banco');txtb=pg.evaluate("bkpExportText()");o=json.loads(txtb)
    chk=pg.evaluate("(t)=>{const o=JSON.parse(t);delete o.__backup;const c=bkpCheck(o);const m=migrate(JSON.parse(JSON.stringify(o)));const m2=migrate(JSON.parse(JSON.stringify(m)));return {E:c.E,n:m.recon.length,n2:m2.recon.length,bal:(()=>{const keep=S;S=m2;const b=balance();S=keep;return b})()}}",txtb)
    ok('19. Backup exportado inclui as conferências; restaurar/importar valida, mantém 1 registro (sem duplicar, mesmo importando duas vezes) e o mesmo saldo (148,62)',len(o['recon'])==1 and chk['E']==[] and chk['n']==1 and chk['n2']==1 and chk['bal']==14862,chk)
    old=json.loads(json.dumps(real()));
    chk=pg.evaluate("(t)=>{const m=migrate(JSON.parse(t));return {n:m.recon.length,E:bkpCheck(JSON.parse(t)).E}}",json.dumps(old))
    ok('20. Backup antigo (sem conferências) importa normalmente e ganha histórico vazio, sem alterar o saldo calculado',chk['n']==0 and chk['E']==[])
    bad=json.loads(txtb);bad['recon'][0]['adj']='x';del bad['__backup']
    ok('21. Histórico de conferências danificado no arquivo é recusado com mensagem clara',len(pg.evaluate("(o)=>bkpCheck(o).E",bad))>=1)
    # recarregar PWA
    load(pg,real());conf(pg,'148,62');pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
    ok('22. Recarregar a PWA: conferência e saldo (R$ 148,62) permanecem',pg.evaluate("S.recon.length")==1 and pg.evaluate("balance()")==14862)
    # relatórios
    pg.evaluate("VIEWS.rel[2]=()=>'<h2>Relatórios</h2>'+['sit','mes','comp','cat','rec','hm','div','cmp','ano','shr'].map(rptBody).join('');go('rel')");pg.wait_for_timeout(400);rt=pg.inner_text('#s-rel')
    ok('23. Relatórios: receitas/despesas do mês iguais às de antes da conferência e linha própria "Ajuste de conferência do saldo (não é receita nem despesa)"',pg.evaluate("relFlow('2026-11').inc")==81100 and pg.evaluate("relFlow('2026-11').exp")==76390+0 and 'Ajuste de conferência do saldo' in rt,pg.evaluate("[relFlow('2026-11').inc,relFlow('2026-11').exp,relFlow('2026-11').fin]"))
    ok('23b. Saldo final do mês no relatório = saldo atual da Home',pg.evaluate("relFlow('2026-11').fin")==pg.evaluate("balance()"))
    ok('24. Sem erros de JavaScript',not pg.errs,pg.errs[:3]);c.close()
    # mascote ativado/desativado
    c,pg=page();load(pg,real())
    pg.evaluate("S.pref.wf=Object.assign({on:1},S.pref.wf,{on:1});save();go('home')");pg.wait_for_timeout(500)
    ok('25. Mascote ativado: personagem no cartão de dicas, busto, e tocar nele abre a Loja',pg.locator('#s-home .mqc .mqw,#s-home .mqc canvas,#s-home .mqc .wolf').count()>=1 and pg.locator('#s-home .mqb[data-id=loja]').count()==1 and (pg.click('#s-home .mqb[data-id=loja]'),pg.wait_for_timeout(400),pg.evaluate("view"))[2]=='loja')
    ok('25b. Loja continua com a chave "Mostrar o Wolfin"',pg.locator('#s-loja [data-act=wfon]').count()==1)
    pg.evaluate("S.pref.wf.on=0;save();go('home')");pg.wait_for_timeout(500)
    ge=pg.evaluate("(()=>{const c=document.querySelector('#s-home .mqc'),r=c.getBoundingClientRect(),t=c.querySelector('.mt').getBoundingClientRect();return {wolf:c.querySelectorAll('.mqw,.wolf,canvas,img').length,loja:document.querySelectorAll('#s-home [data-act=nav][data-id=loja]').length,shop:document.querySelectorAll('.mqshop,.mqo').length,fix:[...document.querySelectorAll('#s-home button,#s-home a')].filter(e=>getComputedStyle(e).position==='fixed'||getComputedStyle(e).position==='absolute'&&e.closest('.mqc')).length,h:r.height,tw:t.width,cw:r.width,left:t.left-r.left}})()")
    ok('26. Mascote desativado: sem personagem, sem botão da Loja, sem ícone flutuante (.mqshop/.mqo não existem); o texto ocupa a largura do cartão',ge['wolf']==0 and ge['loja']==0 and ge['shop']==0 and ge['fix']==0 and ge['tw']/ge['cw']>.6,ge)
    ok('26b. O cartão de dicas continua funcionando (texto presente) e sem espaço vazio (altura ≤ 110px)',len(pg.inner_text('#s-home .mqc').strip())>10 and ge['h']<=110,ge['h'])
    pg.evaluate("go('cfg',{cat:'mascote'})");pg.wait_for_timeout(400);cw=pg.inner_text('#cs-wolf') if pg.locator('#cs-wolf').count() else ''
    ok('27. Configurações: seção "Wolfin, o mascote" com ligar/desligar e acesso à Loja; sem "Jeito de falar"',all(x in cw for x in ('Wolfin, o mascote','Mostrar o Wolfin na Home','Desligado','Abrir a Loja do Wolfin')) and 'Jeito de falar' not in pg.inner_text('#s-cfg'),cw[:120])
    wc0=pg.evaluate("JSON.stringify([S.wc,S.pref.wf&&S.pref.wf.own])");pg.click('#cs-wolf [data-act=wfon]');pg.wait_for_timeout(300)
    ok('28. Reativar pelas Configurações: Home volta a mostrar o Wolfin; WolfCoins e personagens desbloqueados intactos',pg.evaluate("S.pref.wf.on")==1 and pg.evaluate("JSON.stringify([S.wc,S.pref.wf&&S.pref.wf.own])")==wc0 and pg.locator('#cs-wolf [data-act=wfon]').inner_text()=='Ligado')
    pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
    ok('29. A preferência persiste após atualizar a página',pg.evaluate("S.pref.wf.on")==1)
    pg.evaluate("go('cfg',{cat:'mascote'})");pg.wait_for_timeout(300);pg.click('#cs-wolf [data-act=wfon]');pg.wait_for_timeout(300);pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
    ok('29b. Desligado também persiste após atualizar',pg.evaluate("S.pref.wf.on")==0)
    pg.evaluate("go('cfg',{cat:'mascote'})");pg.wait_for_timeout(300);pg.click('#cs-wolf [data-act=nav][data-id=loja]');pg.wait_for_timeout(400)
    ok('30. Acesso à Loja pelas Configurações',pg.evaluate("view")=='loja')
    ok('31. Sem erros',not pg.errs,pg.errs[:3]);c.close()
    # telas pequenas
    for w,h in ((320,640),(360,740),(393,851)):
        c,pg=page(w,h);load(pg,real());conf(pg,'148,62','2026-11-24','Banco')
        pg.evaluate("S.pref.wf=Object.assign({},S.pref.wf,{on:1});save();go('home')");pg.wait_for_timeout(400)
        pg.click('#s-home .hero .hdet summary');pg.wait_for_timeout(300)
        g=pg.evaluate("""()=>{const r=e=>e.getBoundingClientRect(),hero=document.querySelector('#s-home .hero'),hr=r(hero),nx=r(document.querySelector('#s-home .mqc')),out=[...document.querySelectorAll('#s-home .hero *')].filter(e=>r(e).right>innerWidth+.5||r(e).left<-.5).length;
          return {ov:document.documentElement.scrollWidth>innerWidth,out,gap:nx.top-hr.bottom,clip:[...document.querySelectorAll('#s-home .hero .pill b,#s-home .hero .hprev b,#s-home .hero .big')].filter(e=>e.scrollWidth>e.clientWidth+1).length}}""")
        pg.evaluate("window.scrollTo(0,document.body.scrollHeight)");pg.wait_for_timeout(300)
        nv=pg.evaluate("""()=>{const n=document.getElementById('nav').getBoundingClientRect().top,f=document.getElementById('cfab').getBoundingClientRect().top,l=[...document.querySelectorAll('#s-home > *')].filter(e=>e.getBoundingClientRect().height>0).pop().getBoundingClientRect().bottom;return l<=Math.min(n,f)+2}""")
        ok(f'32. {w}px: cartão com detalhes abertos e histórico sem rolagem horizontal, sem texto cortado, sem sobreposição com o próximo cartão; fim da página livre da navegação',(not g['ov']) and g['out']==0 and g['clip']==0 and g['gap']>=0 and nv,g)
        c.close()
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
