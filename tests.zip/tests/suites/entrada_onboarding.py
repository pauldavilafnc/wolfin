"""Entrada do Wolfin (v7.25): tela inicial (Começar) → aparência → nome → senha. Um único olho mostra/oculta a senha e a repetição.
ENTRAR visível na tela inicial e na aparência; preferências preservadas. Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:230] if d else ''),flush=True)
FORM="Senha-Forte-123"
with sync_playwright() as p:
    b=p.chromium.launch()
    ba=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    bb=p.chromium.launch(args=['--autoplay-policy=document-user-activation-required'])
    def ctx(w=393,h=851,br=None,reduce=False,intro=False,**k):
        c=(br or b).new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,reduced_motion='reduce' if reduce else 'no-preference',**k)
        c.add_init_script("window.__WS_NOCSP=1")
        if not intro:c.add_init_script("window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        return c,pg
    hid=lambda pg:pg.evaluate("document.getElementById('lock').hidden")
    html=open(os.path.join(ROOT,'index.html'),encoding='utf-8').read()
    m=re.search(r"BUILD='([^']{3,90})'",html);mm=re.search(r"const KEY='wallstreet.v1',BUILD='([^']*)'",html)
    ok('Versão (BUILD) cabe na verificação de atualização (≤ 90 caracteres) — senão aparece "Nova versão disponível" sempre',bool(m) and bool(mm) and m.group(1)==mm.group(1),(len(mm.group(1)) if mm else None))
    # ===== 1. intro em vídeo e depois a etapa 1 =====
    c,pg=ctx(br=ba,intro=True);pg.goto(URL);pg.wait_for_function("!document.getElementById('intro')",timeout=15000);pg.wait_for_selector('[data-lk=new]')
    ok('1. Depois da intro em vídeo aparece a tela inicial (Começar); a intro some do código da página',pg.locator('[data-lk=new]').is_visible() and pg.locator('#intro').count()==0 and pg.locator('#introv').count()==0 and pg.locator('#intsnd').count()==0)
    ok('1. Não há erros no console',not pg.errs,pg.errs[:3]);c.close()
    # ===== 3. etapa 1: aparência (sem mascote) =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=new]')
    ok('3. Tela inicial: "Oi, eu sou Wolfin!" com o Wolfin e sem o mascote antigo',pg.locator('#lock h2').first.inner_text()=='Oi, eu sou Wolfin!' and pg.locator('#lock .wolf').count()==1 and pg.locator('#lock .mc,#mf').count()==0)
    ok('3. Tela inicial sem contador de etapas, com botão Começar',pg.locator('.obdots').count()==0 and pg.locator('[data-lk=new]').inner_text()=='Começar')
    # ===== 6. ENTRAR nas 2 etapas =====
    def enter_ok(tag):
        e=pg.locator('#lock [data-lk=enter]');e.scroll_into_view_if_needed();pg.wait_for_timeout(150)
        bx=e.bounding_box();vp=pg.viewport_size
        st=pg.evaluate("(()=>{const e=document.querySelector('#lock [data-lk=enter]'),cs=getComputedStyle(e),p=e.parentElement,pb=document.querySelector('#lock .lk .b1:not([data-lk=cmode]):not([data-lk=theme])');return{pos:cs.position,td:cs.textDecorationLine,bg:cs.backgroundColor,bw:cs.borderTopWidth,par:p.textContent.trim(),abaixo:!pb||pb.getBoundingClientRect().top<e.getBoundingClientRect().top,fixoPai:getComputedStyle(p).position}})()")
        link=e.count()==1 and e.is_visible() and e.inner_text().strip()=='Entrar' and st['par']=='Já tem conta? Entrar' and 'underline' in st['td'] and st['bg']=='rgba(0, 0, 0, 0)' and st['bw']=='0px' and st['pos']!='fixed' and st['fixoPai']!='fixed' and bx['height']>=40 and bx['width']<120
        ok(f'6. "Já tem conta? Entrar" na {tag}: link de texto sublinhado (sem fundo/borda/botão), centralizado e abaixo da ação principal',link and abs((bx['x']+bx['width']/2)-vp['width']/2)<60 and st['abaixo'],(bx,st))
    enter_ok('tela inicial')
    pg.click('[data-lk=new]');pg.wait_for_selector('#cf');enter_ok('etapa 1 (aparência)')
    # ===== 4. etapa 2 =====
    ok('4. Etapa 1 de 3, com claro/escuro, 9 cores compatíveis e prévia',pg.locator('.obdots[aria-label="Etapa 1 de 3"]').count()==1 and pg.locator('#cf [data-lk=cmode]').count()==2 and pg.locator('#cf .pal').count()==9 and pg.locator('#cf .obpv').count()==1)
    ok('4. A cor padrão continua Azul',pg.evaluate("S.pref.pal")=='blue' and pg.locator('#cf .pal.on').get_attribute('data-id')=='blue')
    c1=pg.evaluate("getComputedStyle(document.querySelector('.obpvh')).backgroundImage")
    pg.click('#cf [data-lk=cpick][data-id=violet]');pg.wait_for_timeout(350)
    c2=pg.evaluate("getComputedStyle(document.querySelector('.obpvh')).backgroundImage")
    ok('4. Escolher a cor muda a prévia e o app na hora',c1!=c2 and pg.evaluate("document.documentElement.dataset.pal")=='violet')
    pg.click('#cf [data-lk=cmode][data-id=dark]');pg.wait_for_timeout(350)
    ok('4. Escolher o tema escuro aplica na hora',pg.evaluate("document.documentElement.dataset.theme")=='dark' and pg.locator('#cf [data-lk=cmode][data-id=dark]').get_attribute('aria-pressed')=='true')
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('#nf')
    ok('5. Nome é a etapa 2 de 3',pg.locator('.obdots[aria-label="Etapa 2 de 3"]').count()==1 and pg.locator('#nf').count()==1)
    # voltar mantém escolhas
    pg.click('[data-lk=backcolor]');pg.wait_for_selector('#cf');ok('Voltar do nome à aparência mantém violeta/escuro',pg.evaluate("S.pref.pal")=='violet' and pg.evaluate("S.pref.theme")=='dark')
    pg.click('[data-lk=backwelcome]');pg.wait_for_selector('[data-lk=new]');pg.click('[data-lk=new]');pg.wait_for_selector('#cf');pg.click('#cf button:not([type=button])');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]','Ana Maria');pg.click('#nf .b1');pg.wait_for_selector('#sf')
    ok('4. Depois do nome: criação de acesso (etapa 3 de 3), sem pedir mascote/cor de novo',pg.locator('#mf,#cf').count()==0 and pg.locator('.obdots[aria-label="Etapa 3 de 3"]').count()==1 and pg.input_value('#sf [name=u]')=='ana')
    # ===== 9. senhas independentes =====
    pg.fill('#sf [name=p]',FORM);pg.fill('#sf [name=c]',FORM)
    tp=lambda:pg.evaluate("[...document.querySelectorAll('#sf input[name=p],#sf input[name=c]')].map(i=>i.type)")
    ok('9. Começa com as duas senhas ocultas e um único olho',tp()==['password','password'] and pg.locator('#sf .eyl').count()==1)
    pg.click('#sf .eyl');ok('9. O olho único mostra senha e repetição juntas',tp()==['text','text'])
    ok('9. Criar acesso não tem mascote (só ícone de vidro)',pg.locator('#lock .wolf').count()==0 and pg.locator('#lock .obic').count()==1)
    pg.click('#sf .eyl');ok('9. Clicar de novo oculta as duas',tp()==['password','password'])
    nm=pg.evaluate("[...document.querySelectorAll('#sf .eyl')].map(e=>e.getAttribute('aria-label')+'|'+e.getAttribute('aria-pressed'))")
    ok('9. O olho tem nome acessível e estado (aria-pressed)',len(nm)==1 and nm[0].split('|')[0]!='' and nm[0].endswith('|false'),nm)
    # ===== 10. preferências preservadas =====
    pg.click('#sf .b1');pg.wait_for_selector('#skcode',timeout=20000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000);pg.wait_for_timeout(1500)
    s=pg.evaluate("({pal:S.pref.pal,th:S.pref.theme,o:S.owner,tour:!!document.querySelector('#tour')})")
    ok('10. Conta criada: cor, tema e nome salvos',s['pal']=='violet' and s['th']=='dark' and s['o']=='Ana Maria',s)
    ok('10. O avatar do app mostra a inicial do nome (sem foto)',pg.evaluate("document.querySelector('#avh').innerText.trim()")=='A')
    pg.reload();pg.wait_for_selector('#lf')
    ok('10. Ao reabrir: vai direto ao login (sem repetir o onboarding), já no tema/cor escolhidos',pg.locator('#mf,#cf,[data-lk=new]').count()==0 and pg.evaluate("document.documentElement.dataset.pal")=='violet' and pg.evaluate("document.documentElement.dataset.theme")=='dark')
    ok('8. O login mostra o olho na senha',pg.locator('#lf .eyl').count()==1)
    pg.fill('#lf [name=p]',FORM);pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000)
    ok('8. Conta existente entra normalmente e mantém as preferências',pg.evaluate("S.pref.pal+S.pref.theme")=='violetdark')
    ok('Sem erros no console (criar conta)',not pg.errs,pg.errs[:3]);c.close()
    # ===== 7. ENTRAR leva à autenticação =====
    for etapa in (1,2):
        c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=new]')
        if etapa>=2:pg.click('[data-lk=new]');pg.wait_for_selector('#cf')
        pg.click('#lock [data-lk=enter]');pg.wait_for_selector('[data-lk=pickbk]')
        ok(f'7. ENTRAR na etapa {etapa} leva direto à tela de entrada (conta existente), sem passar pelas outras',pg.locator('#mf,#cf,[data-lk=new]').count()==0 and 'Entrar na sua conta' in pg.inner_text('#lock'))
        pg.click('[data-lk=backob]');pg.wait_for_selector('[data-lk=new],#cf')
        ok(f'7. Voltar de ENTRAR retorna à etapa {etapa}',(pg.locator('[data-lk=new]').count()==1) if etapa==1 else (pg.locator('#cf').count()==1));c.close()
    # usuário que já tem conta (dados protegidos) nunca vê o onboarding
    c,pg=ctx();pg.goto(URL);OB_TO_SETUP(pg,'Bia');pg.fill('#sf [name=p]',FORM);pg.fill('#sf [name=c]',FORM);pg.click('#sf .b1');pg.wait_for_selector('#skcode',timeout=20000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000)
    st=c.storage_state();c.close()
    c2=b.new_context(viewport={'width':393,'height':851},is_mobile=True,storage_state=st);c2.add_init_script("window.__WS_NOCSP=1");pg=c2.new_page();pg.goto(URL);pg.wait_for_selector('#lf')
    ok('8. Quem já tem conta cai no login, sem etapas de boas-vindas nem ENTRAR',pg.locator('.obdots,[data-lk=enter],#cf').count()==0);c2.close()
    # recuperação de senha também tem olho nos dois campos
    c,pg=ctx();pg.goto(URL);OB_TO_SETUP(pg,'Bia');pg.fill('#sf [name=p]',FORM);pg.fill('#sf [name=c]',FORM);pg.click('#sf .b1');pg.wait_for_selector('#skcode',timeout=20000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000)
    pg.evaluate("lockNow()");pg.wait_for_selector('#lf');pg.click('[data-lk=rec]');pg.wait_for_selector('#rf')
    ok('9. Recuperar acesso: "Nova senha" e "Repita a nova senha" compartilham um único olho',pg.locator('#rf .eyl').count()==1);c.close()
    # ===== 11/12. temas claro/escuro e celulares =====
    for th in ('light','dark'):
        for w,h in ((393,851),(320,568),(360,640),(851,393),(1280,800)):
            c,pg=ctx(w,h);pg.goto(URL);pg.wait_for_selector('[data-lk=new]');pg.evaluate(f"S.pref.theme='{th}';applyPref()")
            for et in (1,2):
                if et==2:pg.click('[data-lk=new]');pg.wait_for_selector('#cf')
                pg.wait_for_timeout(700)
                r=pg.evaluate("""(()=>{const L=document.getElementById('lock');document.querySelector('[data-lk=enter]').scrollIntoView({block:'center'});const e=document.querySelector('[data-lk=enter]').getBoundingClientRect(),cs=[...L.querySelectorAll('button:not([hidden]),input')].filter(x=>x.getBoundingClientRect().width>0);
                  const ct=document.querySelector('.lk .b1:not([data-lk=cmode])');
                  return{sx:document.documentElement.scrollWidth>document.documentElement.clientWidth+1||L.scrollWidth>L.clientWidth+1,enterDentro:e.bottom<=innerHeight+1&&e.top>=0&&e.left>=0&&e.right<=innerWidth,small:cs.filter(x=>{const r=x.getBoundingClientRect();return r.height<40}).length}})()""")
                ok(f'11/12. {th} {w}x{h} etapa {et}: sem rolagem lateral, link "Entrar" alcançável dentro da tela e alvos ≥ 40 px',not r['sx'] and r['enterDentro'] and r['small']==0,r)
            c.close()
    # ===== 13. offline / PWA =====
    c,pg=ctx(service_workers='allow');pg.goto(URL);pg.wait_for_selector('[data-lk=new]');pg.evaluate("navigator.serviceWorker.ready.then(()=>1)");pg.wait_for_timeout(2500)
    c.set_offline(True);pg.reload();pg.wait_for_selector('[data-lk=new]',timeout=15000)
    ok('13. Offline (com o service worker ativo): a tela inicial continua funcionando, com o Wolfin',pg.locator('#lock [data-lk=enter]').is_visible() and pg.locator('#lock .wolf').count()==1)
    pg.click('[data-lk=new]');pg.wait_for_selector('#cf');ok('13. Offline: avança entre as etapas',pg.locator('#cf .pal').count()==9);c.close()
    # ===== não toca em dados =====
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('[data-lk=new]')
    ok('Nada é gravado antes de concluir o cadastro (as escolhas só vão para a conta no fim)',pg.evaluate("localStorage.getItem('wallstreet.v1')")is None and pg.evaluate("localStorage.getItem('wallstreet.sec')")is None);c.close()
    for x in (b,ba,bb):x.close()
print(sum(R),'/',len(R))
