"""v7.21: Ajustes sai da barra (6 abas) e passa a abrir pelo menu da foto de perfil. Dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json
os.environ['NOSKIP']='1'
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
JPG="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA="
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light',pal=None,extra='',rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,reduced_motion='reduce' if rm else 'no-preference',timezone_id='America/Sao_Paulo')
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};"+extra+"S.pref.theme='%s';"%th+("S.pref.pal='%s';"%pal if pal else '')+"save();applyPref();go('home')");pg.wait_for_timeout(500);return c,pg
    opn=lambda pg,sel='#avh':(pg.click(sel),pg.wait_for_selector('#pm.on'),pg.wait_for_timeout(250))
    # A. barra
    c,pg=app()
    lab=pg.evaluate("[...document.querySelectorAll('#nav button')].map(b=>b.innerText.trim())")
    ok('A. A barra inferior tem exatamente 6 abas, na ordem Home, Receitas, Despesas, Dívidas, Caixinhas, Relat. — sem Ajustes',lab==['Home','Receitas','Despesas','Dívidas','Caixinhas','Relat.'] and pg.locator('#nav [data-id=cfg]').count()==0,lab)
    ws=pg.evaluate("[...document.querySelectorAll('#nav button')].map(b=>Math.round(b.getBoundingClientRect().width))")
    ok('A. As 6 abas ficam distribuídas por igual',max(ws)-min(ws)<=1,ws)
    okn=True
    for v in ['rec','des','div','cx','rel','home']:
        pg.click(f'#nav button[data-id={v}]');pg.wait_for_timeout(150);okn=okn and pg.evaluate("view")==v and pg.evaluate("document.querySelector('#nav button.on').dataset.id")==v
    ok('A. Todas as abas continuam funcionando e destacam a aba atual',okn)
    c.close()
    # B. abrir/fechar
    c,pg=app();S0=pg.evaluate("JSON.stringify(S)")
    ok('B. O avatar é um botão com aria-haspopup="menu" e aria-expanded="false"',pg.evaluate("(()=>{const a=document.getElementById('avh');return a.tagName==='BUTTON'&&a.getAttribute('aria-haspopup')==='menu'&&a.getAttribute('aria-expanded')==='false'})()"))
    opn(pg)
    ok('B. Tocar na foto abre o menu (role=menu) com aria-expanded="true"',pg.evaluate("document.getElementById('avh').getAttribute('aria-expanded')")=='true' and pg.locator('#pm [role=menu]').count()==1 and pg.is_visible('#pm .pmp'))
    items=pg.evaluate("[...document.querySelectorAll('#pm .pml .pmi')].map(b=>b.innerText.trim())");ft=pg.evaluate("[...document.querySelectorAll('#pm .pmf .pmi')].map(b=>b.innerText.trim())")
    ok('B. Opções: Meu perfil, Configurações, Aparência e temas, Privacidade e segurança, Backups',items==['Meu perfil','Configurações','Aparência e temas','Privacidade e segurança','Backups'],items)
    hd=pg.inner_text('#pm .pmh');ok('B. Cabeçalho mostra a foto/avatar, o nome e a informação da conta',pg.locator('#pm .pmh .pmav').count()==1 and 'Dados só neste aparelho' in hd and len(pg.inner_text('#pm .pmn b'))>0,hd)
    ok('B. Rodapé (sem senha ativada): "Ativar proteção por senha" no lugar de Sair',ft==['Ativar proteção por senha'],ft)
    ok('B. Todos os itens têm ≥ 44 px e ícone',pg.evaluate("[...document.querySelectorAll('#pm .pmi')].every(b=>b.getBoundingClientRect().height>=44&&b.querySelector('.pmic svg'))"))
    ok('B. O menu fica por cima da barra e do botão flutuante',pg.evaluate("(()=>{const r=document.querySelector('#pm .pmf .pmi').getBoundingClientRect();const e=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return !!e.closest('#pm')})()"))
    pg.mouse.click(8,pg.evaluate("innerHeight")-8);pg.wait_for_timeout(400)
    ok('B. Tocar fora do menu fecha (e o foco volta ao avatar)',pg.evaluate("document.getElementById('pm').hidden")and pg.evaluate("document.activeElement.id")=='avh' and pg.evaluate("document.getElementById('avh').getAttribute('aria-expanded')")=='false')
    opn(pg);pg.keyboard.press('Escape');pg.wait_for_timeout(400);ok('B. Esc fecha o menu',pg.evaluate("document.getElementById('pm').hidden"))
    opn(pg);pg.go_back();pg.wait_for_timeout(500)
    ok('B. Botão Voltar do Android (popstate) fecha o menu e continua na Home',pg.evaluate("document.getElementById('pm').hidden")and pg.evaluate("view")=='home' and pg.url.endswith('index.html'),pg.url)
    opn(pg);pg.keyboard.press('ArrowDown');ok('B. Setas navegam entre as opções',pg.evaluate("document.activeElement.classList.contains('pmi')"))
    pg.keyboard.press('Escape');pg.wait_for_timeout(400)
    ok('B. Abrir e fechar não altera nenhum dado',pg.evaluate("JSON.stringify(S)")==S0)
    opn(pg);pg.click('#pm .pmi >> nth=1');pg.wait_for_timeout(700)
    ok('B. Depois de escolher uma opção, o menu fecha, abre Ajustes e a entrada do menu sai do histórico',pg.evaluate("document.getElementById('pm').hidden") and pg.evaluate("view")=='cfg' and pg.evaluate("!(history.state&&history.state.pm)"))
    c.close()
    # C. todas as telas principais, vários tamanhos e temas
    for w,h in((320,568),(393,851),(768,1024)):
        for th in('light','dark'):
            c,pg=app(w,h,th,extra="S.owner='Maria Aparecida de Nazaré Albuquerque Montenegro';");bad=[]
            for v in ['rec','des','div','cx','rel']:
                pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
                if pg.locator('.avfl').count()!=0 or pg.locator('#avh').is_visible():bad.append(v+':avatar fora da Home')
            for v in ['home']:
                pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250);sel='#avh'
                r=pg.evaluate(f"(()=>{{const a=document.querySelector('{sel}').getBoundingClientRect();return[a.width,a.height]}})()")
                opn(pg,sel)
                g=pg.evaluate("""()=>{const p=document.querySelector('#pm .pmp').getBoundingClientRect(),e=document.querySelector('#pm .pmp');return{l:p.left,t:p.top,r:p.right,b:p.bottom,vw:innerWidth,vh:innerHeight,sx:e.scrollWidth>e.clientWidth+1,sx2:document.documentElement.scrollWidth>innerWidth,nm:(n=>n.scrollWidth<=n.clientWidth||getComputedStyle(n).textOverflow==='ellipsis')(document.querySelector('#pm .pmn b'))}}""")
                if not(g['l']>=0 and g['r']<=g['vw'] and g['t']>=0 and g['b']<=g['vh']+1 and not g['sx'] and not g['sx2'] and g['nm']):bad.append((v,g))
                if min(r)<43.5:bad.append((v,'avatar pequeno',r))
                pg.keyboard.press('Escape');pg.wait_for_timeout(350)
            ok(f'C. {w}x{h} {th}: avatar abre o menu só na Home (nenhum avatar nas outras abas); menu inteiro na tela, sem rolagem lateral, nome longo cortado com reticências',not bad and not pg.errs,bad or pg.errs);c.close()
    # D. destinos
    c,pg=app(393,851,'dark')
    G=lambda: pg.evaluate("(id=>{const e=document.getElementById(id).getBoundingClientRect();return e.top>=-2&&e.top<innerHeight*.6})")
    exp={'own':'cs-own','apa':'cs-apa','sec':'cs-sec','bkp':'cs-bkp'}
    for sec,idn in exp.items():
        pg.evaluate("go('home')");pg.wait_for_timeout(200);opn(pg);pg.click(f'#pm [data-id={sec}]');pg.wait_for_timeout(700)
        vis=pg.evaluate(f"(()=>{{const e=document.getElementById('{idn}').getBoundingClientRect();return e.top>=-2&&e.top<innerHeight*.7&&view==='cfg'}})()")
        ok(f'D. "{sec}" abre Ajustes direto no cartão certo ({idn}) sem página duplicada',vis and pg.evaluate("document.getElementById('pm').hidden"))
    ok('D. "Aparência e temas" deixa as paletas visíveis',pg.evaluate("(()=>{go('home');return 1})()") and (opn(pg),pg.click('#pm [data-id=apa]'),pg.wait_for_timeout(1000))and pg.locator('#s-cfg .pals').is_visible())
    pg.evaluate("go('home')");pg.wait_for_timeout(200);opn(pg);pg.click('#pm [data-id=cfg]');pg.wait_for_timeout(500)
    h3=pg.evaluate("[...document.querySelectorAll('#s-cfg h3')].map(h=>h.textContent.replace(/Protegido/,'').trim())");lb=pg.inner_text('#s-cfg')
    ok('D. "Configurações" abre a tela completa de Ajustes com todos os cartões (nada se perdeu)',all(x in h3 for x in['Backup','Segurança','Aparência','Conquistas','Zerar todos os dados','Sobre']) and 'Nome do proprietário' in lb,h3)
    ok('D. Em Ajustes, o botão de Backup (exportar/importar), tema claro/escuro e paletas continuam',pg.locator('#s-cfg [data-act=exp]').count()==1 and pg.locator('#s-cfg [data-act=imp]').count()==1 and pg.locator('#s-cfg [data-act=theme]').count()==2 and pg.locator('#s-cfg [data-act=pal]').count()>=5)
    pg.evaluate("go('home')");pg.wait_for_timeout(200);opn(pg);pg.click('#pm [data-id=foto]');pg.wait_for_selector('#ov .avs');pg.wait_for_timeout(350);ok('D. Tocar na foto dentro do menu abre o seletor de foto',pg.locator('#ov .avs').count()==1 and pg.evaluate("document.getElementById('pm').hidden"));pg.evaluate("closeOv()")
    pg.evaluate("go('home')");pg.wait_for_timeout(200);opn(pg);pg.click('#pm [data-id=secon]');pg.wait_for_timeout(400);ok('D. "Ativar proteção por senha" abre a criação de acesso existente',pg.locator('#sf').count()==1);c.close()
    # E. foto e nome
    c,pg=app(extra=f"S.owner='Ana Souza';S.pref.ph='{JPG}';");opn(pg)
    ok('E. A foto do usuário aparece no avatar da Home e no cabeçalho do menu; o nome é exibido',pg.locator('#avh img').count()==1 and pg.locator('#pm .pmav img').count()==1 and 'Ana Souza' in pg.inner_text('#pm .pmn'));c.close()
    # F. temas/paletas: contraste
    JSC="""()=>{const L=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};
     const bg=getComputedStyle(document.querySelector('#pm .pmp')).backgroundColor,out=[];const lb=L(bg);
     document.querySelectorAll('#pm .pmt,#pm .pmn b,#pm .pmn span').forEach(e=>{const l=L(getComputedStyle(e).color);out.push(+(((Math.max(l,lb)+.05)/(Math.min(l,lb)+.05)).toFixed(2)))});return{bg,min:Math.min(...out)}}"""
    for pal in('azul','violet','teal','ouro','grafite'):
        for th in('light','dark'):
            c,pg=app(393,851,th,pal);opn(pg);r=pg.evaluate(JSC)
            ok(f'F. Tema {pal}/{th}: textos do menu com contraste ≥ 4.5:1',r['min']>=4.5 and not pg.errs,r);c.close()
    # G. movimento reduzido
    c,pg=app(rm=True);opn(pg);ok('G. Movimento reduzido: o menu abre e fecha sem transição',pg.evaluate("getComputedStyle(document.querySelector('#pm .pmp')).transitionDuration")in('0s','0s, 0s'));pg.keyboard.press('Escape');pg.wait_for_timeout(100);ok('G. Movimento reduzido: fecha na hora',pg.evaluate("document.getElementById('pm').hidden"));c.close()
    # H. sair da conta (conta protegida) e ativação
    c,pg=app();pg.evaluate("go('home')");opn(pg);pg.click('#pm [data-id=secon]');pg.wait_for_selector('#sf')
    pg.fill('#sf [name=u]','paul');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=20000)
    pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000);pg.wait_for_timeout(1500)
    bal=pg.evaluate("balance()");opn(pg);ft=pg.evaluate("[...document.querySelectorAll('#pm .pmf .pmi')].map(b=>b.innerText.trim())");inf=pg.inner_text('#pm .pmn')
    ok('H. Com senha ativada: o rodapé mostra "Sair da conta" e o cabeçalho informa a proteção e o usuário',ft==['Sair da conta'] and 'Protegido por senha' in inf and 'paul' in inf,(ft,inf))
    pg.click('#pm [data-id=lock]');pg.wait_for_selector('#lf',timeout=15000);pg.wait_for_timeout(500)
    ok('H. "Sair da conta" executa o bloqueio existente: aparece o login e nenhum dado financeiro fica visível',not pg.evaluate("document.getElementById('lock').hidden") and 'R$' not in pg.evaluate("document.getElementById('main').innerText.slice(0,0)+document.getElementById('lock').innerText"))
    pg.fill('#lf [name=u]','paul');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=20000);pg.wait_for_timeout(1200)
    ok('H. Entrando de novo, os dados continuam os mesmos (saldo igual)',pg.evaluate("balance()")==bal and not pg.errs,(bal,pg.errs));c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
