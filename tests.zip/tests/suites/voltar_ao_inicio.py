"""v7.37: Ajustes → "Voltar ao início": apaga TUDO deste aparelho e o app reabre na tela de boas-vindas. Só dados fictícios."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,tempfile
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1")
    pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    pg.goto(HTTP_URL);OB_NOSEC(pg,'Maria Teste');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500)
    pg.evaluate("S.items.push({id:'a1',t:'exp',d:'Teste',c:5000,day:5,fixed:false,ym:'2026-11',cat:'Outros',pay:'Pix'});S.pref.wf=Object.assign({},S.pref.wf,{on:0});S.wc=Object.assign({},S.wc,{n:777});save();localStorage.setItem('wallstreet.look','{\"t\":\"light\"}');localStorage.setItem('wallstreet.sec','{\"fake\":1}');go('cfg')");pg.wait_for_timeout(400)
    txt=pg.evaluate("bkpExportText()")
    ok('1. Ajustes mostra "Zerar todos os dados" (como antes) e o novo "Voltar ao início", em cartões separados',pg.locator('#s-cfg [data-act=reset]').count()==1 and pg.locator('#s-cfg #cs-fresh [data-act=fresh]').count()==1)
    pg.click('#cs-fresh [data-act=fresh]');pg.wait_for_selector('#f');pg.fill('#f input','apagar');pg.click('#f button[type=submit]');pg.wait_for_timeout(400)
    ok('2. Confirmação errada é recusada com mensagem e NADA é apagado',('APAGAR TUDO' in pg.inner_text('#er')) and pg.evaluate("S.items.length")>=1 and pg.evaluate("localStorage.getItem('wallstreet.v1')")!=None)
    pg.fill('#f input','APAGAR TUDO')
    with pg.expect_navigation(): pg.click('#f button[type=submit]')
    pg.wait_for_timeout(1200)
    keys=pg.evaluate("Object.keys(localStorage).filter(k=>k.indexOf('wallstreet.')===0)")
    ok('3. Depois de confirmar: página recarrega e todos os dados do app (nome, tema, senha, mascote, moedas) sumiram do aparelho',not any(k in keys for k in ('wallstreet.sec','wallstreet.secskip','wallstreet.welcomed')) and pg.evaluate("localStorage.getItem('wallstreet.look')")!='{"t":"light"}' and (pg.evaluate("localStorage.getItem('wallstreet.v1')") in (None,) or 'a1' not in pg.evaluate("localStorage.getItem('wallstreet.v1')")),keys)
    vis=pg.evaluate("(()=>{const l=document.getElementById('lock');return !l.hidden})()")
    ok('4. O app abre na tela inicial de boas-vindas (como na primeira vez), sem nome nem lançamentos',vis and 'Oi, eu sou Wolfin' in pg.inner_text('#lock') and pg.evaluate("S.owner")!='Maria Teste' and pg.evaluate("S.items.length")==0 and pg.evaluate("document.documentElement.dataset.theme")!='light',pg.inner_text('#lock')[:80])
    ok('5. Sem erros de JavaScript',not pg.errs,pg.errs[:2])
    # recomeça do zero e restaura o backup salvo
    OB_NOSEC_AGAIN=None
    pg.evaluate("localStorage.clear()");pg.reload();OB_NOSEC(pg,'Outra Pessoa');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500)
    ok('6. Recomeço limpo: o nome novo foi aceito e não há lançamentos',pg.evaluate("S.owner")=='Outra Pessoa' and pg.evaluate("S.items.length")==0)
    f=tempfile.NamedTemporaryFile('w',suffix='.json',delete=False,encoding='utf-8');f.write(txt);f.close()
    OPEN_CFG(pg,'bkp');pg.set_input_files('#file',f.name);pg.wait_for_timeout(400);pg.click('[data-act=yes]');pg.wait_for_timeout(800)
    ok('7. O backup salvo antes volta inteiro depois do recomeço (lançamento, WolfCoins e nome)',pg.evaluate("S.items.some(i=>i.id==='a1')") and json.dumps(pg.evaluate("S.wc"),sort_keys=True)==json.dumps(json.loads(txt).get('wc'),sort_keys=True) and pg.evaluate("S.owner")=='Maria Teste',pg.evaluate("[S.items.length,S.wc,S.owner]"))
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
