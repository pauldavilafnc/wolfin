"""v7.22: Editar parcela valida tudo antes de alterar/gravar (sem data de pagamento = bloqueado; Cancelar preserva; parcelas antigas pagas sem data continuam compatíveis). Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
BASE="""{owner:'T',opening:{c:100000,d:'2026-01-01'},items:[],inst:[{id:'n1',n:'Celular',c:null,np:4,day:5,paid:false}],parc:[
{id:'q1',iid:'n1',ym:'2026-06',c:20000,due:'2026-06-05',paid:true,paidOn:'2026-11-15'},
{id:'q2',iid:'n1',ym:'2026-07',c:20000,due:'2026-07-05',paid:false},
{id:'q3',iid:'n1',ym:'2026-08',c:20000,due:'2026-08-05',paid:false},
{id:'q4',iid:'n1',ym:'2026-09',c:20000,paid:true}],debts:[],boxes:[],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light'):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'T')
        pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref()"%th)
        pg.evaluate("S=migrate("+BASE+");save();render()");return c,pg
    q=lambda pg,i:pg.evaluate("(()=>{const p=S.parc.find(x=>x.id==='%s');return{paid:p.paid,paidOn:p.paidOn===undefined?null:p.paidOn,due:p.due===undefined?null:p.due,ym:p.ym,c:p.c}})()"%i)
    ORIG={'paid':False,'paidOn':None,'due':'2026-07-05','ym':'2026-07','c':20000}
    def abre(pg,i):pg.evaluate("parcForm('%s')"%i);pg.wait_for_selector('#f')
    def marca_pago_e_muda_mes(pg,ym):
        pg.select_option('#f select[name=paid]','1');pg.fill('#f input[name=ym]',ym);pg.dispatch_event('#f input[name=ym]','change');pg.wait_for_timeout(150)
    def salvar(pg):pg.click('#f .b1');pg.wait_for_timeout(250)
    err=lambda pg:pg.inner_text('#er')
    # 1) dois cliques em Salvar sem data
    c,pg=app();abre(pg,'q2');marca_pago_e_muda_mes(pg,'2026-09')
    ok('A. Ao mudar o mês a data some (cenário do bug): campo de data vazio',pg.input_value('#f input[name=pd]')=='')
    salvar(pg);e1=err(pg);s1=q(pg,'q2')
    ok('A. 1º clique em Salvar sem data: mostra erro "Informe a data do pagamento."',e1=='Informe a data do pagamento.',e1)
    ok('A. 1º clique NÃO altera a parcela em memória (mês, vencimento, valor, status)',s1==ORIG,s1)
    salvar(pg);s2=q(pg,'q2')
    ok('A. 2º clique em Salvar também é bloqueado (continua com erro)',err(pg)=='Informe a data do pagamento.' and pg.locator('#f').count()==1,err(pg))
    ok('A. 2º clique NÃO grava como paga sem data',s2==ORIG,s2)
    ok('A. Nada foi gravado no armazenamento',pg.evaluate("(()=>{const r=JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k=>/wallstreet|wolfin/i.test(k)&&localStorage.getItem(k).includes('q2')))||'null');const p=r&&(r.parc||[]).find(x=>x.id==='q2');return !p||(!p.paid&&p.ym==='2026-07')})()"))
    # 2) Cancelar depois do erro
    pg.click('#f [data-act=close]');pg.wait_for_timeout(250)
    ok('B. Cancelar depois do erro: parcela intacta (mês, vencimento, valor, status)',q(pg,'q2')==ORIG,q(pg,'q2'))
    ok('B. Reabrir mostra os valores originais',(abre(pg,'q2') or True) and pg.input_value('#f input[name=ym]')=='2026-07' and pg.input_value('#f select[name=paid]')=='0')
    ok('B. Sem erros no console',not pg.errs,pg.errs);c.close()
    # 3) data inválida também não altera
    c,pg=app();abre(pg,'q2');marca_pago_e_muda_mes(pg,'2026-09')
    pg.evaluate("document.querySelector('#f input[name=pd]').value='2026-02-31'");salvar(pg)
    ok('C. Data inválida bloqueada e parcela intacta',err(pg)=='Data do pagamento inválida.' and q(pg,'q2')==ORIG,(err(pg),q(pg,'q2')));c.close()
    # 4) valor inválido: não altera
    c,pg=app();abre(pg,'q2');pg.fill('#f input[name=c]','abc');pg.fill('#f input[name=ym]','2026-10');salvar(pg)
    ok('D. Valor inválido bloqueado e parcela intacta',err(pg)=='Valor inválido.' and q(pg,'q2')==ORIG,(err(pg),q(pg,'q2')));c.close()
    # 5) pagamento em mês diferente do vencimento: relatório no mês do pagamento
    c,pg=app();abre(pg,'q2');pg.select_option('#f select[name=paid]','1')
    pg.evaluate("(()=>{const w=document.querySelector('#pdw .calw');w.dataset.ym='2026-10';w.dataset.sel='2026-10-12';calMount(w)})()")
    salvar(pg);r=q(pg,'q2')
    ok('E. Pagamento com data válida em outro mês salva (paid, paidOn 12/10) mantendo o vencimento',r['paid'] and r['paidOn']=='2026-10-12' and r['due']=='2026-07-05' and r['ym']=='2026-07',r)
    f=pg.evaluate("(()=>{const f=flows();return{jul:(f['2026-07']||{}).exp||0,out:(f['2026-10']||{}).exp||0}})()")
    ok('E. Relatório: a saída de R$ 200,00 entra em outubro (mês do pagamento), não em julho',f['out']>=20000 and f['jul']<20000,f)
    ok('E. Saldo/relatório contam a parcela uma só vez',pg.evaluate("S.parc.filter(x=>x.id==='q2'&&x.paid).length")==1)
    c.close()
    # 6) mês trocado + data no novo mês
    c,pg=app();abre(pg,'q3');marca_pago_e_muda_mes(pg,'2026-09')
    pg.evaluate("(()=>{const w=document.querySelector('#pdw .calw');w.dataset.sel='2026-09-20';calMount(w)})()");salvar(pg);r=q(pg,'q3')
    ok('F. Trocar mês e informar a data salva normalmente',r['paid'] and r['paidOn']=='2026-09-20' and r['ym']=='2026-09' and r['c']==20000,r);c.close()
    # 7) compatibilidade: parcela antiga paga sem data
    c,pg=app();abre(pg,'q4');pg.fill('#f input[name=c]','250,00');salvar(pg);r=q(pg,'q4')
    ok('G. Parcela antiga paga sem data: editar o valor continua salvando, sem inventar data',r['paid'] and r['paidOn'] is None and r['c']==25000,r)
    abre(pg,'q4');pg.fill('#f input[name=ym]','2026-10');pg.dispatch_event('#f input[name=ym]','change');salvar(pg);r=q(pg,'q4')
    ok('G. Mudar o mês da antiga paga sem data também salva, sem preencher data retroativa',r['paid'] and r['paidOn'] is None and r['ym']=='2026-10',r)
    abre(pg,'q4');pg.select_option('#f select[name=paid]','0');salvar(pg);r=q(pg,'q4')
    ok('G. Voltar a antiga para Pendente funciona e não deixa data',(not r['paid']) and r['paidOn'] is None,r)
    abre(pg,'q4');pg.select_option('#f select[name=paid]','1');pg.evaluate("document.querySelector('#f input[name=pd]').value=''");salvar(pg)
    ok('G. Pendente → Pago de novo (agora é um novo pagamento) exige data',err(pg)=='Informe a data do pagamento.' and not q(pg,'q4')['paid'],(err(pg),q(pg,'q4')));c.close()
    # 8) fluxo Registrar pagamento continua igual
    c,pg=app();pg.evaluate("ACT.payp('q2')");pg.wait_for_selector('#f')
    ok('H. Registrar pagamento continua com seu formulário (título e calendário)','Registrar pagamento' in pg.inner_text('#ov h3') and pg.locator('#f .calw').count()==1)
    pg.evaluate("(()=>{const w=document.querySelector('#f .calw');w.dataset.sel='2026-11-10';calMount(w)})()");salvar(pg);r=q(pg,'q2')
    ok('H. Registrar pagamento salva paga com a data escolhida',r['paid'] and r['paidOn']=='2026-11-10',r);c.close()
    # 9) nova parcela
    c,pg=app();pg.evaluate("parcForm(null,'n1')");pg.wait_for_selector('#f');pg.fill('#f input[name=c]','100,00');pg.fill('#f input[name=ym]','2026-12');pg.select_option('#f select[name=paid]','1');pg.fill('#f input[name=ym]','2026-12');pg.dispatch_event('#f input[name=ym]','change');n0=pg.evaluate("S.parc.length");salvar(pg);salvar(pg)
    ok('I. Nova parcela marcada como Pago sem data: bloqueada nas duas tentativas e nada é criada',err(pg)=='Informe a data do pagamento.' and pg.evaluate("S.parc.length")==n0,err(pg));c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
