"""v7.10: fundo dos avatares acompanha a cor do tema + mapa de calor em tons quentes. Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,hashlib,colorsys,io
from playwright.sync_api import sync_playwright
from PIL import Image
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SRC=open(_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))),'index.html'),encoding='utf-8').read()
PALS=['blue','perola','violet','teal','pink','orange','ouro','esmeralda','grafite'];CHROMA=['blue','violet','teal','pink','orange','ouro','esmeralda']
def lum(c):f=lambda v:(v/255/12.92) if v/255<=.03928 else ((v/255+.055)/1.055)**2.4;return .2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2])
def cr(a,b):x,y=lum(a),lum(b);return (max(x,y)+.05)/(min(x,y)+.05)
def hue(c):h,l,s=colorsys.rgb_to_hls(*[v/255 for v in c]);return h*360,s,l
def hd(a,b):d=abs(a-b)%360;return min(d,360-d)
# ===== A. código-fonte =====
i=SRC.index('const MCB=');j=SRC.index('};',i)+2
ok('A. As 12 imagens do Wolfin (6 corpos inteiros e 6 bustos) estão embutidas e intactas (hash da v7.18)',len(re.findall(r'"[fb][1-6]":"',SRC[i:j]))==12 and hashlib.sha256(SRC[i:j].encode()).hexdigest()=='1af489f9bae5488d840a058d1b4508aaed557c899fe32f06af8261f45323b076')
ok('A. Sem azul fixo no fundo do avatar (#4f78c8 / #1b2f63 removidos)','4f78c8' not in SRC.lower() and '1b2f63' not in SRC.lower())
ok('A. Cores do avatar centralizadas: --av1/--av2 definidas uma vez no :root e usadas por .mcav',SRC.count('--av1:')==1 and SRC.count('--av2:')==1 and 'radial-gradient(circle at 50% 30%,var(--av1),var(--av2))' in SRC)
ok('A. Alternativa para navegador sem color-mix (cor do tema lisa)','@supports not (color:color-mix(in srgb,red,blue)){.mcav{background:var(--blue)}}' in SRC)
with sync_playwright() as p:
    b=p.chromium.launch()
    def conta(w=393,h=851,th='light',nome='Ana'):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th,device_scale_factor=2)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        pg.goto(URL);OB_NOSEC(pg,nome);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_selector('#cfab');pg.wait_for_timeout(500);return c,pg
    PROBE="""(v)=>{const k=document.createElement('canvas').getContext('2d'),e=document.createElement('i');document.body.appendChild(e);e.style.color=v;const cc=getComputedStyle(e).color;e.remove();k.fillStyle='#000';k.fillStyle=cc;k.fillRect(0,0,1,1);return [...k.getImageData(0,0,1,1).data].slice(0,3)}"""
    def setpal(pg,th,pl):pg.evaluate(f"S.pref.theme='{th}';S.pref.pal='{pl}';applyPref();save();render()");pg.wait_for_timeout(120)
    def avcols(pg):return [pg.evaluate(PROBE,'var(--av1)'),pg.evaluate(PROBE,'var(--av2)'),pg.evaluate(PROBE,'var(--blue)')]
    def pix(png,box,fx,fy):
        im=Image.open(io.BytesIO(png)).convert('RGB');return im.getpixel((int(fx*im.width),int(fy*im.height)))
    c,pg=conta()
    # ===== B. todas as cores x temas: o fundo segue a cor principal =====
    for th in ('light','dark'):
        res={}
        for pl in PALS:
            setpal(pg,th,pl);a1,a2,bl=avcols(pg);res[pl]=(a1,a2,bl)
        okc=all(hd(hue([(x+y)/2 for x,y in zip(*res[pl][:2])])[0],hue(res[pl][2])[0])<=30 for pl in CHROMA)
        ok(f'B. Tema {th}: nos 7 temas coloridos o fundo do avatar tem o matiz da cor principal (±30°)',okc,{pl:round(hue([(x+y)/2 for x,y in zip(*res[pl][:2])])[0]) for pl in CHROMA})
        ok(f'B. Tema {th}: perola e grafite ficam neutros/acinzentados (saturação baixa), não azul vivo',all(hue([(x+y)/2 for x,y in zip(*res[pl][:2])])[1]<.45 for pl in ('perola','grafite')),{pl:round(hue([(x+y)/2 for x,y in zip(*res[pl][:2])])[1],2) for pl in ('perola','grafite')})
        ok(f'B. Tema {th}: os 9 temas dão fundos diferentes entre si',len({tuple(res[pl][0]) for pl in PALS})==9)
        ok(f'B. Tema {th}: laranja/ouro/rosa/verde/violeta/turquesa NÃO usam mais o azul antigo (matiz ≥ 25° distante do azul #4F78C8)',all(hd(hue([(x+y)/2 for x,y in zip(*res[pl][:2])])[0],hue((0x4f,0x78,0xc8))[0])>25 for pl in ('violet','teal','pink','orange','ouro','esmeralda')))
    # ===== C. contraste do personagem: borda do mascote x fundo (todas as cores e temas) =====
    import base64,statistics
    from PIL import ImageFilter,ImageChops
    rims={}
    for k,v in re.findall(r'"(b[1-6])":"([A-Za-z0-9+/=]+)"',SRC[i:j]):
        a=Image.open(io.BytesIO(base64.b64decode(v))).convert('RGBA');m=a.getchannel('A').point(lambda x:255 if x>128 else 0)
        band=ImageChops.subtract(m,m.filter(ImageFilter.MinFilter(21)));bd=list(band.getdata());rgb=list(a.convert('RGB').getdata())
        rims[k]=[rgb[q] for q in range(0,len(rgb),40) if bd[q]>128]
    worst=9;wn=''
    for th in ('light','dark'):
        for pl in PALS:
            setpal(pg,th,pl);a1,a2,_=avcols(pg);mid=[(x+y)/2 for x,y in zip(a1,a2)]
            for k,rg in rims.items():
                v=float(statistics.median([cr(px,mid) for px in rg]))
                if v<worst:worst=v;wn=(th,pl,k)
    ok(f'C. Contraste mascote × fundo nos 6 bustos × 9 cores × 2 temas: pior caso {worst:.2f}:1 {wn} (decorativo, com nome acessível; piso 1,5:1 para os novos bustos, conferido visualmente)',worst>=1.5,wn)
    # ===== D. onde os avatares aparecem: pixel real do fundo =====
    def bgmatch(png,cols,fx=.2,fy=.2,tol=70):
        import math
        m=[(x+y)/2 for x,y in zip(*cols[:2])];best=(999,None)
        for ang in range(0,360,15):
            px=pix(png,None,.5+.43*math.cos(math.radians(ang)),.5+.43*math.sin(math.radians(ang)));d=sum((x-y)**2 for x,y in zip(px,m))**.5
            if d<best[0]:best=(d,px)
        return best[0]<tol,best[1]
    for th,pl in (('light','esmeralda'),('dark','violet'),('light','orange'),('dark','pink'),('light','teal')):
        setpal(pg,th,pl);cols=avcols(pg);pg.evaluate("go('home')");pg.wait_for_selector('#avh .mcav');pg.wait_for_timeout(250)
        okh,px=bgmatch(pg.locator('#avh .mcav').screenshot(),cols,.14,.5,90)
        pg.click('#avh');pg.wait_for_selector('#ov .lvc');pg.wait_for_timeout(300)
        sel=pg.evaluate("(()=>{const e=document.querySelector('#ov .lvc.on');return getComputedStyle(e).boxShadow+'|'+getComputedStyle(e).borderColor})()")
        pg.click('#ov [data-act=close]') if pg.locator('#ov [data-act=close]').count() else pg.keyboard.press('Escape');pg.wait_for_timeout(200)
        ok(f'D. {th}/{pl}: avatar da Home usa o fundo da cor do tema (pixel real)',okh,px)
        ok(f'D. {th}/{pl}: destaque da roupa selecionada na galeria não usa o azul fixo antigo (rgb 37,99,235)','37, 99, 235' not in sel,sel[:120])
    # Ajustes: troca de roupa pelo botão "Trocar de roupa"
    setpal(pg,'dark','pink');pg.evaluate("go('cfg')");pg.wait_for_timeout(300);pg.locator('.card [data-act=avs]').first.scroll_into_view_if_needed();pg.locator('.card [data-act=avs]').first.click();pg.wait_for_selector('#ov .lvc');pg.wait_for_timeout(250)
    pg.click('#ov .lvc >> nth=0');pg.wait_for_timeout(150);ok('D. Trocar a roupa na galeria continua funcionando (seleção marcada, Confirmar ativo)',pg.locator('#ov .lvc.on').count()==1 and pg.locator('[data-act=lvok]').count()==1)
    pg.click('[data-act=lvok]');pg.wait_for_timeout(300);ok('D. Confirmar guarda a roupa escolhida',pg.evaluate("S.pref.lm")=='m' and pg.evaluate("S.pref.lp")==1)
    c.close()
    # onboarding (conheça o Wolfin)
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1");pg=c.new_page();pg.goto(URL)
    try:
        pg.wait_for_selector('#mf .mcav',timeout=8000);pg.evaluate("document.documentElement.dataset.pal='teal'");pg.wait_for_timeout(300)
        a1,a2,_=avcols(pg);m=[(x+y)/2 for x,y in zip(a1,a2)];okb,px=bgmatch(pg.locator('#mf .mcav').first.screenshot(),avcols(pg),0,0,90)
        ok('D. Etapa 1 do cadastro (roupas do Wolfin): fundo do avatar na cor do tema (turquesa)',okb and hd(hue(px)[0],173)<40,px)
    except Exception as e:ok('D. Etapa 1 do cadastro (roupas do Wolfin)',False,e)
    c.close()
    # ===== E. mapa de calor quente =====
    c,pg=conta()
    pg.evaluate("""(()=>{const m=ymOf(new Date()),X=(id,d,cc,day)=>S.items.push({id,t:'exp',d,c:cc,day,ym:m,cat:'Lazer',done:{[m]:cc}});[[2,1000],[5,2500],[9,6000],[14,20000]].forEach(([d,c],i)=>X('w'+i,'Gasto'+i,c,d));save()})()""")
    base={'light':(235,240,250),'dark':(14,22,45)}
    for th in ('light','dark'):
        for pl in ('blue','esmeralda'):
            setpal(pg,th,pl);pg.evaluate("HMS.main.sel=0;go('rel')");pg.wait_for_selector('.hmc');pg.locator('.hmcard').scroll_into_view_if_needed()
            cell={d:pg.evaluate(f"(()=>{{const s=getComputedStyle(document.querySelector('.hmw[data-hm=main] [data-d=\"{d}\"]'));return [s.backgroundColor,s.color]}})()") for d in (2,5,9,14,20)}
            leg=pg.evaluate("[...document.querySelectorAll('.hml i')].map(e=>getComputedStyle(e).backgroundColor)")
            P=lambda s:[float(x) for x in re.findall(r'[\d.]+',s)[:4]]
            bgs=[P(cell[d][0]) for d in (2,5,9,14)];fgs=[P(cell[d][1])[:3] for d in (2,5,9,14)]
            hs=[hue(x[:3]) for x in bgs]
            ok(f'E. {th}/{pl}: escala quente — faixa 1 amarelo suave, 2 amarelo-alaranjado, 3 laranja, 4 vermelho (matizes {[round(h[0]) for h in hs]})',45<=hs[0][0]<=56 and 36<=hs[1][0]<=46 and 18<=hs[2][0]<=32 and (hs[3][0]<=10 or hs[3][0]>=350),[round(h[0]) for h in hs])
            ok(f'E. {th}/{pl}: o matiz desce de amarelo a vermelho em ordem e nenhuma faixa é azul/verde',hs[0][0]>hs[1][0]>hs[2][0]>(hs[3][0] if hs[3][0]<100 else 0) and all(h[0]<70 or h[0]>340 for h in hs))
            rs=[cr(fgs[k],bgs[k][:3]) for k in range(4)];ok(f'E. {th}/{pl}: números legíveis em todas as faixas (contraste mínimo {min(rs):.1f}:1 ≥ 4,5)',min(rs)>=4.5,[round(x,1) for x in rs])
            ok(f'E. {th}/{pl}: cores sem saturação excessiva (S ≤ 0,85 em HSV) e sem brilho estourado no escuro',all(colorsys.rgb_to_hsv(*[v/255 for v in x[:3]])[1]<=.85 for x in bgs) and (th=='light' or all(colorsys.rgb_to_hsv(*[v/255 for v in x[:3]])[2]<=.8 for x in bgs)),[tuple(round(q,2) for q in colorsys.rgb_to_hsv(*[v/255 for v in x[:3]])[1:]) for x in bgs])
            ok(f'E. {th}/{pl}: legenda sincronizada com as cores dos dias (mesmas 5 cores)',len(leg)==5 and leg[1:]==[cell[d][0] for d in (2,5,9,14)] and leg[0]==cell[20][0],leg)
    # selecionado ≠ intensidade
    for th in ('light','dark'):
        setpal(pg,th,'blue');pg.evaluate("HMS.main.sel=0;go('rel')");pg.wait_for_selector('.hmc')
        before=pg.evaluate("getComputedStyle(document.querySelector('.hmw[data-hm=main] [data-d=\"9\"]')).backgroundColor")
        pg.click('.hmw[data-hm=main] [data-d="9"]');pg.wait_for_timeout(250)
        sel=pg.evaluate("(()=>{const e=document.querySelector('.hmc.sel'),s=getComputedStyle(e);return {bg:s.backgroundColor,o:s.outlineColor,w:s.outlineWidth,st:s.outlineStyle,cls:e.className}})()")
        warm=[pg.evaluate(f"getComputedStyle(document.querySelector('.hml i.hm{k}')).backgroundColor") for k in range(5)]
        ok(f'E. {th}: dia selecionado mantém a cor da intensidade e ganha contorno neutro (3 px, cor do texto do tema), que não é nenhuma cor da escala',sel['bg']==before and sel['st']=='solid' and sel['w']=='3px' and sel['o'] not in warm,sel)
    pg.evaluate("go('home')");pg.evaluate("S.pref.theme='light';applyPref()")
    # maior dia sempre vermelho
    def lvs(vals):
        pg.evaluate("S.items=S.items.filter(i=>!i.id.startsWith('w'))");pg.evaluate("(vals)=>{const m=ymOf(new Date());vals.forEach(([d,c],i)=>S.items.push({id:'w'+i,t:'exp',d:'x',c,day:d,ym:m,cat:'Lazer',done:{[m]:c}}));save()}",vals)
        return pg.evaluate("hmCalc(ymOf(new Date()),null).days.map(x=>x.lv)")
    L=lvs([(3,500)]);ok('E. Um único dia com gasto = maior dia = faixa 4 (vermelho)',L[2]==4)
    L=lvs([(3,500),(7,900)]);ok('E. Com 2 dias: o maior é faixa 4 (vermelho) e o menor continua mais claro',L[6]==4 and 0<L[2]<4,L)
    L=lvs([(3,500),(7,900),(11,1500)]);ok('E. Com 3 dias: o maior é vermelho',L[10]==4 and L[2]<L[6]<4+1,L)
    L=lvs([(d,100*d) for d in range(1,29)]);ok('E. Com 28 dias distintos: faixas 1–4 distribuídas (7 dias cada); o maior dia está na faixa vermelha',L[27]==4 and L[0]==1 and L[:28]==sorted(L[:28]) and [L.count(k) for k in (1,2,3,4)]==[7,7,7,7],[L.count(k) for k in range(5)])
    L=lvs([(2,1000),(5,2000),(9,3000),(14,4000)]);ok('E. Cálculo de intensidade mantido (4 dias → 1,2,3,4)',[L[1],L[4],L[8],L[13]]==[1,2,3,4],L)
    d0=pg.evaluate("JSON.stringify(S.items)");pg.evaluate("go('rel')");pg.wait_for_selector('.hmc');pg.click('.hmw[data-hm=main] [data-act=hmn]');ok('E. Registros financeiros não são alterados pelo mapa',pg.evaluate("JSON.stringify(S.items)")==d0)
    ok('E. Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    # ===== F. responsivo e dois temas visuais =====
    for w,h,th,pl in ((320,568,'light','orange'),(360,740,'dark','violet'),(393,851,'light','esmeralda'),(851,393,'dark','pink')):
        c,pg=conta(w,h,th);setpal(pg,th,pl)
        pg.evaluate("(()=>{const m=ymOf(new Date());[[2,1000],[5,2500],[9,6000],[14,20000]].forEach(([d,c],i)=>S.items.push({id:'q'+i,t:'exp',d:'x',c,day:d,ym:m,cat:'Lazer',done:{[m]:c}}));save()})()")
        pg.evaluate("go('rel')");pg.wait_for_selector('.hmc');pg.click('.hmw[data-hm=main] [data-d="9"]');pg.wait_for_timeout(250)
        r=pg.evaluate("(()=>{const cd=document.querySelector('.hmcard').getBoundingClientRect(),cs=[...document.querySelectorAll('.hmw[data-hm=main] .hmc')].map(e=>e.getBoundingClientRect());return{sx:document.documentElement.scrollWidth>innerWidth+1,inside:cs.every(x=>x.left>=cd.left-1&&x.right<=cd.right+1),w:Math.min(...cs.map(x=>x.width))}})()")
        pg.evaluate("go('home')");pg.wait_for_selector('#avh .mcav');av=pg.evaluate("(()=>{const r=document.querySelector('#avh').getBoundingClientRect();return[r.width,r.height]})()")
        ok(f'F. {w}x{h} {th}/{pl}: mapa sem rolagem lateral, quadrados ≥ 33 px e avatar da Home {av[0]:.0f}x{av[1]:.0f} px preservado',not r['sx'] and r['inside'] and r['w']>=33 and av==[44,44] and not pg.errs,(r,av,pg.errs[:2]));c.close()
    b.close()
print(sum(R),'/',len(R))
