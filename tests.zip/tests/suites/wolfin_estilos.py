"""v7.26: estilos do Wolfin (10 personagens: normal, mãos nos olhos, busto). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
IDS=['brasil','shelby','cafetao','tommy','meme','kratos','morgan','cj','tyler','heisenberg']
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(w=393,h=851,th='light',rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,reduced_motion='reduce' if rm else 'no-preference');pg=c.new_page()
        pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};save();go('home')");pg.wait_for_timeout(700)
        return c,pg
    c,pg=home()
    pg.evaluate("wfLoadSty()");pg.wait_for_function("window.WOLFIMG&&WOLFIMG.sty&&WOLFIMG.sty.arabe",timeout=15000)
    ok('1. Dados dos 11 estilos (Brasil + 9 + Árabe): corpo inteiro e busto',pg.evaluate("%s.every(k=>WOLFIMG.sty[k]&&WOLFIMG.sty[k].n&&WOLFIMG.sty[k].b)"%json.dumps(IDS+['arabe'])))
    ok('2. Versões "vendado" removidas: nenhuma chave v nos dados e nenhuma imagem .sv na tela',pg.evaluate("Object.values(WOLFIMG.sty).every(e=>!e.v)&&!document.querySelector('.wolf .sv')"))
    ok('3. Loja: 12 personagens e saldo no cabeçalho; nenhum "Em breve"',(pg.evaluate("go('loja')"),pg.wait_for_timeout(700),pg.locator('#s-loja .lc').count()==12 and pg.locator('#s-loja .sbar .lbal2 .wcn').count()==1 and 'Em breve' not in pg.inner_text('#s-loja'))[2])
    ok('4. Árabe pode ser equipado (modo de testes)',pg.evaluate("(()=>{ACT.wlook('arabe');const r=wcEnsure().look;ACT.wlook('brasil');return r})()")=='arabe')
    bad=[]
    for L in IDS+['arabe']:
        pg.evaluate("ACT.wlook('%s');go('home')"%L);pg.wait_for_timeout(500)
        r=pg.evaluate("""(()=>{const w=document.querySelector('#s-home .mqc .wolf');if(!w)return 'sem avatar';const im=[...w.querySelectorAll('img')];const ok=im.length>0&&im.every(i=>i.complete&&i.naturalWidth>0);const r=w.getBoundingClientRect();return [S.wc.look,JSON.parse(localStorage.getItem('wallstreet.look')).w,ok,Math.round(r.width)]})()""")
        if not(isinstance(r,list) and r[0]==L and r[1]==L and r[2] and r[3]>=40):bad.append((L,r))
    ok('5. Cada estilo equipado: salvo em S.wc.look e espelhado no armazenamento da tela de entrada; avatar da Home carrega (≥60px)',not bad,bad)
    pg.evaluate("ACT.wlook('kratos');go('home')");pg.wait_for_timeout(500)
    ok('6. Home: cartão usa o busto do estilo (sem círculo)',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');return w.classList.contains('sty')&&w.classList.contains('bx')&&w.dataset.k==='b'&&w.querySelector('img').src===wfSty('kratos','b')})()"))
    ok('7. Tela de entrada bloqueada usa o estilo salvo antes de abrir os dados',pg.evaluate("(()=>{const a=SECMODE,d=DEK;SECMODE=true;DEK=null;const r=wfLook();SECMODE=a;DEK=d;return r})()")=='kratos')
    ok('8. Tela de entrada (corpo inteiro): só a imagem normal',pg.evaluate("(()=>{const d=document.createElement('div');d.innerHTML=wolfHtml({lock:1});const w=d.firstChild;return w.classList.contains('lkw')&&!!w.querySelector('.sn')&&!w.querySelector('.sv')&&w.dataset.look==='kratos'})()"))
    ok('9. Corpo inteiro do Brasil preservado (camadas em Conquistas) e busto do Brasil na Home',pg.evaluate("(()=>{ACT.wlook('brasil');go('conq');const f=!!document.querySelector('#s-conq .wolf .we');go('home');const w=document.querySelector('#s-home .mqc .wolf');return f&&w.dataset.look==='brasil'&&w.classList.contains('bx')})()"))
    ok('10. Migração: look inválido volta para o Padrão; look liberado permanece',pg.evaluate("(()=>{const a={wc:{look:'zzz'}},b2={wc:{look:'tyler'}};wcEnsure(a);wcEnsure(b2);return[a.wc.look,b2.wc.look]})()")==['padrao','tyler'])
    ok('11. Sem erros de script',not pg.errs,pg.errs);c.close()
    for w,h in((320,568),(393,851)):
        c,pg=home(w,h,'dark');pg.evaluate("ACT.wlook('cafetao');go('loja')");pg.wait_for_timeout(900)
        ok('12. Loja %dx%d (escuro): sem rolagem horizontal e botões ≥44px'%(w,h),pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1")and pg.evaluate("[...document.querySelectorAll('#s-loja .lc .lbt button:not(.ltest),#s-loja .ltabs button')].every(x=>x.getBoundingClientRect().height>=43.5)"))
        c.close()
    c,pg=home(rm=True);pg.evaluate("ACT.wlook('tyler');go('home')");pg.wait_for_timeout(300)
    ok('13. Movimento reduzido: sem animação no avatar',pg.evaluate("getComputedStyle(document.querySelector('#s-home .mqc .wolf img')).animationName")=='none');c.close()
    c,pg=home()
    pg.click('#s-home .mqb');pg.wait_for_timeout(500)
    ok('14. Tocar no mascote da Home abre a Loja do Wolfin',pg.evaluate("view")=='loja')
    ok('15. Loja: barra inferior oculta e botão Voltar retorna à Home',(pg.evaluate("getComputedStyle(document.getElementById('nav')).display")=='none',pg.click('#s-loja .sbk'),pg.wait_for_timeout(400),pg.evaluate("view"))[3]=='home')
    pg.evaluate("go('cfg',{cat:'mascote'})");pg.wait_for_timeout(400)
    ok('16. Configurações: sem barra inferior, só o atalho "Loja do Wolfin" (v7.33) como botão da Loja, com Voltar no topo e Voltar funciona',pg.evaluate("getComputedStyle(document.getElementById('nav')).display")=='none' and pg.locator('#s-cfg [data-act=nav][data-id=loja]').count()==1 and pg.locator('#s-cfg #cs-wolf [data-act=nav][data-id=loja]').count()==1 and pg.locator('#s-cfg .sbk').count()==1 and (pg.click('#s-cfg .sbk'),pg.wait_for_timeout(400),pg.click('#s-cfg .sbk'),pg.wait_for_timeout(400),pg.evaluate("view"))[4]=='home')
    r=pg.evaluate("(()=>{const w=wcEnsure(),n0=w.n,a=wcGrant('t:x',5,'teste'),b2=wcGrant('t:x',5,'teste');return[a,b2,wcEnsure().n-n0]})()")
    ok('17. Recompensa com identificador único: segunda tentativa não paga de novo',r==[5,0,5],r)
    r=pg.evaluate("(()=>{const w=wcEnsure();w.n=100;ACT.wbuy('shelby');const a=[w.n,w.own.includes('shelby')];w.n=500;ACT.wbuy('shelby');return[a,w.n,w.own.includes('shelby'),w.log[0].n]})()")
    ok('18. Desbloqueio: sem saldo não compra; com saldo desconta o preço e registra no histórico',r==[[100,False],350,True,-150],r)
    pg.evaluate("save()");pg.reload();pg.wait_for_selector('#s-home');pg.wait_for_timeout(800)
    r=pg.evaluate("[wcEnsure().own.includes('shelby'),wcEnsure().n,wcEnsure().log.some(g=>g.n===-150)]")
    ok('19. Saldo, item desbloqueado e histórico persistem após recarregar (+ visita do dia, se houver)',r[0] and r[1]>=350 and r[2],r)
    # 20. Regressão da tela em branco (v7.28b): estilo equipado SEM constar em 'own' (modo de testes) + reabrir
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.evaluate("(()=>{const w=wcEnsure();w.look='arabe';w.own=['brasil'];save()})()")
    pg.reload();pg.wait_for_timeout(1500)
    r=pg.evaluate("(document.querySelector('#s-home')||{innerHTML:''}).innerHTML.length")
    ok('20. Reabrir com estilo equipado fora de "own" mostra a Home (sem tela em branco) e sem erro de JS',r>200 and not errs,(r,errs[:1]))
    pg.evaluate("(()=>{const w=wcEnsure();w.own='lixo';w.look=5;save()})()")
    pg.reload();pg.wait_for_timeout(1500)
    r=pg.evaluate("(document.querySelector('#s-home')||{innerHTML:''}).innerHTML.length")
    ok('21. Dados de WolfCoins corrompidos não impedem de abrir o app',r>200 and not errs,(r,errs[:1]))
    c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
