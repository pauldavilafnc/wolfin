"""v7.26: estilos do Wolfin (10 personagens: normal, mãos nos olhos, busto). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
IDS=['brasil','shelby','cafetao','tommy','meme','kratos','morgan','cj','tyler','heisenberg']
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(w=393,h=851,th='light',rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,reduced_motion='reduce' if rm else 'no-preference');pg=c.new_page()
        pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};save();go('home')");pg.wait_for_timeout(700)
        return c,pg
    c,pg=home()
    pg.evaluate("wfLoadSty()");pg.wait_for_function("window.WOLFIMG&&WOLFIMG.sty&&WOLFIMG.sty.arabe",timeout=15000)
    ok('1. Dados dos 10 estilos + Árabe existem',pg.evaluate("%s.every(k=>WOLFIMG.sty[k]&&WOLFIMG.sty[k].n&&WOLFIMG.sty[k].v&&WOLFIMG.sty[k].b)&&!!WOLFIMG.sty.arabe.n"%json.dumps(IDS)))
    ok('2. Árabe só tem a imagem normal (sem vendado nem busto)',pg.evaluate("!WOLFIMG.sty.arabe.v&&!WOLFIMG.sty.arabe.b"))
    ok('3. Loja: 11 visuais; 10 liberados e Árabe "Em breve" (sem compra)',(pg.evaluate("go('loja')"),pg.wait_for_timeout(700),pg.locator('#s-loja .li').count()==11 and pg.locator('#s-loja .li .tag').count()==1 and pg.locator('#s-loja .li .b1').count()==1 and pg.locator('#s-loja .li .b2').count()==9)[2])
    ok('4. Árabe não pode ser equipado',pg.evaluate("(()=>{ACT.wlook('arabe');return wcEnsure().look})()")=='brasil')
    bad=[]
    for L in IDS:
        pg.evaluate("ACT.wlook('%s');go('home')"%L);pg.wait_for_timeout(500)
        r=pg.evaluate("""(()=>{const w=document.querySelector('#s-home .mqc .wolf');if(!w)return 'sem avatar';const im=[...w.querySelectorAll('img')];const ok=im.length>0&&im.every(i=>i.complete&&i.naturalWidth>0);const r=w.getBoundingClientRect();return [S.wc.look,JSON.parse(localStorage.getItem('wallstreet.look')).w,ok,Math.round(r.width)]})()""")
        if not(isinstance(r,list) and r[0]==L and r[1]==L and r[2] and r[3]>=60):bad.append((L,r))
    ok('5. Cada estilo equipado: salvo em S.wc.look e espelhado no armazenamento da tela de entrada; avatar da Home carrega (≥60px)',not bad,bad)
    pg.evaluate("ACT.wlook('kratos');go('home')");pg.wait_for_timeout(500)
    ok('6. Home: avatar usa o busto (imagem do estilo, não camadas Brasil)',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');return w.classList.contains('sty')&&w.dataset.k==='b'&&w.querySelector('img').src===wfSty('kratos','b')})()"))
    ok('7. Tela de entrada bloqueada usa o estilo salvo antes de abrir os dados',pg.evaluate("(()=>{const a=SECMODE,d=DEK;SECMODE=true;DEK=null;const r=wfLook();SECMODE=a;DEK=d;return r})()")=='kratos')
    ok('8. Tela de entrada (corpo inteiro): normal + mãos nos olhos',pg.evaluate("(()=>{const d=document.createElement('div');d.innerHTML=wolfHtml({lock:1});const w=d.firstChild;return w.classList.contains('lkw')&&!!w.querySelector('.sn')&&!!w.querySelector('.sv')&&w.dataset.look==='kratos'})()"))
    ok('9. Nenhum visual quebra: Brasil volta com camadas e expressões',pg.evaluate("(()=>{ACT.wlook('brasil');go('home');const w=document.querySelector('#s-home .mqc .wolf');return !w.classList.contains('sty')&&!!w.querySelector('.we')})()"))
    ok('10. Migração: look inválido volta para Brasil; look liberado permanece',pg.evaluate("(()=>{const a={wc:{look:'zzz'}},b2={wc:{look:'tyler'}};wcEnsure(a);wcEnsure(b2);return[a.wc.look,b2.wc.look]})()")==['brasil','tyler'])
    ok('11. Sem erros de script',not pg.errs,pg.errs);c.close()
    for w,h in((320,568),(393,851)):
        c,pg=home(w,h,'dark');pg.evaluate("ACT.wlook('cafetao');go('loja')");pg.wait_for_timeout(900)
        ok('12. Loja %dx%d (escuro): sem rolagem horizontal e botões ≥44px'%(w,h),pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1")and pg.evaluate("[...document.querySelectorAll('#s-loja .li button')].every(x=>x.getBoundingClientRect().height>=43.5)"))
        c.close()
    c,pg=home(rm=True);pg.evaluate("ACT.wlook('tyler');go('home')");pg.wait_for_timeout(300)
    ok('13. Movimento reduzido: sem animação no avatar',pg.evaluate("getComputedStyle(document.querySelector('#s-home .mqc .wolf img')).animationName")=='none');c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
