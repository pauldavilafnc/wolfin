"""v7.22: Redesign da Home (vidro nas cores do tema; olho só na Home). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(w=393,h=851,th='dark',pal=None,code=''):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,timezone_id='America/Sao_Paulo')
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};"+code+"S.pref.theme='%s';"%th+("S.pref.pal='%s';"%pal if pal else '')+"save();applyPref();go('home')");pg.wait_for_timeout(500);return c,pg
    c,pg=home()
    ok('A. O olho existe na Home (cabeçalho) e é um só',pg.locator('#s-home .top [data-act=eye]').count()==1 and pg.locator('#s-home [data-act=eye]').count()==1)
    sem=[]
    for v in('rec','des','div','cx','rel','cc','nt','conq','cfg','news'):
        try:
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
            n=pg.evaluate("[...document.querySelectorAll('[data-act=eye],.eyefl')].filter(e=>e.offsetParent!==null).length")
            if n:sem.append((v,n))
        except Exception as e:sem.append((v,str(e)[:40]))
    ok('B. Nenhuma outra aba mostra o botão de olho',not sem,sem)
    pg.evaluate("go('home')");pg.wait_for_timeout(250)
    ok('C. Olho do cabeçalho tem nome acessível',bool(pg.evaluate("document.querySelector('#s-home [data-act=eye]').getAttribute('aria-label')")))
    ant=pg.inner_text('#s-home .hero .big')
    pg.click('#s-home [data-act=eye]');pg.wait_for_timeout(300)
    oc=pg.inner_text('#s-home .hero .big');ok('D. Ocultar valores na Home mascara o saldo',oc!=ant and '•' in oc or '*' in oc,(ant,oc))
    mask=[]
    for v in('rec','des','div','cx','rel'):
        pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
        t=pg.inner_text('#s-'+v);
        if 'R$ ' in t and not any(ch in t for ch in'•*'):mask.append(v)
    ok('E. Com valores ocultos, as outras abas continuam mascaradas (comportamento global)',not mask,mask)
    pg.evaluate("go('home')");pg.wait_for_timeout(250)
    pg.click('#s-home [data-act=eye]');pg.wait_for_timeout(300)
    ok('F. Tocar de novo no olho da Home volta a mostrar os valores',pg.inner_text('#s-home .hero .big')==ant)
    c.close()
    # seção expansível
    c,pg=home()
    vis=lambda s:pg.evaluate("s=>{const e=document.querySelector(s);return !!e&&e.checkVisibility({checkVisibilityCSS:true,contentVisibilityAuto:true})&&e.getBoundingClientRect().height>0}",s)
    ok('G. "Mais informações" começa fechada: previsões/caixinhas/dívidas/mês escondidos',not vis('#s-home .hmore .g2') and not vis('#s-home .hmore .cql') and pg.locator('#s-home details.hmore:not([open])').count()==1)
    pg.click('#s-home .hmore>summary');pg.wait_for_timeout(250)
    t=pg.inner_text('#s-home .hmore')
    ok('G. Aberta, mostra Receitas previstas, Despesas fixas, Caixinhas, Dívidas, Este mês e Conquistas',all(x.lower() in t.lower() for x in('Receitas previstas','Despesas fixas','Caixinhas','Dívidas','Este mês','Conquistas')),t[:200])
    pg.evaluate("go('rec')");pg.wait_for_timeout(200);pg.evaluate("go('home')");pg.wait_for_timeout(250)
    ok('G. Seção continua aberta depois de trocar de aba',pg.locator('#s-home details.hmore[open]').count()==1)
    c.close()
    # detalhes do saldo
    c,pg=home()
    ok('H. Detalhes do saldo (Guardado e explicação) ficam recolhidos e abrem pelo ⓘ',not vis('#s-home #hsub'))
    pg.click('#s-home .hdet>summary');pg.wait_for_timeout(250)
    t=pg.inner_text('#s-home .hdet');ok('H. Abertos: mostram "Só conta o que já aconteceu"',vis('#s-home #hsub') and 'Só conta o que já aconteceu' in t,t)
    ok('H. Tocar na área do ⓘ tem ≥44px',pg.evaluate("(()=>{const r=document.querySelector('#s-home .hdet>summary').getBoundingClientRect();return r.width>=43.5&&r.height>=43.5})()"))
    c.close()
    # cores unificadas no tema: ícones/chips da Home não usam verde/vermelho fixos
    for pal in('azul','violet','teal','ouro','grafite','esmeralda','perola'):
        for th in('dark','light'):
            c,pg=home(393,851,th,pal)
            r=pg.evaluate("""()=>{const bad=[];const sat=c=>{const m=c.match(/[\\d.]+/g);if(!m)return false;const [r,g,b]=m.map(Number);return false};
              const q=[...document.querySelectorAll('#s-home .qa button i,#s-home .nth0 .nic,#s-home .mqc .mi,#s-home .row .dchip,#s-home .row .tag')];
              const cs=q.map(e=>getComputedStyle(e).backgroundColor+'|'+getComputedStyle(e).backgroundImage);
              const qa=[...document.querySelectorAll('#s-home .qa button i')].map(e=>getComputedStyle(e).backgroundImage);
              return{same:qa.length===3&&qa[0]===qa[1]&&qa[1]===qa[2],n:q.length}}""")
            ok(f'I. {pal}/{th}: Receita, Despesa e Guardar usam o mesmo tratamento (cor do tema, sem verde/vermelho fixos)',r['same'] and r['n']>=5 and not pg.errs,r);c.close()
    # alerta nos estados
    for nome,code,neg in(('negativo',"S.opening.c=-900000;",True),('positivo',"",False),('zerado',"S.items=[];S.debts=[];S.boxes=[];S.inst=[];S.parc=[];S.cards=[];S.opening.c=0;S.org={notes:[],rems:[],lists:[]};",False)):
        c,pg=home(393,851,'dark',None,code)
        n=pg.locator('#s-home button.mqc').count()
        ok(f'J. Aviso {nome}: '+('botão com seta que abre Relatórios' if neg else 'texto simples, sem botão'),n==(1 if neg else 0) and pg.locator('#s-home .mqc').count()==1)
        if neg:
            pg.click('#s-home button.mqc');pg.wait_for_timeout(300);ok('J. Tocar no aviso negativo abre Relatórios',pg.evaluate('view')=='rel')
        c.close()
    # sem rolagem lateral nem sobreposição em larguras estreitas
    for w,h in((320,568),(360,640),(393,851),(768,1024)):
        c,pg=home(w,h)
        m=pg.evaluate("""()=>{const de=document.documentElement;const o=[...document.querySelectorAll('#s-home .top,#s-home .sqb,#s-home .hero,#s-home .mqc,#s-home .qa,#s-home .nth0')].map(e=>e.getBoundingClientRect());let ov=0;for(let i=0;i<o.length;i++)for(let j=i+1;j<o.length;j++)if(o[i].bottom>o[j].top+1&&o[i].top<o[j].top)ov++;
          const hello=document.querySelector('#s-home .hello').getBoundingClientRect();return{sx:de.scrollWidth>innerWidth,ov,h1:hello.height}}""")
        ok(f'K. {w}x{h}: sem rolagem lateral e sem sobreposição',not m['sx'] and m['ov']==0,m);c.close()
    # sem vidro (backdrop-filter) ainda legível: fundos continuam opacos o bastante
    c,pg=home(393,851,'light');r=pg.evaluate("getComputedStyle(document.querySelector('#s-home .qa button')).backdropFilter");ok('L. Vidro usa desfoque moderado (blur ≤ 24px)',r=='none' or int(__import__('re').search(r'(\d+)',r).group(1))<=24,r);c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
