"""v7.17: acabamentos (saldo da Home que fecha, calculadora no canto, Home/Relatórios/Ajustes mais curtos,
linhas tocáveis com excluir dentro da edição, textos de Despesas, Conquistas recolhidas, fontes >= 11px).
Só dados fictícios; Chromium simulado (sem aparelho real)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
BASE="""{owner:'Paulo',opening:{c:20000,d:'2026-01-01'},items:[
{id:'f1',t:'exp',d:'Aluguel',c:60000,day:5,cat:'Moradia',pay:'Pix',fixed:true,from:'2026-01',done:{'2026-11':60000}},
{id:'f2',t:'exp',d:'Internet',c:9900,day:10,cat:'Moradia',pay:'Pix',fixed:true,from:'2026-01',done:{}},
{id:'v1',t:'exp',d:'Mercado',c:25000,day:8,dt:'2026-11-08',cat:'Alimentação',pay:'Pix',fixed:false,ym:'2026-11',done:{'2026-11':25000}},
{id:'r1',t:'inc',d:'Salário',c:190000,day:5,cat:'Salário',pay:'Pix',fixed:true,from:'2026-01',done:{'2026-11':190000}},
{id:'r2',t:'inc',d:'Freela',c:30000,day:25,cat:'Extra',pay:'Pix',fixed:false,ym:'2026-11',dt:'2026-11-25',done:{}}],
inst:[{id:'i1',n:'Geladeira',c:100000,np:2,day:10,pay:'Pix',paid:0}],
parc:[{id:'p1',iid:'i1',ym:'2026-11',c:50000,paid:0},{id:'p2',iid:'i1',ym:'2026-12',c:50000,paid:0}],
debts:[{id:'d1',n:'Cartão Nubank',o:150000,due:'',pays:[{id:'q1',c:30000,d:'2026-10-01'}]}],
boxes:[{id:'b1',n:'Reserva',g:100000,m:0,dl:'',ic:'',moves:[{id:'m1',c:20000,d:'2026-11-02'}]}],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light',hint=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1"+(";window.__WS_FABHINT=1" if hint else ""))
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'Paulo')
        pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref()"%th)
        pg.evaluate("S=migrate("+BASE+");save();render()");pg.evaluate("vm='2026-11'");pg.evaluate("go('home')");pg.wait_for_timeout(200)
        return c,pg
    txt=lambda pg,sel:pg.evaluate("(()=>{const e=document.querySelector(%r);return e?e.innerText:null})()"%sel)
    num=lambda t:int(round(float(t.replace('R$','').replace('\xa0','').replace('.','').replace(',','.').replace('−','-').strip())*100))
    # ---------- 1. saldo da Home fecha ----------
    c,pg=app()
    r=pg.evaluate("""(()=>{const m=s=>[...document.querySelectorAll(s)].map(e=>e.textContent.trim());const big=document.querySelector('.hero .big').innerText,pills=m('.hero .pill'),sub=document.querySelector('#hsub').textContent;return{big,pills,sub}})()""")
    big=num(r['big']);val=lambda t:num(t.split('R$',1)[1] if 'R$' in t else t)
    def pv(t):  # valor (com sinal) depois do rótulo
        import re;m=re.search(r'(−|-)?\s*R\$\s*[\d.]+,\d\d',t);return num(m.group(0).replace(' ',''))
    rec=pv([x for x in r['pills'] if 'Recebido' in x][0]);pag=pv([x for x in r['pills'] if 'Pago' in x][0]);gd=[pv(x) for x in r['pills'] if 'Guardado' in x]
    import re
    mm=re.search(r'Inclui\s+((?:−|-)?\s*R\$\s*[\d.]+,\d\d)',r['sub']);prior=pv(mm.group(1)) if mm else 0
    ok('1. Saldo = (saldo inicial e outros meses) + recebido − pago − guardado/dívidas, com todas as parcelas visíveis na Home',big==prior+rec-pag-(gd[0] if gd else 0),r)
    ok('1. Texto explica de onde vem o ajuste ("saldo inicial e de outros meses")',mm is not None and 'outros meses' in r['sub'])
    ok('1. Valores do exemplo: saldo R$ 750, recebido 1.900, pago 850, guardado/dívidas 200, anterior −100',(big,rec,pag,gd,prior)==(75000,190000,85000,[20000],-10000),(big,rec,pag,gd,prior))
    # sem movimentos de dívida/caixinha no mês: não aparece a 3ª pílula e a conta continua fechando
    pg.evaluate("S.boxes=[];S.debts=[];save();render()")
    r2=pg.evaluate("[document.querySelector('.hero .big').innerText,[...document.querySelectorAll('.hero .pill')].map(e=>e.textContent.trim()),document.querySelector('#hsub').textContent]")
    ok('1. Sem dívidas/caixinhas no mês: só 2 pílulas e saldo = anterior + recebido − pago',len(r2[1])==2 and num(r2[0])==20000+190000-85000,r2)
    c.close()
    # ---------- 5. Home mais curta ----------
    c,pg=app()
    h=pg.evaluate("document.documentElement.scrollHeight")
    ok('5. Home com dados cabe em menos de 1.850 px (antes ≈1.930)',h<1850,h)
    home=txt(pg,'#app') or pg.inner_text('body')
    ok('5. Sem os cartões repetidos "Dívidas pendentes" e "Dinheiro guardado"; sem a frase "WOLFIN · Domine" dentro do saldo',pg.evaluate("![...document.querySelectorAll('.tile .lbl')].some(e=>/Dívidas pendentes|Dinheiro guardado/.test(e.innerText))")and 'WOLFIN · Domine' not in pg.inner_text('.hero'))
    pg.evaluate("document.querySelector('#s-home .hmore').open=true");pg.wait_for_timeout(200)
    secs=pg.evaluate("[...document.querySelectorAll('.sec')].map(e=>e.innerText.split('\\n')[0].trim().toUpperCase())")
    ok('5. Ordem: Próximos compromissos → Caixinhas → Dívidas → Este mês',secs==['PRÓXIMOS COMPROMISSOS','CAIXINHAS','DÍVIDAS','ESTE MÊS'],secs)
    ok('5. Atalhos Receita/Despesa/Guardar e 2 cartões (receitas previstas, despesas fixas) continuam',pg.evaluate("document.querySelectorAll('.qa button').length==3&&document.querySelectorAll('.g2 .tile').length>=2"))
    c.close()
    # ---------- saudação curta ----------
    for w in (320,360,393):
        c,pg=app(w=w)
        g=pg.evaluate("(()=>{const e=document.querySelector('.hello');const r=e.getBoundingClientRect();return{t:e.innerText,h:r.height,fs:parseFloat(getComputedStyle(e).fontSize)}})()")
        ok(f'G. {w}px: saudação curta ("Bom dia/Boa tarde/Boa noite, Paulo!"), uma linha (até 2 em 320px)',bool(__import__('re').match(r'^(Bom dia|Boa tarde|Boa noite), Paulo!$',g['t'])) and g['h']<=g['fs']*(1.5 if w>=360 else 3.2),g)
        c.close()
    # ---------- 2. calculadora no canto inferior direito + dica ----------
    c,pg=app(hint=True)
    m=pg.evaluate("""(()=>{const f=document.querySelector('#cfab').getBoundingClientRect(),n=document.querySelector('nav').getBoundingClientRect();return{fr:f.right,fb:f.bottom,ft:f.top,nt:n.top,iw:innerWidth,op:parseFloat(getComputedStyle(document.querySelector('#cfab')).opacity)}})()""")
    ok('2. Calculadora começa na borda direita, logo acima do menu inferior (não cobre mais o meio da tela)',abs(m['fr']-m['iw'])<=1 and m['nt']-m['fb']>=0 and m['nt']-m['fb']<=20,m)
    ok('2. Mais discreta (opacidade < 1 em repouso)',m['op']<1,m)
    pg.wait_for_timeout(2200)
    hv=pg.evaluate("(()=>{const e=document.querySelector('#fabhint');return e?e.innerText:null})()")
    ok('2. Dica de arrastar aparece na primeira vez',bool(hv) and 'arraste' in hv.lower(),hv)
    pg.wait_for_timeout(7600)
    ok('2. A dica some sozinha',pg.evaluate("!document.querySelector('#fabhint')"))
    pg.reload();pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(2600)
    ok('2. Depois de vista, a dica não volta',pg.evaluate("!document.querySelector('#fabhint')"))
    pg.evaluate("go('des');window.scrollTo(0,1e7)");pg.wait_for_timeout(250)
    ok('2. Na aba Despesas, ao rolar até o fim, nenhum botão (✓, adicionar…) fica coberto pela calculadora nem pelo menu',pg.evaluate("""(()=>{const f=document.querySelector('#cfab').getBoundingClientRect();return [...document.querySelectorAll('#s-des button')].every(b=>{const r=b.getBoundingClientRect();return r.bottom<=0||r.top>=innerHeight||r.right<=f.left||r.left>=f.right||r.bottom<=f.top||r.top>=f.bottom})})()"""))
    c.close()
    # ---------- 6. linhas tocáveis; excluir dentro da edição ----------
    c,pg=app();pg.evaluate("go('des')");pg.wait_for_timeout(200)
    ok('6. Despesas: nenhuma linha mostra botões "Editar"/"Excluir" soltos',pg.evaluate("![...document.querySelectorAll('#app button, main button, button')].some(b=>b.closest('.row')&&/^(Editar|Excluir)$/.test(b.innerText.trim()))"))
    ok('6. Dica "Toque em um item para editar ou excluir." aparece uma vez',pg.inner_text('body').count('Toque em um item para editar ou excluir.')==1)
    pg.click('.rm >> text=Internet');pg.wait_for_selector('#f')
    ok('6. Tocar na linha abre "Editar despesa" com valores certos e botão Excluir dentro',pg.inner_text('#ov h3')=='Editar despesa' and pg.input_value('#f [name=d]')=='Internet' and pg.locator('#ov .fdel').count()==1,pg.inner_text('#ov h3'))
    pg.click('#ov .fdel');pg.wait_for_timeout(150)
    ok('6. Excluir pede confirmação antes de apagar',pg.evaluate("S.items.some(x=>x.id==='f2')") and 'Confirmar' in pg.inner_text('#ov'))
    pg.click('#ov [data-act=yes]');pg.wait_for_timeout(250)
    ok('6. Confirmando, o lançamento é excluído',pg.evaluate("!S.items.some(x=>x.id==='f2')"))
    pg.evaluate("go('des')");pg.click('.rm >> text=Aluguel');pg.wait_for_selector('#f');pg.click('#ov [data-act=close]');pg.wait_for_timeout(150)
    ok('6. Cancelar a edição não apaga nada',pg.evaluate("S.items.some(x=>x.id==='f1')")and pg.evaluate("document.querySelector('#ov').hidden"))
    pg.click('[data-act=tog][data-id=v1]');pg.wait_for_timeout(200)
    ok('6. O botão ✓/↺ continua marcando sem abrir a edição',pg.evaluate("document.querySelector('#ov').hidden")and pg.evaluate("!S.items.find(x=>x.id==='v1').done['2026-11']"))
    pg.evaluate("go('rec')");pg.click('.rm >> text=Salário');pg.wait_for_selector('#f')
    ok('6. Receitas: mesma lógica (editar receita, excluir receita dentro)',pg.inner_text('#ov h3')=='Editar receita' and 'Excluir receita' in pg.inner_text('#ov .fdel'))
    pg.click('#ov [data-act=close]')
    # parcelada
    pg.evaluate("go('des')");pg.wait_for_timeout(150)
    ok('6. Parcelada: só "Linha do tempo" e "+ Parcela" ficam na tela; ✎ no cabeçalho edita',pg.evaluate("(()=>{const c=[...document.querySelectorAll('.card')].find(x=>x.innerText.includes('Geladeira'));const t=[...c.querySelectorAll('button')].map(b=>b.innerText.trim());return t.includes('Linha do tempo')&&t.includes('+ Parcela')&&!t.includes('Editar')&&!t.includes('Excluir')&&!!c.querySelector('[data-act=edinst]')})()"))
    pg.click('[data-act=edinst]');pg.wait_for_selector('#f')
    ok('6. Editar parcelada tem "Excluir despesa parcelada" dentro',pg.locator('#ov .fdel').count()==1)
    pg.click('#ov .fdel');pg.click('#ov [data-act=yes]');pg.wait_for_timeout(250)
    ok('6. Excluir parcelada remove o plano e as parcelas',pg.evaluate("S.inst.length===0&&S.parc.length===0"))
    # dívida
    pg.evaluate("go('div')");pg.wait_for_timeout(150)
    ok('6. Dívida: Pagar e Histórico ficam; Editar/Excluir saem da lista (✎ no cabeçalho)',pg.evaluate("(()=>{const t=[...document.querySelectorAll('.card button')].map(b=>b.innerText.trim());return t.includes('Pagar')&&t.some(x=>x.startsWith('Histórico'))&&!t.includes('Editar')&&!t.includes('Excluir')&&!!document.querySelector('[data-act=edd]')})()"))
    pg.click('[data-act=edd]');pg.wait_for_selector('#f');pg.click('#ov .fdel');pg.click('#ov [data-act=yes]');pg.wait_for_timeout(250)
    ok('6. Excluir dívida pela edição funciona',pg.evaluate("S.debts.length===0"))
    # caixinha
    pg.evaluate("go('cx')");pg.wait_for_timeout(150)
    ok('6. Caixinha: Guardar, Retirar e Histórico ficam; ✎ edita',pg.evaluate("(()=>{const t=[...document.querySelectorAll('.card button')].map(b=>b.innerText.trim());return ['Guardar','Retirar','Histórico'].every(x=>t.includes(x))&&!t.includes('Editar')&&!t.includes('Excluir')&&!!document.querySelector('[data-act=edb]')})()"))
    pg.click('[data-act=edb]');pg.wait_for_selector('#f')
    ok('6. Editar caixinha tem "Excluir caixinha"; o aviso de devolução do valor continua',pg.locator('#ov .fdel').count()==1)
    pg.click('#ov .fdel');ok('6. Aviso "voltam ao saldo disponível" na confirmação',pg.inner_text('#ov').find('voltam ao saldo disponível')>=0)
    pg.click('#ov [data-act=yes]');pg.wait_for_timeout(250)
    ok('6. Excluir caixinha funciona',pg.evaluate("S.boxes.length===0"))
    ok('6. Sem erros de página',not pg.errs,pg.errs)
    c.close()
    # ---------- 7. textos e ordem em Despesas ----------
    c,pg=app();pg.evaluate("go('des')");pg.wait_for_timeout(200)
    body=pg.inner_text('body')
    ok('7. "Já pagas" e "Previstas no mês" no lugar dos rótulos longos',('Já pagas' in body) and ('Previstas no mês' in body) and 'sem faturas de cartão' not in body)
    pos=pg.evaluate("['FIXAS','VARIÁVEIS','PARCELADAS'].map(t=>{const e=[...document.querySelectorAll('.sec')].find(x=>x.innerText.toUpperCase().startsWith(t));return e?e.getBoundingClientRect().top+scrollY:-1})")
    ok('7. Ordem: Fixas → Variáveis → Parceladas',pos[0]>0 and pos[0]<pos[1]<pos[2],pos)
    ok('7. Sem cartão cadastrado, a nota sobre faturas não aparece',not pg.evaluate("document.body.innerText.includes('Não inclui faturas de cartão')"))
    pg.evaluate("S.cards=[{id:'k1',n:'Cartão',lim:100000,cl:10,dd:20,buys:[],pays:[]}];save();render()");pg.wait_for_timeout(150)
    ok('7. Com cartão cadastrado, mostra a nota "Não inclui faturas de cartão: veja em Cartões."',pg.evaluate("document.body.innerText.includes('Não inclui faturas de cartão: veja em Cartões.')"))
    c.close()
    # ---------- 9. Ajustes ----------
    c,pg=app();pg.evaluate("go('cfg')");pg.wait_for_timeout(200)
    order=pg.evaluate("['Backup','Segurança','Aparência','Conquistas','Zerar todos os dados','Sobre'].map(t=>{const e=[...document.querySelectorAll('h3')].find(x=>x.innerText.trim()===t);return e?e.getBoundingClientRect().top+scrollY:-1})")
    ok('9. Ordem: Backup → Segurança → Aparência → Conquistas → Zerar → Sobre',all(x>0 for x in order) and order==sorted(order),order)
    ok('9. Rodapé sem texto de desenvolvedor (nada de "Painel de…", changelog da versão, contagem de lançamentos)',pg.evaluate("(()=>{const t=document.querySelector('.sys').innerText;return !/Painel de|intro|acabamentos|lançamento|dívida|caixinha/i.test(t)&&/offline/.test(t)})()"))
    ok('9. Versão continua na seção Sobre ("Versão 7.30")',pg.evaluate("/Versão 7\\.30/.test(document.body.innerText)"))
    ok('9. Aparência: Claro/Escuro visíveis; paletas, vidro e animações recolhidos',pg.evaluate("(()=>{const d=document.querySelector('details[data-det=aparencia]');return !!d&&!d.open&&!!document.querySelector('[data-act=theme]')&&d.querySelectorAll('.pal').length===9})()"))
    pg.click('details[data-det=aparencia] > summary');pg.click('.pal[data-id=teal]') if pg.locator('.pal[data-id=teal]').count() else pg.click('.pal >> nth=3')
    pg.wait_for_timeout(250)
    ok('9. Escolher uma paleta não fecha a seção e a cor muda',pg.evaluate("document.querySelector('details[data-det=aparencia]').open")and pg.evaluate("S.pref.pal!=='blue'"))
    pg.locator('[data-act=nav][data-id=conq]:visible').first.click();pg.wait_for_timeout(200)
    ok('9. "Ver conquistas" no cartão Conquistas abre as Conquistas',pg.evaluate("view==='conq'"))
    ok('9. Backup/Segurança/Zerar/Mascote continuam: ações exportar, importar, criptografar, zerar presentes',pg.evaluate("(go('cfg'),['exp','imp','expenc','reset','secon'].every(a=>!!document.querySelector('[data-act='+a+']')))"))
    c.close()
    # ---------- Conquistas ----------
    c,pg=app();pg.evaluate("go('conq')");pg.wait_for_timeout(200)
    cc=pg.evaluate("({vis:[...document.querySelectorAll('.agrid')].filter(g=>!g.closest('details')).reduce((a,g)=>a+g.children.length,0),det:(document.querySelector('details[data-det=conq]')||{}).open,hid:document.querySelectorAll('details[data-det=conq] .ab').length,h:document.documentElement.scrollHeight})")
    ok('Conquistas: só as 3 próximas aparecem; as demais ficam recolhidas',cc['vis']<=3+int(pg.evaluate("Object.keys(S.ach||{}).length")) and cc['hid']>=1 and not cc['det'],cc)
    ok('Conquistas: tela bem mais curta (< 1.200 px com o cartão do Wolfin; antes 1.800)',cc['h']<1200,cc['h'])
    pg.click('details[data-det=conq] > summary');pg.wait_for_timeout(150)
    ok('Conquistas: abrir mostra todas (15 no total entre visíveis e recolhidas)',pg.evaluate("document.querySelectorAll('.ab').length")==15)
    c.close()
    # ---------- 3. Relatórios ----------
    c,pg=app();pg.evaluate("go('rel')");pg.wait_for_timeout(300)
    h=pg.evaluate("document.documentElement.scrollHeight")
    ok('3. Relatórios cabe em menos de 3.600 px (antes ≈6.650)',h<3600,h)
    titles=pg.evaluate("[...document.querySelectorAll('h3')].map(e=>e.innerText.trim())")
    ok('3. Não repete mais: "Indicadores do mês" nem "Despesas por categoria" (a categoria única é "Gastos por categoria")',('Indicadores do mês' not in titles) and ('Despesas por categoria' not in titles) and 'Gastos por categoria' in titles,titles)
    ok('3. Resumo e comprometimento ficam abertos; seções extras recolhidas por padrão',pg.evaluate("['rec','div','cmp','hm','ano','shr'].every(i=>{const d=document.querySelector('details[data-det='+i+']');return d&&!d.open})")and 'Resumo do mês' in titles)
    ok('3. Dívidas vencidas e (se houver) limites entraram no bloco de contas do mês',pg.evaluate("document.body.innerText.includes('Dívidas vencidas')"))
    ok('3. "?" explica o saldo no início do mês (negativo: mostra motivo)',pg.evaluate("(()=>{const d=document.querySelector('details.why');if(!d)return false;d.open=true;return /negativo/.test(d.innerText)})()"))
    pg.click('details[data-det=cmp] > summary');pg.wait_for_selector('#rcA')
    pg.select_option('#rcA','2026-09');pg.wait_for_timeout(250)
    ok('3. Comparar dois meses: trocar o mês mantém a seção aberta',pg.evaluate("document.querySelector('details[data-det=cmp]').open")and pg.evaluate("rcA")=='2026-09')
    pg.click('details[data-det=hm] > summary');pg.wait_for_timeout(150)
    ok('3. Mapa de calor continua funcionando dentro da seção',pg.evaluate("document.querySelectorAll('details[data-det=hm] .hmc,details[data-det=hm] .cd,details[data-det=hm] [data-act=hmsel]').length")>0)
    pg.click('details[data-det=ano] > summary');pg.wait_for_timeout(150)
    ok('3. Gráficos do ano: 6 blocos + seletor de ano/mês na mesma seção',pg.evaluate("document.querySelectorAll('details[data-det=ano] .rch').length")==6 and pg.evaluate("!!document.querySelector('details[data-det=ano] #rmSel')"))
    pg.select_option('#rmSel','11');pg.wait_for_timeout(250)
    ok('3. Escolher o mês dos gráficos mantém a seção aberta e mostra os 4 números do mês',pg.evaluate("document.querySelector('details[data-det=ano]').open")and pg.evaluate("!!document.querySelector('details[data-det=ano] .grid')"))
    pg.click('details[data-det=shr] > summary');pg.wait_for_timeout(150)
    ok('3. Resumo para compartilhar continua (botão Criar imagem)',pg.evaluate("!!document.querySelector('details[data-det=shr] [data-act=rsopen]')"))
    ok('3. Sem erros de página',not pg.errs,pg.errs)
    c.close()
    # ---------- fontes e rolagem lateral ----------
    for w in (320,360,393):
        c,pg=app(w=w);res={}
        for v in ['home','rec','des','div','cx','rel','cfg','conq']:
            pg.evaluate("go('%s')"%v)
            if v=='rel':pg.evaluate("document.querySelectorAll('details.rdet').forEach(d=>d.open=true)")
            pg.wait_for_timeout(180)
            res[v]=pg.evaluate("""(()=>{let min=99,who='';document.querySelectorAll('body *').forEach(e=>{if(e.children.length&&e.tagName!=='text')return;if(!e.textContent.trim()||e.offsetParent===null&&e.tagName!=='text'&&!e.closest('svg'))return;if(e.closest('[hidden]'))return;const r=e.getBoundingClientRect();if(!r.width)return;const f=parseFloat(getComputedStyle(e).fontSize);if(f<min){min=f;who=e.tagName+'.'+e.className+':'+e.textContent.trim().slice(0,20)}});return{min,who,ovx:document.documentElement.scrollWidth>innerWidth+1,nav:[...document.querySelectorAll('nav button')].some(b=>b.scrollWidth>b.clientWidth+1)}})()""")
        bad={k:v for k,v in res.items() if v['min']<(11 if w>=360 else 9) or v['ovx'] or v['nav']}
        ok(f'F. {w}px: nenhum texto abaixo de 11px (em 320px: 9px só na barra inferior), sem rolagem lateral e sem rótulo cortado na barra inferior (8 telas)',not bad,bad)
        c.close()
    # ---------- tema escuro e dados ----------
    c,pg=app(th='dark')
    for v in ['home','rel','cfg','conq']:
        pg.evaluate("go('%s')"%v);pg.wait_for_timeout(150)
    pg.evaluate("go('rel');document.querySelectorAll('details.rdet').forEach(d=>d.open=true)")
    ok('D. Escuro: títulos das seções recolhíveis legíveis (contraste ≥ 4,5 contra o fundo do cartão)',pg.evaluate("""(()=>{const lum=c=>{const m=c.match(/[\\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};const s=document.querySelector('details.rdet > summary b'),card=document.querySelector('details.rdet');const fg=lum(getComputedStyle(s).color);let bg=card,col;while(bg){col=getComputedStyle(bg).backgroundColor;if(col&&!/rgba\\(.*,\\s*0\\)|transparent/.test(col))break;bg=bg.parentElement}const b=lum(col||'rgb(0,0,0)');return (Math.max(fg,b)+.05)/(Math.min(fg,b)+.05)>=4.5})()"""))
    ok('D. Estrutura dos dados intacta: mesmas chaves de S, nada novo guardado nas contas',pg.evaluate("JSON.stringify(Object.keys(S).sort())")==pg.evaluate("JSON.stringify(Object.keys(migrate(JSON.parse(JSON.stringify(S)))).sort())") and 'fabhint' not in pg.evaluate("JSON.stringify(S)"))
    ok('D. Sem erros de página',not pg.errs,pg.errs)
    c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
