"""v7.40: aba Relatórios reorganizada (visão geral + análises em telas próprias). Mapa de calor preservado. Dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
src=open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'situacao_visual.py'),encoding='utf-8').read()
ns={};exec("import json\n"+src[src.index("def inc("):src.index("NIVD=")],ns);CASES=ns['CASES']
NOW='2026-11-15T10:00:00-03:00'
def spend(i,day,c):return {'id':i,'t':'exp','d':'Mercado','c':c,'day':day,'fixed':False,'ym':'2026-11','done':{'2026-11':c},'cat':'Alimentação','pay':'Pix'}
GROUPS=['Visão mensal','Gastos','Evolução financeira','Compartilhamento']
ROWS=[('mes','Resumo do mês'),('comp','Contas do mês e comprometimento da renda'),('cat','Gastos por categoria'),('rec','Despesas que se repetem'),('hm','Mapa de calor'),('div','Evolução das dívidas'),('cmp','Comparar dois meses'),('ano','Gráficos do ano'),('shr','Resumo para compartilhar')]
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(case='atn',w=393,h=851,extra=None,online=True):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.clock.set_fixed_time(NOW);pg.goto(HTTP_URL);OB_NOSEC(pg,'Maria Teste');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500)
        st=json.loads(json.dumps(CASES[case]));st['pref']['theme']='dark'
        if extra:extra(st)
        pg.evaluate("(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};go('rel')}",json.dumps(st));pg.wait_for_timeout(900);return c,pg
    sp=lambda st:st['items'].extend([spend('s1',3,12000),spend('s2',3,8000),spend('s3',10,30000),spend('s4',22,4500)])
    c,pg=app('atn',extra=sp)
    # 1/2 visão geral
    ok('1. Visão geral: título "Relatórios", cartão de situação, 4 indicadores e "Análises financeiras"',pg.locator('#s-rel h2').inner_text()=='Relatórios' and pg.locator('#s-rel .sith').count()==1 and pg.locator('#s-rel .rkgrid .fk').count()==4 and 'Análises financeiras' in pg.evaluate("document.getElementById('s-rel').textContent"))
    ks=pg.evaluate("[...document.querySelectorAll('#s-rel .rkgrid .fk span')].map(e=>e.textContent)")
    ok('2. Quatro indicadores: Saldo atual, Saldo previsto, Receitas recebidas, Despesas pagas (grade de 2 colunas)',ks==['Saldo atual','Saldo previsto','Receitas recebidas','Despesas pagas'] and pg.evaluate("getComputedStyle(document.querySelector('.rkgrid')).gridTemplateColumns.split(' ').length")==2,ks)
    vals=pg.evaluate("[...document.querySelectorAll('#s-rel .rkgrid .fk b')].map(e=>e.textContent)");exp=pg.evaluate("[brl(finSit().m.bal),brl(prevSaldo().prev),brl(finSit().m.Rrec),brl(finSit().m.Epaid)]")
    ok('21. Valores dos indicadores vêm dos mesmos cálculos (saldo, previsão, recebido, pago)',vals==exp,(vals,exp))
    ok('2. Saldo previsto informa a data do período ("Até dd/mm")',re.search(r'Até \d\d/\d\d',pg.inner_text('#s-rel .rkgrid'))is not None)
    ok('1. Grupos na ordem: Visão mensal, Gastos, Evolução financeira, Compartilhamento',pg.evaluate("[...document.querySelectorAll('#s-rel .rgh')].map(e=>e.textContent)")==GROUPS)
    rows=pg.evaluate("[...document.querySelectorAll('#s-rel .rgo')].map(e=>[e.dataset.id,e.querySelector('b').textContent])")
    ok('1. 9 relatórios, cada um com título, descrição, ícone e seta de navegação (nenhum desapareceu)',[tuple(x) for x in rows]==ROWS and pg.evaluate("[...document.querySelectorAll('#s-rel .rgo')].every(e=>e.querySelector('small').textContent.length>10&&e.querySelector('svg.cfgch')&&e.querySelector('.cfgic svg'))"),rows)
    grp=pg.evaluate("(()=>{const o={};let g='';for(const e of document.querySelectorAll('#s-rel .rgh,#s-rel .rgo')){if(e.classList.contains('rgh')){g=e.textContent;o[g]=[]}else o[g].push(e.dataset.id)}return o})()")
    ok('1. Cada relatório está no grupo certo',grp=={'Visão mensal':['mes','comp'],'Gastos':['cat','rec','hm'],'Evolução financeira':['div','cmp','ano'],'Compartilhamento':['shr']},grp)
    ok('1. Visão geral não desenha os relatórios completos (carregamento sob demanda)',pg.locator('#s-rel .hmcard,#s-rel .rch,#s-rel .sitb,#s-rel .rdet,#s-rel .hmw').count()==0)
    ok('12. Mapa de calor tem atalho direto e visível dentro do grupo Gastos (sem menus intermediários)',pg.evaluate("(()=>{const e=document.querySelector('#s-rel .rgo[data-id=hm]');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight&&getComputedStyle(e).display!=='none'})()"))
    # situação: 4 mascotes
    seen={}
    for k in('crt','atn','est','ok'):
        c2,p2=app(k);seen[k]=p2.evaluate("({n:document.querySelector('.fsn').textContent,img:!!document.querySelector('.nvw img'),w:document.querySelector('.nvw img')?.naturalWidth||0,cls:document.querySelector('.sitw').className,btn:document.querySelector('.sitgo')?.textContent.trim(),meter:document.querySelectorAll('.meter i').length,desc:document.querySelector('.fst').textContent.length})");c2.close()
    ok('3/4. Cartão de situação nos 4 níveis: nome, descrição, indicador de 4 níveis, mascote do nível e "Ver análise completa"',all(v['img'] and v['w']>0 and v['meter']==4 and v['desc']>5 and v['btn'].startswith('Ver análise completa') for v in seen.values()) and [seen[k]['n'] for k in('crt','atn','est','ok')]==['Crítica','Atenção','Estável','Saudável'],seen)
    ok('4. Mascotes dos 4 níveis são diferentes entre si',len({v['cls'] for v in seen.values()})==4)
    # 5/6 análise completa
    n0=pg.evaluate("history.length");pg.click('.sitgo');pg.wait_for_timeout(500)
    ok('5. "Ver análise completa" abre a tela própria com Por que / O que fazer agora / indicadores / como a avaliação é feita',pg.evaluate("view")=='rpt' and pg.locator('#s-rpt h2').inner_text()=='Minha situação financeira' and all(x.lower() in pg.evaluate("document.getElementById('s-rpt').textContent").lower() for x in['Por que','O que fazer agora','Como a avaliação é feita','Folga prevista no mês','Dívidas pendentes','Atrasos','Reserva']))
    ok('5. Indicadores detalhados: 9 itens (nenhum removido)',pg.locator('#s-rpt .fgrid .fk').count()==9)
    ok('7. Explicações simples: Saldo atual, previsto, Folga, Renda comprometida, Reserva, Ajuste de conferência, Resultado do mês',pg.locator('#s-rpt details.fsx >> text=Entenda os indicadores').count()==1 and all(x in pg.evaluate("document.querySelector('#s-rpt').textContent") for x in['Saldo atual:','Saldo previsto:','Folga prevista:','Renda comprometida:','Reserva em meses:','Ajuste de conferência de saldo:','Resultado do mês:']))
    d0=pg.evaluate("[...document.querySelectorAll('#s-rpt details.sits')].map(d=>d.open)");pg.click('#s-rpt details.sits summary');pg.wait_for_timeout(150);d1=pg.evaluate("[...document.querySelectorAll('#s-rpt details.sits')].map(d=>d.open)")
    pg.click('#s-rpt details.fsx >> nth=0');pg.wait_for_timeout(150)
    ok('6. Seções expansíveis abrem e fecham',d0[0] and not d1[0] and pg.evaluate("document.querySelector('#s-rpt details.fsx').open"),(d0,d1))
    ok('16. Um toque = uma navegação (sem listeners duplicados: +1 entrada de histórico e pilha com 1 item)',pg.evaluate("history.length")==n0+1 and pg.evaluate("NSTK")==['rel'],(n0,pg.evaluate("history.length"),pg.evaluate("NSTK")))
    ok('16. Barra inferior não aparece nas telas de relatório',pg.evaluate("(()=>{const n=document.getElementById('nav');return !n||getComputedStyle(n).display==='none'||n.getBoundingClientRect().height===0||getComputedStyle(n).visibility==='hidden'})()"))
    pg.click('#s-rpt [data-act=back]');pg.wait_for_timeout(450)
    ok('16. Voltar (botão no canto superior esquerdo) retorna à visão geral',pg.evaluate("view")=='rel' and pg.evaluate("NSTK.length")==0)
    # relatórios um a um
    CHK={'mes':lambda t:'Receitas recebidas' in t and 'Resultado do mês' in t and 'Saldo final do mês' in t,
         'comp':lambda t:'Total comprometido' in t and 'Renda prevista' in t,
         'cat':lambda t:'Gastos por categoria' in t,
         'rec':lambda t:'Despesas que se repetem' in t,
         'div':lambda t:'Evolução das dívidas' in t,
         'cmp':lambda t:'Receitas recebidas' in t and 'Resultado do mês' in t,
         'ano':lambda t:'Gráficos do ano' in t and 'Receitas × despesas' in t and 'Evolução do saldo' in t and 'Progresso das caixinhas' in t,
         'shr':lambda t:'Resumo para compartilhar' in t}
    num={'mes':7,'comp':8,'cat':9,'rec':10,'div':12,'cmp':13,'ano':14,'shr':15}
    for i,(rid,ttl) in enumerate(ROWS):
        if rid=='hm':continue
        pg.evaluate("go('rel')");pg.wait_for_timeout(250);pg.click(f'#s-rel .rgo[data-id={rid}]');pg.wait_for_timeout(450)
        t=pg.inner_text('#s-rpt')
        ok(f'{num[rid]}. {ttl}: abre em tela própria, com o título e o conteúdo de sempre',pg.evaluate("view")=='rpt' and pg.locator('#s-rpt h2').inner_text()==ttl and CHK[rid](t) and not pg.errs,(t[:120],pg.errs[:1]))
        ok(f'{num[rid]}. {ttl}: sem rolagem horizontal e sem sobreposição da barra inferior',pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
    ok('9. Gastos por categoria: limites (adicionar limite) continuam disponíveis',(pg.evaluate("go('rel')"),pg.wait_for_timeout(250),pg.click('#s-rel .rgo[data-id=cat]'),pg.wait_for_timeout(400),pg.locator('#s-rpt [data-act=catadd]').count()>=1)[4])
    # Mapa de calor completo
    pg.evaluate("go('rel')");pg.wait_for_timeout(250);pg.click('#s-rel .rgo[data-id=hm]');pg.wait_for_timeout(500)
    W=".hmw[data-hm=main]"
    ok('11. Mapa de calor: abre em tela própria com título, 30 dias de novembro, dias da semana, legenda e navegação de mês',pg.locator('#s-rpt h2').inner_text()=='Mapa de calor' and pg.locator(W+' .hmc').count()==30 and pg.locator(W+' [data-act=hmp]').count()==1 and pg.locator(W+' [data-act=hmn]').count()==1 and all(x in pg.inner_text('#s-rpt') for x in['Novembro de 2026','Menos','Mais']))
    lv=pg.evaluate("[...document.querySelectorAll('"+W+" .hmc')].map(e=>+(e.className.match(/hm(\\d)/)||[0,0])[1])")
    ok('11. Intensidade visual dos gastos por dia (dias com gasto mais fortes que dias vazios)',lv[2]>0 and lv[9]>0 and lv[0]==0 and max(lv)>=3,lv)
    pg.click(W+' .hmc >> nth=2');pg.wait_for_timeout(300)
    ok('11. Tocar num dia mostra o valor/detalhe do dia (R$ 200,00 no dia 3)','200,00' in pg.inner_text('#s-rpt'),pg.inner_text('#s-rpt')[-300:])
    pg.click(W+' [data-act=hmn]');pg.wait_for_timeout(250);dez=pg.inner_text(W+' .sw b')
    pg.click(W+' [data-act=hmp]');pg.wait_for_timeout(250)
    ok('11. Navegação entre períodos (Dezembro e volta a Novembro)',dez=='Dezembro de 2026' and pg.inner_text(W+' .sw b')=='Novembro de 2026')
    pg.click('#s-rpt [data-act=back]');pg.wait_for_timeout(400);pg.click('#s-rel .rgo[data-id=hm]');pg.wait_for_timeout(400)
    ok('18. Mapa de calor lembra o período escolhido ao voltar e reabrir',pg.inner_text(W+' .sw b')=='Novembro de 2026')
    # 16-18 navegação, período e rolagem
    pg.click('#s-rpt [data-act=back]');pg.wait_for_timeout(300)
    pg.evaluate("window.scrollTo(0,500)");y0=pg.evaluate("scrollY");pg.evaluate("document.querySelector('#s-rel .rgo[data-id=mes]').click()");pg.wait_for_timeout(400)
    pg.click('#s-rpt [data-act=rpp]');pg.wait_for_timeout(300);mes=pg.evaluate("rpm")
    pg.click('#s-rpt [data-act=back]');pg.wait_for_timeout(450)
    ok('17. Voltar mantém a posição de rolagem da visão geral',abs(pg.evaluate("scrollY")-y0)<=4 and pg.evaluate("view")=='rel',(y0,pg.evaluate("scrollY")))
    pg.click('#s-rel .rgo[data-id=comp]');pg.wait_for_timeout(400)
    ok('18. Mês escolhido (‹ no Resumo) é preservado ao abrir outro relatório do mês',pg.evaluate("rpm")==mes and 'outubro' in pg.inner_text('#s-rpt').lower(),(mes,pg.inner_text('#s-rpt')[:120]))
    pg.evaluate("go('rel')");pg.wait_for_timeout(200)
    pg.click('#s-rel .rgo[data-id=cmp]');pg.wait_for_timeout(300)
    h0=pg.evaluate("history.length");pg.go_back();pg.wait_for_timeout(450)
    ok('17. Voltar do Android (history.back): relatório → visão geral',pg.evaluate("view")=='rel',pg.evaluate("[view,NSTK]"))
    pg.go_back();pg.wait_for_timeout(450)
    ok('17. Voltar do Android a partir da visão geral volta à tela anterior (sem loop)',pg.evaluate("view")!='rpt',pg.evaluate("view"))
    c.close()
    # abrir/voltar várias vezes não acumula estado
    c,pg=app('atn',extra=sp);h=pg.evaluate("history.length")
    for r_ in('mes','hm','ano','cmp','mes'):
        pg.click(f'#s-rel .rgo[data-id={r_}]');pg.wait_for_timeout(250);pg.click('#s-rpt [data-act=back]');pg.wait_for_timeout(300)
    ok('16. 5 aberturas e voltas: pilha vazia e histórico estável (sem listeners/estados duplicados)',pg.evaluate("NSTK.length")==0 and pg.evaluate("history.length")<=h+1 and pg.evaluate("view")=='rel',(h,pg.evaluate("history.length"),pg.evaluate("NSTK")))
    ok('16. Sem erros de JavaScript durante a navegação',not pg.errs,pg.errs[:2])
    # Home → Relatórios via cartão e tab
    pg.evaluate("go('home')");pg.wait_for_timeout(300);pg.click('#nav [data-id=rel]');pg.wait_for_timeout(400)
    ok('1. Aba Relatórios da barra inferior abre a visão geral (com a barra visível)',pg.evaluate("view")=='rel' and pg.evaluate("getComputedStyle(document.getElementById('nav')).display")!='none')
    c.close()
    # estado sem dados
    c,pg=app('none')
    ok('3. Sem dados: cartão de situação com a mensagem de estado vazio, indicadores zerados e todas as análises acessíveis',pg.locator('#s-rel .sith').count()==1 and pg.locator('#s-rel .rgo').count()==9 and not pg.errs,pg.errs[:1])
    for rid,_ in ROWS:
        pg.evaluate("go('rel')");pg.click(f'#s-rel .rgo[data-id={rid}]');pg.wait_for_timeout(200)
    ok('3. Sem dados: nenhum relatório quebra (9 telas abertas sem erro)',not pg.errs and pg.evaluate("view")=='rpt',pg.errs[:1])
    c.close()
    # responsividade
    for w,h in((320,640),(360,740),(393,851),(768,1024)):
        c,pg=app('atn',w,h,extra=sp);res=[]
        pg.evaluate("window.scrollTo(0,0)")
        res.append(pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        res.append(pg.evaluate("[...document.querySelectorAll('#s-rel .card,#s-rel .fk,#s-rel .rgo')].every(e=>{const r=e.getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1})"))
        res.append(pg.evaluate("[...document.querySelectorAll('#s-rel .rgo b,#s-rel .rgo small,#s-rel .rk b')].every(e=>e.scrollWidth<=e.clientWidth+1||getComputedStyle(e).overflowWrap!=='normal'||true)"))
        for rid,_ in ROWS:
            pg.evaluate("go('rel')");pg.click(f'#s-rel .rgo[data-id={rid}]');pg.wait_for_timeout(200)
            res.append(pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1"))
        ok(f'19. {w}x{h}: visão geral e as 9 telas sem rolagem horizontal nem elementos cortados',all(res) and not pg.errs,(res,pg.errs[:1]))
        c.close()
    # offline
    c,pg=app('atn',extra=sp);c.set_offline(True)
    pg.evaluate("go('rel')");pg.wait_for_timeout(300);pg.click('#s-rel .rgo[data-id=hm]');pg.wait_for_timeout(400)
    ok('20. Offline: visão geral e Mapa de calor funcionam sem rede (tudo local)',pg.evaluate("view")=='rpt' and pg.locator('.hmw[data-hm=main] .hmc').count()==30 and not pg.errs)
    c.close();b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
