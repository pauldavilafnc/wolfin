"""Wolfin, o lobo (v7.18): mascote único com 6 roupas (Mendigo → Magnata) que evoluem com o progresso financeiro ACUMULADO.
Estrutura e imagens, regras de nível, desbloqueio permanente, modo automático/escolher, galeria, cadastro, login, migração de contas e backups antigos,
animação, temas/telas pequenas, offline e console limpo. Só dados fictícios; Chromium simulado (sem celular real)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
NOMES=['Mendigo','Liso','Na média','Bem de vida','Patrão','Magnata']
def months(n,start='2026-10'):
    y,m=map(int,start.split('-'));r=[]
    for i in range(n):
        r.append(f'{y}-{m:02d}');m-=1
        if m==0:m=12;y-=1
    return r
def data(n,reserve=0,late=False,skip=None,bad=None):
    """n meses fechados (a partir de out/2026) com receita 3.000 e despesa 1.500; skip = mês sem movimento; bad = mês em que gastou mais do que ganhou"""
    ms=[k for k in months(n) if k!=skip]
    inc={k:300000 for k in ms};exp={k:(350000 if k==bad else 150000) for k in ms}
    items=[{'id':'r1','t':'inc','d':'Salário','c':300000,'day':5,'cat':'Salário','pay':'Pix','fixed':True,'from':'2024-01','done':inc},
           {'id':'f1','t':'exp','d':'Aluguel','c':150000,'day':5,'cat':'Moradia','pay':'Pix','fixed':True,'from':'2024-01','done':exp}]
    boxes=[{'id':'b1','n':'Reserva','g':5000000,'m':0,'dl':'','ic':'','moves':[{'id':'m1','c':reserve,'d':'2026-10-02'}]}] if reserve else []
    debts=[{'id':'d1','n':'Cartão','o':100000,'due':'2026-09-01','pays':[]}] if late else []
    return {'owner':'Paulo','opening':None,'items':items,'inst':[],'parc':[],'debts':debts,'boxes':boxes,'cards':[],'flags':{'tour':1}}
import json
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th=None,reduce=False,state=None,sw=False):
        c=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,is_mobile=w<600,has_touch=w<600,timezone_id='America/Sao_Paulo',reduced_motion='reduce' if reduce else 'no-preference',storage_state=state,color_scheme=th or 'light',service_workers='allow' if sw else 'block')
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1");return c
    def page(c):
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);return pg
    def newapp(w=393,h=851,th='light',reduce=False,d=None):
        c=ctx(w,h,th,reduce);pg=page(c);pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'Teste');pg.wait_for_function("document.getElementById('lock').hidden",timeout=10000)
        pg.evaluate(f"S.pref.theme='{th}';S.flags={{tour:1}};save();render()");pg.wait_for_timeout(300)
        if d is not None:setdata(pg,d)
        return c,pg
    def setdata(pg,d):
        pg.evaluate("d=>{d.pref=S.pref;d.ach=S.ach;S=migrate(d);save();render()}",d);pg.wait_for_timeout(150)
    ev=lambda pg,js,*a:pg.evaluate(js,*a) if a else pg.evaluate(js)
    lvof=lambda pg,d:(setdata(pg,d),ev(pg,"lvCalc().lv"))[1]
    # ===== A) estrutura e imagens =====
    c,pg=newapp()
    ok('Existe um único mascote (o Wolfin) com 6 roupas/níveis e os nomes combinados',ev(pg,"LV.map(x=>x.n)")==NOMES and ev(pg,"MCIDS")==['wolfin'])
    r=ev(pg,"""async()=>{const out=[];for(const k of Object.keys(MCB)){const im=new Image();im.src=mcUrl(k);await im.decode();out.push([k,im.naturalWidth,im.naturalHeight,MCB[k].length])}return out}""")
    ok('12 imagens (corpo inteiro f1–f6 e busto b1–b6) são WebP válidas, nas proporções certas (340×670 e 400×400) e leves (< 80 KB cada)',len(r)==12 and all((x[1],x[2])==((340,670) if x[0][0]=='f' else (400,400)) and x[3]<80000*4//3 for x in r),r)
    ok('Mascotes e avatares antigos foram removidos do código (10 personagens, escolha de personagem, pálpebras/orelhas por personagem)',ev(pg,"typeof MC==='undefined'&&typeof mcRows==='undefined'&&typeof mcGrid==='undefined'&&typeof mascotHtml==='undefined'&&typeof mcDef==='undefined'&&typeof SKV.leonidas==='undefined'")==True)
    ok('Conta nova: dados do mascote no padrão (mc="wolfin", lv=0 ainda não calculado, automático, sem roupa escolhida) e seed igual',ev(pg,"[S.pref.mc,S.pref.lm,S.pref.lp]")==['wolfin','a',0] and ev(pg,"seed().pref.lv")==0 and ev(pg,"seed().pref.lm")=='a')
    c.close()
    # ===== B) regras de nível (progresso acumulado) =====
    c,pg=newapp()
    cen=[('sem histórico (conta nova)',data(0),1),('1 mês fechado no azul',data(1),2),('2 meses no azul ainda é "Liso"',data(2),2),('3 meses seguidos no azul',data(3),3),
         ('6 meses no azul, mas sem reserva: continua "Na média"',data(6),3),('6 meses + reserva de 1 mês de gastos (R$ 1.500)',data(6,150000),4),('5 meses + reserva enorme: ainda 3 (faltam meses)',data(5,5000000),3),
         ('12 meses + reserva de 3 meses',data(12,450000),5),('12 meses + reserva de 3 meses, mas com dívida vencida: cai para 4',data(12,450000,True),4),
         ('18 meses + reserva de 6 meses',data(18,900000),6),('18 meses + reserva de 6 meses + dívida vencida: 4',data(18,900000,True),4),('12 meses + reserva de 6 meses: só 5 (faltam meses para o topo)',data(12,900000),5),
         ('um mês SEM movimento quebra a sequência (só o mês depois dele conta: 1 mês)',data(6,skip='2026-09'),2),('gastar mais do que ganhou no mês quebra a sequência',data(6,bad='2026-10'),1),('mês atual (novembro) não conta, só meses fechados',data(0),1)]
    bad=[(nm,got,exp) for nm,d,exp in cen for got in [lvof(pg,d)] if got!=exp]
    ok('Regras de nível: 15 cenários (meses seguidos no azul, reserva em meses de gastos, dívida vencida, quebra de sequência)',not bad,bad)
    setdata(pg,data(6,150000))
    st=ev(pg,"lvCalc().s")
    ok('A reserva é medida em meses de gastos: média das despesas dos últimos meses fechados (R$ 1.500) → R$ 1.500 guardados = 1,0 mês',abs(st['rm']-1.0)<1e-9 and st['m']==6 and st['avg']==150000,st)
    setdata(pg,data(3));nx=ev(pg,"lvNextLine()");ok('Texto do próximo nível diz exatamente o que falta ("Próxima roupa: Bem de vida… mais 3 meses… reserva…")',nx.startswith('Próxima roupa: Bem de vida') and 'mais 3 meses fechados no azul' in nx and 'reserva de 1 mês de gastos' in nx,nx)
    setdata(pg,data(18,900000));ok('No nível máximo o texto muda ("nível máximo")','nível máximo' in ev(pg,"lvNextLine()"))
    c.close()
    # ===== C) Home e Ajustes mostram a roupa certa (mesma imagem no avatar e no cartão) =====
    res=[]
    c,pg=newapp()
    for n,d in enumerate([data(0),data(1),data(3),data(6,150000),data(12,450000),data(18,900000)],1):
        setdata(pg,d);ev(pg,"go('home')");pg.wait_for_timeout(120)
        h=ev(pg,"""(()=>{const a=document.querySelector('#avh .mcav img'),m=document.querySelector('#s-home .mqc .mc'),i=m&&m.querySelector('img');return{av:a&&a.src,mc:m&&m.dataset.lv,img:i&&i.src,exp:mcUrl('b'+mcCur()),cur:mcCur(),lbl:document.querySelector('#avh').getAttribute('aria-label'),al:m&&m.getAttribute('aria-label'),ok:!!(i&&i.complete&&i.naturalWidth>0)}})()""")
        res.append((n,h['cur']==n and h['av']==h['exp'] and h['img']==h['exp'] and h['mc']==str(n) and h['ok'] and NOMES[n-1] in h['lbl'] and NOMES[n-1] in h['al'] and f'nível {n}' in h['lbl']))
    ok('Home: o avatar do cabeçalho e o mascote do cartão mostram a MESMA roupa (imagem do nível), com nome e nível no texto de acessibilidade, para os 6 níveis',all(x[1] for x in res),res)
    ev(pg,"go('cfg')");pg.wait_for_timeout(250);cf=ev(pg,"(()=>{const c=document.querySelector('#s-cfg .mcnow');return{lv:c.querySelector('.mc').dataset.lv,t:c.innerText,n:document.querySelector('#s-cfg').innerText.split('Meu mascote').length-1}})()")
    ok('Ajustes → Meu mascote: mostra o nível atual, nome, roupa automática, o que falta e os botões "Trocar de roupa" e "Ver conquistas"; uma única seção',cf['lv']=='6' and 'Wolfin · Nível 6' in cf['t'] and 'Magnata' in cf['t'] and cf['n']==1 and pg.locator('#s-cfg [data-act=avs]').inner_text()=='Trocar de roupa' and 'nível máximo' in pg.inner_text('#s-cfg'),cf)
    ev(pg,"go('home')");pg.wait_for_timeout(150);av=ev(pg,"(()=>{const i=document.querySelector('#avh .mcav img'),r=document.querySelector('#avh').getBoundingClientRect();return{w:r.width,h:r.height,same:i.src===mcUrl('b'+mcCur())}})()")
    ok('O avatar é recorte do rosto da MESMA imagem do busto e tem 44 px (alvo de toque)',av['same'] and av['w']>=44 and av['h']>=44,av)
    c.close()
    # ===== D) desbloqueio permanente, celebração e modo automático =====
    c,pg=newapp()
    ok('Conta nova: 1ª sincronização guarda o nível sem comemorar (lv=1) e o Wolfin começa como Mendigo',ev(pg,"S.pref.lv")==1 and ev(pg,"mcCur()")==1)
    setdata(pg,data(3));ev(pg,"commit('x')");pg.wait_for_timeout(250)
    ok('Subir de nível libera a roupa para sempre (S.pref.lv = 3) e avisa "Roupa nova: Na média!"',ev(pg,"S.pref.lv")==3 and 'Roupa nova: Na média' in pg.inner_text('#toast'),pg.inner_text('#toast'))
    pg.wait_for_timeout(400);ok('O balão do Wolfin também comemora a roupa nova (e não diz "conquista")','Roupa nova liberada: Na média' in ev(pg,"mqSay()[1]") or ev(pg,"MQH.lv")==1,ev(pg,"mqSay()[1]"))
    setdata(pg,data(0));ev(pg,"commit('y')");pg.wait_for_timeout(200)
    ok('Se a situação piora (sem histórico), o modo automático volta a mostrar Mendigo, mas a roupa liberada continua sua (S.pref.lv segue 3)',ev(pg,"mcCur()")==1 and ev(pg,"S.pref.lv")==3 and ev(pg,"lvTop()")==3)
    ev(pg,"go('cfg')");pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .lvc');pg.wait_for_timeout(250)
    g=ev(pg,"[...document.querySelectorAll('#ov .lvc')].map(x=>({n:x.querySelector('b').textContent,lock:x.classList.contains('lock'),dis:x.getAttribute('aria-disabled'),on:x.classList.contains('on'),q:(x.querySelector('.lvq')||{}).textContent||'',lbl:x.getAttribute('aria-label')}))")
    ok('Galeria: 6 roupas; as 3 liberadas selecionáveis e as 3 bloqueadas mostram o que falta (texto) e aria-disabled; a atual (Mendigo) está destacada',[x['n'] for x in g]==NOMES and [x['lock'] for x in g]==[False]*3+[True]*3 and [x['dis'] for x in g]==[None]*3+['true']*3 and [x['on'] for x in g]==[True]+[False]*5 and 'reserva de 1 mês' in g[3]['q'] and '18 meses' in g[5]['q'] and all('Para liberar' in x['lbl'] for x in g[3:]),g)
    pg.click('#ov .lvc >> nth=4',force=True);pg.wait_for_timeout(250)
    ok('Tocar numa roupa BLOQUEADA não escolhe: explica o que falta e nada muda',ev(pg,"LVT.m")=='a' and 'Bloqueada' in pg.inner_text('#toast') and ev(pg,"document.querySelectorAll('#ov .lvc.on').length")==1 and ev(pg,"S.pref.lm")=='a')
    pg.click('#ov .lvc >> nth=2');pg.wait_for_timeout(200)
    ok('Tocar numa roupa liberada muda para "Escolher" e mostra a prévia dela, sem salvar ainda',ev(pg,"LVT.m")=='m' and ev(pg,"document.querySelector('#ov .mcpv .mc').dataset.lv")=='3' and ev(pg,"S.pref.lm")=='a' and pg.locator('#ov .lvseg button.on').inner_text()=='Escolher')
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(150)
    ok('Cancelar fecha sem alterar nada',ev(pg,"[S.pref.lm,S.pref.lp,mcCur()]")==['a',0,1] and pg.locator('#ov .sheet').count()==0)
    pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .lvc');pg.click('#ov .lvc >> nth=2');pg.click('#ov [data-act=lvok]');pg.wait_for_timeout(300)
    s=ev(pg,"""()=>({lm:S.pref.lm,lp:S.pref.lp,cur:mcCur(),av:document.querySelector('#avh .mcav img').src===mcUrl('b3'),card:document.querySelector('#s-cfg .mcnow .mc').dataset.lv,set:S.pref.av.set,sv:JSON.parse(localStorage.getItem('wallstreet.v1')).pref.lp,look:JSON.parse(localStorage.getItem('wallstreet.look')).v,tx:document.querySelector('#s-cfg .mcnow').innerText})""")
    ok('Confirmar "Escolher Na média": o Wolfin passa a vestir essa roupa mesmo com situação pior (avatar, cartão, aparência do login e conta salvos)',s['lm']=='m' and s['lp']==3 and s['cur']==3 and s['av'] and s['card']=='3' and s['sv']==3 and s['look']==3 and 'roupa escolhida' in s['tx'],s)
    ok('A conquista "Cara própria" passa a significar escolher a roupa e é concedida ao confirmar',ev(pg,"S.pref.av.set")==1 and 'roupa' in ev(pg,"ACH.find(a=>a.id==='av').d") and ev(pg,"!!S.ach.av"))
    pg.reload();pg.wait_for_selector('#nav');pg.wait_for_timeout(700)
    ok('Persistência após recarregar: a roupa escolhida e as roupas liberadas continuam',ev(pg,"[S.pref.lm,S.pref.lp,S.pref.lv,mcCur()]")==['m',3,3,3])
    pg.evaluate("go('cfg')");pg.click('#s-cfg [data-act=avs]');pg.wait_for_selector('#ov .lvc');pg.click('#ov .lvseg button >> nth=0');pg.wait_for_timeout(150);pg.click('#ov [data-act=lvok]');pg.wait_for_timeout(250)
    ok('Voltar para "Automática" acompanha a situação de novo (volta a Mendigo) e avisa',ev(pg,"S.pref.lm")=='a' and ev(pg,"mcCur()")==1 and 'automática' in pg.inner_text('#toast').lower())
    setdata(pg,data(18,900000));ev(pg,"commit('z')");pg.wait_for_timeout(200)
    ok('Subir de uma vez para o topo libera todas as roupas (lv = 6)',ev(pg,"S.pref.lv")==6 and ev(pg,"mcCur()")==6)
    ev(pg,"go('cfg')");pg.wait_for_timeout(200);pg.click('[data-act=reset]');pg.fill('#f [name=t]','zerar');pg.click('#f button[type=submit]');pg.wait_for_timeout(500)
    ok('"Zerar todos os dados" também zera as roupas liberadas (lv/lp/lm voltam ao início; o resto das preferências continua)',ev(pg,"[S.pref.lv,S.pref.lp,S.pref.lm]")in([1,0,'a'],[0,0,'a']) and ev(pg,"S.items.length")==0 and ev(pg,"S.pref.theme")=='light',ev(pg,"[S.pref.lv,S.pref.lp,S.pref.lm,S.items.length]"))
    c.close()
    # ===== E) galeria: layout, teclado e telas pequenas =====
    for (w,h,th) in ((393,851,'light'),(393,851,'dark'),(360,740,'light'),(320,568,'dark')):
        c,pg=newapp(w,h,th,d=data(6,150000));ev(pg,"go('home')");pg.click('#avh');pg.wait_for_selector('#ov .lvc');pg.wait_for_timeout(350)
        g=ev(pg,"""()=>{const s=document.querySelector('#ov .sheet').getBoundingClientRect(),bt=[...document.querySelectorAll('#ov .btns button')].map(b=>b.getBoundingClientRect()),cs=[...document.querySelectorAll('#ov .lvc')].map(c=>c.getBoundingClientRect()),sg=[...document.querySelectorAll('#ov .lvseg button')].map(b=>b.getBoundingClientRect());
          const l=document.querySelector('#ov .lvlist');return{fits:s.bottom<=innerHeight+1&&s.top>=0,btns:bt.every(b=>b.bottom<=innerHeight+1&&b.height>=44),seg:sg.every(b=>b.height>=44),sx:document.documentElement.scrollWidth<=innerWidth+1,cols:[...new Set(cs.map(c=>Math.round(c.left)))].length,imgs:[...document.querySelectorAll('#ov .lvc img')].every(i=>i.complete&&i.naturalWidth>0),th:document.documentElement.dataset.theme,scroll:l.scrollHeight>=l.clientHeight}}""")
        ok(f'Galeria {w}×{h} ({th}): cabe na tela, botões e seletor com 44 px, 3 colunas, imagens carregadas, sem rolagem lateral',g['fits'] and g['btns'] and g['seg'] and g['sx'] and g['cols']==3 and g['imgs'] and g['th']==th,g)
        if (w,th)==(320,'dark'):
            lk=ev(pg,"(()=>{const c=document.querySelector('#ov .lvc.lock .lvi img');return getComputedStyle(c).filter})()")
            ok('Roupas bloqueadas aparecem como silhueta cinza (filtro) também no tema escuro',lk and 'brightness' in lk,lk)
            pg.focus('#ov .lvseg button >> nth=1');pg.keyboard.press('Enter');pg.wait_for_timeout(200)
            fo=ev(pg,"document.activeElement&&document.activeElement.dataset&&document.activeElement.dataset.act+'|'+document.activeElement.dataset.id")
            ok('Teclado: depois de trocar o modo, o foco continua no mesmo botão (a lista é redesenhada sem perder o foco)',fo=='lvmode|m',fo)
            ok('Cartões têm papel de opção (radio) com aria-checked e o seletor Automática/Escolher é um grupo de opções',ev(pg,"document.querySelectorAll('#ov [role=radiogroup] [role=radio]').length")==8 and ev(pg,"document.querySelectorAll('#ov .lvc[aria-checked=true]').length")==1)
        c.close()
    c,pg=newapp(d=data(6,150000))
    ev(pg,"go('home')");pg.click('#avh');pg.wait_for_selector('#ov .lvc');pg.keyboard.press('Escape');pg.wait_for_timeout(250)
    ok('Console sem erros ao abrir a galeria',not pg.errs,pg.errs[:2]);c.close()
    # ===== F) cadastro (etapa 1) e login =====
    c=ctx();pg=page(c);pg.goto(HTTP_URL);pg.wait_for_selector('#mf',timeout=8000);pg.wait_for_timeout(500)
    rows=ev(pg,"[...document.querySelectorAll('#mf .mcrow')].map(r=>({n:r.querySelector('b').textContent,s:r.querySelector('small').textContent,img:!!r.querySelector('img'),btn:r.tagName}))")
    ok('Etapa 1 do cadastro ("Conheça o Wolfin"): mostra as 6 roupas com nome e nível (sem escolher personagem) e o Continuar já está liberado',[r['n'] for r in rows]==NOMES and [r['s'] for r in rows]==[f'Nível {i}' for i in range(1,7)] and all(r['img'] for r in rows) and not pg.locator('#mgo').is_disabled() and 'Conheça o Wolfin' in pg.inner_text('#lock'),rows)
    ok('No cadastro o Wolfin aparece de "Na média" (neutro e simpático) e a conta nova começa como Mendigo',ev(pg,"document.querySelector('#lock .wolf').dataset.lv")=='3')
    pg.click('#mgo');pg.wait_for_selector('#cf');ok('Continuar leva à etapa 2 (aparência) e o resto do cadastro segue igual',pg.locator('.obdots[aria-label="Etapa 2 de 3"]').count()==1)
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('[data-lk=new]');ok('Etapa 3: "Oi, eu sou Wolfin!"','Oi, eu sou Wolfin!' in pg.inner_text('#lock'))
    pg.click('[data-lk=new]');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]','Teste');pg.click('#nf button')
    pg.wait_for_selector('#sf',timeout=8000);pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(500)
    ok('Conta criada (com senha): o app abre com o Wolfin Mendigo e o avatar bate com o cartão',ev(pg,"S.pref.mc")=='wolfin' and ev(pg,"mcCur()")==1 and ev(pg,"document.querySelector('#avh .mcav img').src===mcUrl('b1')"))
    ev(pg,"d=>{d.pref=S.pref;d.ach=S.ach;S=migrate(d);applyPref();save()}",data(12,450000));pg.wait_for_timeout(300)
    ok('A aparência do login guarda a roupa atual (look.v = 5) sem guardar dados financeiros',ev(pg,"JSON.parse(localStorage.getItem('wallstreet.look')).v")==5 and 'Salário' not in ev(pg,"localStorage.getItem('wallstreet.look')"))
    st=c.storage_state();pg.wait_for_timeout(2500);c.close()
    c2=ctx(state=st);pg=page(c2);pg.goto(HTTP_URL);pg.wait_for_selector('#lf',timeout=20000);pg.wait_for_timeout(500)
    ok('Tela de login (conta com senha, após recarregar): mostra o Wolfin na roupa do último uso (Patrão, nível 5), sem decifrar nada',ev(pg,"document.querySelector('#lock .wolf').dataset.lv")=='5' and ev(pg,"typeof S==='undefined'||!S||!S.items||S.items.length===0"))
    pg.focus('#lf [name=p]');pg.wait_for_timeout(250);cl=ev(pg,"document.querySelector('#lock .wolf').classList.contains('cl')");t1=ev(pg,"getComputedStyle(document.querySelector('#lock .wolf .mci')).transform")
    pg.focus('#lf [name=u]');pg.wait_for_timeout(250);dn=ev(pg,"document.querySelector('#lock .wolf').classList.contains('dn')")
    ok('Login: o Wolfin reage ao foco (abaixa a cabeça no campo de senha; estado "dn" no usuário) — sem as pálpebras antigas',cl and dn and t1!='none',(cl,dn,t1))
    pg.fill('#lf [name=u]','teste');pg.fill('#lf [name=p]','Senha-Forte-123');pg.click('#lf button:not([type=button])');pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000);pg.wait_for_timeout(900)
    ok('Depois de entrar de novo: o avatar e o cartão seguem a roupa certa (os dados voltam do cofre)',ev(pg,"document.querySelector('#avh .mcav img').src===mcUrl('b'+mcCur())") and ev(pg,"typeof mcCur()")=='number')
    c2.close()
    # ===== G) migração de contas e backups antigos =====
    c,pg=newapp()
    cases=[('mascote antigo Nyx → Wolfin',{'mc':'nyx','av':{'v':2,'m':8,'an':1,'set':1},'ms':'terno'}),('avatar antigo (tigre) → Wolfin',{'av':{'v':2,'m':3,'an':1,'set':1},'ms':'terno'}),('roupa antiga Rei → Wolfin',{'av':{'v':2,'m':0,'an':1,'set':0},'ms':'rei'}),('mascote inexistente → Wolfin',{'mc':'zzz'}),('sem campo nenhum → Wolfin',{})]
    bad=[]
    for nm,pf in cases:
        got=ev(pg,"""pf=>{const o=JSON.parse(JSON.stringify(S));o.pref=Object.assign({theme:'light',pal:'blue'},pf);const r=migrate(o);return {mc:r.pref.mc,lv:r.pref.lv,lm:r.pref.lm,lp:r.pref.lp,items:r.items.length}}""",pf)
        if got['mc']!='wolfin' or got['lm']!='a' or got['lp']!=0 or got['lv']!=0:bad.append((nm,got))
    ok('Migração: qualquer mascote/avatar/roupa antigo vira o Wolfin e os campos novos recebem valores válidos (automático, nível ainda não calculado)',not bad,bad)
    got=ev(pg,"""()=>{const o=JSON.parse(JSON.stringify(S));o.pref.lv=99;o.pref.lm='x';o.pref.lp=-3;const a=migrate(o).pref;const q=JSON.parse(JSON.stringify(S));q.pref.lv='3';q.pref.lm='m';q.pref.lp=5.7;const b=migrate(q).pref;return [[a.lv,a.lm,a.lp],[b.lv,b.lm,b.lp]]}""")
    ok('Valores inválidos de lv/lm/lp (fora do intervalo, texto, lixo) são corrigidos sem erro; valores válidos são mantidos',got[0]==[0,'a',0] and got[1]==[3,'m',5],got)
    mig=ev(pg,"""()=>{const o=JSON.parse(JSON.stringify(S));o.items.push({id:'t1',t:'inc',d:'Salário',c:300000,day:5,fixed:true,from:'2026-01',done:{},cat:'Salário'});o.debts.push({id:'d1',n:'Dívida',o:50000,due:'',pays:[]});delete o.pref.mc;o.pref.av={v:2,m:3,an:0,set:1};o.pref.ms='jazz';const r=migrate(o);return {items:r.items.length,debts:r.debts.length,an:r.pref.av.an,av:r.pref.av.m,ms:r.pref.ms,mc:r.pref.mc}}""")
    ok('A migração preserva tudo: dados financeiros, animações dos ícones e os campos antigos (av, ms) continuam gravados',mig['items']==1 and mig['debts']==1 and mig['an']==0 and mig['av']==3 and mig['ms']=='jazz' and mig['mc']=='wolfin',mig)
    ix=json.load(open(os.path.join(FIX,'backups','index.json'),encoding='utf-8'));badb=[]
    for e in [x for x in ix['arquivos'] if not x['enc']]:
        txt=open(os.path.join(FIX,'backups',e['file']),encoding='utf-8').read()
        r=ev(pg,"""t=>{const o=migrate(JSON.parse(t));return {mc:o.pref&&o.pref.mc,lv:o.pref&&o.pref.lv,lm:o.pref&&o.pref.lm,items:o.items.length,debts:o.debts.length,boxes:o.boxes.length}}""",txt)
        if not(r['mc']=='wolfin' and r['lv']==0 and r['lm']=='a' and r['items']==3 and r['debts']==1 and r['boxes']==1):badb.append((e['file'],r))
    ok('Backups de várias versões anteriores (fixtures) abrem no sistema novo: Wolfin definido, roupa automática e receitas, despesas, dívidas e caixinhas intactas',not badb and len([x for x in ix['arquivos'] if not x['enc']])>=10,badb[:2])
    setdata(pg,data(6,150000));ev(pg,"commit('x')");ev(pg,"S.pref.lm='m';S.pref.lp=3;save()")
    exp=json.loads(ev(pg,"(async()=>{const t=await bkpExportText();return t})()"))
    ok('Backup novo guarda as roupas (lv, lm, lp) e continua com o marcador compatível "wallstreet-backup"',exp['pref']['lv']==4 and exp['pref']['lm']=='m' and exp['pref']['lp']==3 and exp['pref']['mc']=='wolfin' and exp['__backup']['app']=='wallstreet-backup',exp['pref'])
    sig=ev(pg,"bkpSig(S)");ev(pg,"S.pref.lp=2");ok('A assinatura do backup (aviso de "alterações desde o último backup") não muda só por trocar de roupa',ev(pg,"bkpSig(S)")==sig)
    c.close()
    # ===== H) falas =====
    c,pg=newapp()
    miss=[]
    for n,d in enumerate([data(0),data(1),data(3),data(6,150000),data(12,450000),data(18,900000)],1):
        setdata(pg,d);ev(pg,"S.items.forEach(i=>{i.done['2026-11']=i.c})");ev(pg,"S.debts=[];save()")
        seen=ev(pg,"(()=>{const a=new Set();for(let i=0;i<40;i++){MQH.i=i;a.add(mqSay()[1])}MQH.i=0;return [...a]})()")
        L=ev(pg,"LVQ[%d]"%(n-1))
        if not any(x in seen for x in L):miss.append(n)
    ok('Cada roupa tem falas próprias no balão da Home (3 por nível), misturadas com as dicas de sempre',not miss and ev(pg,"LVQ.length")==6 and all(len(x)==3 for x in ev(pg,"LVQ")),miss)
    c.close()
    # ===== I) animação e imagem do resumo =====
    c,pg=newapp(d=data(12,450000))
    an=ev(pg,"""()=>{const el=document.querySelector('#s-home .mqc .mc');const as=el.getAnimations({subtree:true});const p=new Set();as.forEach(a=>(a.effect.getKeyframes()||[]).forEach(k=>Object.keys(k).forEach(x=>{if(!['offset','easing','composite','computedOffset'].includes(x))p.add(x)})));return{n:as.length,p:[...p]}}""")
    ok('Animação do Wolfin: respiração e balanço da cabeça (só transform), no máximo 3 animações por mascote',an['n']>=1 and an['n']<=3 and set(an['p'])<={'transform','opacity'},an)
    im=ev(pg,"(async()=>{const i=await rsImg();return i&&[i.naturalWidth,i.naturalHeight]})()")
    ok('A imagem de resumo do mês usa o busto da roupa atual (400×400)',im==[400,400],im)
    c.close()
    c,pg=newapp(reduce=True,d=data(12,450000));pg.wait_for_timeout(200)
    ok('Movimento reduzido: o Wolfin fica parado (nenhuma animação)',ev(pg,"[...document.querySelectorAll('.mc')].every(el=>el.getAnimations({subtree:true}).length===0)")==True)
    ok('Sem erros no console durante toda a suíte',not pg.errs,pg.errs[:2]);c.close()
    # ===== J) offline / PWA: imagens embutidas =====
    reqs=[];c=ctx(sw=True);pg=page(c);pg.on('request',lambda r:reqs.append(r.url.split('/')[-1]) if re.search(r'\.(webp|png|jpe?g|svg)(\?|$)',r.url) and 'icon' not in r.url and 'favicon' not in r.url and 'apple' not in r.url else None)
    pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_function("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))",timeout=15000);pg.reload();pg.wait_for_function("!!navigator.serviceWorker.controller",timeout=15000);pg.wait_for_selector('#avh');pg.wait_for_timeout(500)
    c.set_offline(True);pg=page(c);pg.goto(HTTP_URL,wait_until='commit');pg.wait_for_selector('#avh',timeout=10000);pg.wait_for_timeout(500)
    imgs=ev(pg,"[...document.querySelectorAll('#avh img,#s-home .mqc img')].map(i=>i.complete&&i.naturalWidth>0)")
    ok('Offline (PWA): o avatar e o Wolfin aparecem sem internet e nenhum arquivo de imagem do mascote é baixado da rede (estão embutidos)',len(imgs)>=2 and all(imgs) and not reqs and not pg.errs,(imgs,reqs[:3],pg.errs[:2]));c.close()
print(sum(R),'/',len(R))
