"""v7.35: o pacote de imagens do mascote (wolfin-brasil.js, ~700 KB) só é baixado quando algum mascote/moeda precisa aparecer."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    def abre(on,view=None):
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("(m)=>{S.pref.wf=Object.assign({},S.pref.wf,{on:m});save()}",on);pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=10000);pg.wait_for_timeout(1200)
        if view:pg.evaluate("go('%s')"%view);pg.wait_for_timeout(1500)
        return c,pg
    files=lambda pg:pg.evaluate("performance.getEntriesByType('resource').map(r=>r.name.split('/').pop())")
    c,pg=abre(1);f=files(pg)
    ok('1. Mascote ligado: o pacote do mascote carrega e o Wolfin aparece pintado na Home',any('wolfin-brasil' in x for x in f) and pg.evaluate("!!WF.ok") and pg.locator('#s-home .mqc [data-p]').count()>=1,f);c.close()
    c,pg=abre(0);f=files(pg)
    ok('2. Mascote desligado: a Home NÃO baixa wolfin-brasil.js nem wolfin-estilos.js',not any('wolfin-brasil' in x or 'wolfin-estilos' in x for x in f),f)
    ok('2b. Mascote desligado: o cartão de dicas e o saldo continuam funcionando',pg.inner_text('#s-home .mqc').strip()!='' and 'Saldo atual' in pg.inner_text('#s-home .hero'));c.close()
    c,pg=abre(0,'loja');f=files(pg)
    ok('3. Mascote desligado → abrir a Loja carrega os pacotes na hora e as prévias são pintadas',any('wolfin-brasil' in x for x in f) and pg.evaluate("!!WF.ok") and pg.locator('#s-loja .wolf[data-p]').count()>=1,(f,pg.locator('#s-loja .wolf').count()))
    pg.evaluate("S.pref.wf.on=1;save();go('home')");pg.wait_for_timeout(1200)
    ok('4. Religar o mascote depois (sem recarregar) mostra o Wolfin na Home',pg.locator('#s-home .mqc [data-p]').count()>=1 and not pg.errs,pg.errs[:2]);c.close()
    c,pg=abre(0,'conq');pg.evaluate("go('conq')");pg.wait_for_timeout(800)
    ok('5. Mascote desligado → Conquistas: sem erros e a moeda (WolfCoins) é carregada quando aparece',not pg.errs and (pg.locator('#s-conq img[data-coin]').count()==0 or pg.evaluate("document.querySelectorAll('#s-conq img[data-coin][src]').length")>=1),pg.errs[:2]);c.close()
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
