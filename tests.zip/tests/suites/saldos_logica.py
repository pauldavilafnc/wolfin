"""v7.32: saldo ATUAL (dinheiro que existe) x saldo PREVISTO (projeção), saldo inicial com data de referência, alertas e cartão da Home.
Os 18 cenários pedidos, mais persistência, importação, cálculos e escopo. Só dados fictícios (R$ em centavos)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
NOW='2026-11-15T10:00:00-03:00'   # hoje = 15/11/2026; o mês vai até 30/11
N=[0]
def uid():N[0]+=1;return 'x%d'%N[0]
def it(t,c,day=20,done=None,paid=None,fixed=True,ym='2026-11',d=None):
    o={'id':uid(),'t':t,'d':d or ('Salário' if t=='inc' else 'Conta'),'c':c,'day':day,'fixed':fixed,'cat':'Salário' if t=='inc' else 'Outros','pay':'Pix'}
    if fixed:o['from']=ym
    else:o['ym']=ym
    if done is not None:o['done']={ym:done};o['paidOn']={ym:paid or ('%s-%02d'%(ym,day))}
    return o
def st(items=(),opening=None,debts=(),parc=(),boxes=()):
    return {'v':2,'owner':'T','opening':opening,'limits':{},'ntf':{'read':{}},'pref':{'theme':'dark','pal':'midnight','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':list(items),'inst':[],'parc':list(parc),'debts':list(debts),'boxes':list(boxes)}
def op(c,d='2026-01-01',note=''):return {'c':c,'d':d,'note':note}
LOAD="(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};save();go('home')}"
Q="()=>({b:balance(),p:prevSaldo(),f:flows()})"
with sync_playwright() as p:
    b=p.chromium.launch()
    def page():
        c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo')
        c.add_init_script("window.__WS_NOTOUR=1;window.__WS_OPENDET=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time(NOW);pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(600);return c,pg
    def run(pg,s):
        pg.evaluate(LOAD,json.dumps(s));pg.wait_for_timeout(200);return pg.evaluate(Q)
    c,pg=page()
    # 1
    r=run(pg,st([],op(10000)));ok('1. R$100 e nenhuma despesa: atual 100, previsto 100',r['b']==10000 and r['p']['prev']==10000 and r['p']['aPag']==0,r['p'])
    # 2
    s2=st([it('exp',15000,20)],op(10000));r=run(pg,s2)
    ok('2. R$100 com R$150 pendentes: atual continua 100 (não desconta); previsto −50; a pagar 150',r['b']==10000 and r['p']['prev']==-5000 and r['p']['aPag']==15000,r['p'])
    txt=pg.evaluate("mqSay.toString()&&(()=>{let o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()")
    ok('2/11. Atual positivo e previsto negativo: mensagem de compromissos previstos; NUNCA "Seu saldo ... negativo"',any('Você possui dinheiro disponível, mas seus próximos compromissos podem ultrapassar esse valor.'==t for t in txt) and not any('saldo' in t.lower() and 'negativo' in t.lower() for t in txt),txt[:3])
    h=pg.inner_text('#s-home .hero')
    ok('2. Cartão da Home: "Saldo atual" em destaque, Recebido, Pago, A receber, A pagar e Saldo previsto com a data final',all(x in h for x in ('Saldo atual','Recebido','Pago','A receber','A pagar','Saldo previsto até o fim do mês')) and 'Saldo disponível' not in h,h.replace('\n',' | ')[:200])
    # 3
    r=run(pg,st([it('exp',5000,10,done=5000,paid='2026-11-10')],op(10000)));ok('3. R$100 e pagamento efetivo de R$50: atual 50',r['b']==5000,r['b'])
    # 4
    r=run(pg,st([it('inc',20000,25)],op(10000)));ok('4. Receita prevista ainda não recebida: atual 100 (não soma); a receber 200; previsto 300',r['b']==10000 and r['p']['aRec']==20000 and r['p']['prev']==30000,r['p'])
    # 5 receita atrasada recebida
    s5=st([it('inc',20000,5)],op(10000));r=run(pg,s5)
    late=pg.evaluate("stat(S.items[0],'2026-11')")
    pg.evaluate("ACT.tog(S.items[0].id,{dataset:{m:'2026-11'}})");pg.wait_for_timeout(200);r2=pg.evaluate(Q)
    ok('5. Receita atrasada: não soma enquanto atrasada; ao receber soma uma única vez, com a data do recebimento',late=='late' and r['b']==10000 and r2['b']==30000 and pg.evaluate("S.items[0].paidOn['2026-11']")=='2026-11-15',(late,r['b'],r2['b']))
    # 6 dívida parcelada
    d1={'id':uid(),'n':'Empréstimo','o':30000,'pays':[]}
    r=run(pg,st([],op(50000),debts=[d1]));
    pg.evaluate("S.debts[0].pays.push({d:'2026-11-10',c:10000});save();render()");r2=pg.evaluate(Q)
    ok('6. Pagar uma parcela da dívida reduz o saldo uma vez só (500 → 400) e o restante da dívida cai para 200',r['b']==50000 and r2['b']==40000 and pg.evaluate("balOf(S.debts[0])")==20000,(r['b'],r2['b']))
    # 7 antecipar parcela
    q={'id':uid(),'iid':'i1','ym':'2026-12','c':5000,'due':'2026-12-10','paid':False}
    s7=st([],op(20000),parc=[q]);s7['inst']=[{'id':'i1','n':'Celular','c':5000,'np':2,'day':10,'paid':False}]
    r=run(pg,s7);pg.evaluate("S.parc[0].paid=true;S.parc[0].paidOn='2026-11-12';save();render()");r2=pg.evaluate(Q)
    ok('7. Parcela de dezembro paga antecipadamente em novembro: sai do caixa em novembro, uma vez; não está no previsto de novembro antes de pagar',r['p']['aPag']==0 and r['b']==20000 and r2['b']==15000 and r2['p']['aPag']==0,(r['p'],r2['b']))
    # 8 saldo inicial em data passada
    s8=st([it('exp',3000,20,done=3000,paid='2026-09-20',ym='2026-09',fixed=False),it('exp',2000,5,done=2000,paid='2026-10-05',ym='2026-10',fixed=False),it('inc',7000,7,done=7000,paid='2026-10-07',ym='2026-10',fixed=False)],op(50000,'2026-10-01'))
    r=run(pg,s8);pre=pg.evaluate("preOpen()")
    ok('8. Saldo inicial R$500 em 01/10: despesa paga em setembro (antes) NÃO é descontada de novo; as de outubro entram (500 − 20 + 70 = 550)',r['b']==55000 and pre['n']==1 and pre['net']==-3000,(r['b'],pre))
    # 9 corrigir saldo inicial sem criar receita
    pg.evaluate("S.opening.c=60000;save();render()");r2=pg.evaluate(Q);rf=pg.evaluate("[relFlow('2026-10').inc,relFlow('2026-11').inc,Object.values(flows()).reduce((a,x)=>a+x.inc,0)]")
    ok('9. Corrigir o saldo inicial (500 → 600) muda o saldo em R$100 e NÃO cria receita em nenhum mês',r2['b']==65000 and rf[2]==7000 and rf[1]==0,(r2['b'],rf))
    # 10 backup antigo
    old=json.dumps(st([it('inc',10000,5,done=10000,paid='2026-11-05'),it('exp',4000,6,done=4000,paid='2026-11-06')],op(10000)))
    pg.evaluate(LOAD,old);b1=pg.evaluate("balance()")
    for _ in range(3):pg.evaluate("S=migrate(JSON.parse(JSON.stringify(S)));save()")
    b2=pg.evaluate("balance()");o2=pg.evaluate("JSON.stringify(S.opening)")
    ok('10. Backup antigo (sem campos novos) carrega; importar de novo várias vezes não duplica nada (saldo 160 = 100 + 100 − 40) e o saldo inicial fica igual',b1==16000 and b2==16000 and o2==json.dumps(op(10000),separators=(',',':')),(b1,b2,o2))
    ok('10b. A estrutura de dados não mudou (v=2, opening {c,d,note}); nenhuma chave nova foi acrescentada ao estado salvo',pg.evaluate("S.v")==2 and pg.evaluate("Object.keys(S.opening).sort().join()")=='c,d,note' and 'saldoAtual' not in pg.evaluate("Object.keys(S).join()"))
    # 12 saldo atual negativo com receitas futuras
    s12=st([it('exp',8000,10,done=8000,paid='2026-11-10'),it('inc',20000,25)],op(5000));r=run(pg,s12)
    txt=pg.evaluate("(()=>{let o=[];for(let i=0;i<30;i++){MQH.i=i;o.push(mqSay()[1])}return o})()")
    ok('12. Saldo atual NEGATIVO (−30) com receita futura suficiente: continua negativo e alerta de saldo atual negativo; previsto positivo (170)',r['b']==-3000 and r['p']['prev']==17000 and 'Seu saldo registrado está negativo. Confira suas movimentações.' in txt,(r['b'],r['p']['prev']))
    ok('12b. O cartão da Home mostra o saldo atual negativo em vermelho e o previsto separado',pg.evaluate("document.querySelector('#s-home .hero .big').textContent")!='' and r['b']<0)
    # 13 múltiplos recorrentes
    s13=st([it('inc',300000,5,done=300000,paid='2026-11-05'),it('exp',100000,10,done=100000,paid='2026-11-10'),it('exp',50000,20),it('exp',30000,25),it('exp',20000,28),it('inc',10000,27)],op(0 or 1000))
    r=run(pg,s13);ok('13. Vários recorrentes: atual = 10+3000−1000 = 2010; a pagar = 500+300+200; a receber 100; previsto 1010',r['b']==201000 and r['p']['aPag']==100000 and r['p']['aRec']==10000 and r['p']['prev']==111000,r['p'])
    # 14 meses diferentes
    s14=st([it('inc',200000,5,done=200000,paid='2026-10-05',ym='2026-10',fixed=False),it('exp',50000,10,done=50000,paid='2026-10-10',ym='2026-10',fixed=False),it('inc',200000,5,done=200000,paid='2026-11-05'),it('exp',70000,10,done=70000,paid='2026-11-10')],op(10000,'2026-10-01'))
    r=run(pg,s14);rf=pg.evaluate("[relFlow('2026-10'),relFlow('2026-11')]")
    ok('14. Meses diferentes: saldo atual = 100+2000−500+2000−700 = 2900; início de novembro = 1600 e final = 2900 (sem duplicar)',r['b']==290000 and rf[1]['ini']==160000 and rf[1]['fin']==290000 and rf[0]['fin']==160000,(r['b'],rf[1]['ini'],rf[1]['fin']))
    # 15 atrasadas
    s15=st([it('exp',30000,5),it('exp',10000,8),it('inc',50000,25)],op(100000));r=run(pg,s15);sl=pg.evaluate("finSit()")
    ok('15. Contas atrasadas não pagas: saldo atual intacto (1000); entram no "a pagar" e no previsto (1100 = 1000 + 500 − 400) e são sinalizadas como atraso',r['b']==100000 and r['p']['aPag']==40000 and r['p']['prev']==110000 and any(f['code'].startswith('atraso') for f in sl['flags']),(r['p'],[f['code'] for f in sl['flags']]))
    # 16 sem saldo inicial
    r=run(pg,st([it('inc',50000,5,done=50000,paid='2026-11-05'),it('exp',20000,6,done=20000,paid='2026-11-06')],None))
    ok('16. Sem saldo inicial informado: saldo atual = movimentações realizadas (300) e nada quebra',r['b']==30000 and pg.evaluate("document.querySelector('#s-home .hero .big').textContent").startswith('R$'),r['b'])
    # 17 caixinhas
    bx={'id':uid(),'n':'Viagem','g':100000,'ic':'viagem','moves':[]}
    r=run(pg,st([],op(100000),boxes=[bx]))
    pg.evaluate("S.boxes[0].moves.push({d:'2026-11-10',c:30000});save();render()");r1=pg.evaluate(Q)
    pg.evaluate("S.boxes[0].moves.push({d:'2026-11-12',c:-30000});save();render()");r2=pg.evaluate(Q)
    ok('17. Caixinha: guardar R$300 tira do saldo atual (700) e devolver traz de volta (1000); transferência interna não cria nem destrói dinheiro',r['b']==100000 and r1['b']==70000 and r2['b']==100000 and pg.evaluate("savedOf(S.boxes[0])")==0,(r1['b'],r2['b']))
    # 18 própria data de abertura
    s18=st([it('exp',1000,15,done=1000,paid='2026-11-15'),it('exp',2000,14,done=2000,paid='2026-11-14'),it('inc',500,15,done=500,paid='2026-11-15')],op(10000,'2026-11-15'))
    r=run(pg,s18);pre=pg.evaluate("preOpen()")
    ok('18. Pagamentos na própria data de abertura (15/11) contam uma vez; o de 14/11 já está dentro do saldo inicial: 100 − 10 + 5 = 95',r['b']==9500 and pre['n']==1,(r['b'],pre))
    # classificação
    s=st([it('inc',300000,25),it('exp',150000,28)],op(10000));r=run(pg,s);sl=pg.evaluate("finSit()")
    ok('19. Contas futuras maiores que o dinheiro atual NÃO deixam o usuário Crítico por si só',sl['level']!='crt' and r['b']>0,(sl['level'],[f['code'] for f in sl['flags']]))
    s=st([it('inc',100000,25),it('exp',95000,28)],op(1000000));r=run(pg,s);sl=pg.evaluate("finSit()")
    ok('20. Saldo atual positivo não torna Saudável sozinho: compromissos a 95% da receita mantêm Atenção',sl['level'] in('atn','est') and sl['level']!='ok',sl['level'])
    s=st([it('inc',100000,5,done=100000,paid='2026-11-05'),it('exp',20000,10,done=20000,paid='2026-11-10')],op(100000));pg.evaluate(LOAD,json.dumps(s));pg.evaluate("VIEWS.rel[2]=()=>'<h2>Relatórios</h2>'+['sit','mes','comp','cat','rec','hm','div','cmp','ano','shr'].map(rptBody).join('');go('rel')");pg.wait_for_timeout(300)
    rt=pg.inner_text('#s-rel .sitw')
    ok('21. "Minha situação financeira": mostra Saldo atual e Saldo previsto (e não "Saldo disponível")',('Saldo atual' in rt and 'Saldo previsto' in rt and 'Saldo disponível' not in rt),rt.replace('\n',' | ')[:250])
    # UI: Receitas sem cartão, Ajustes com Contas e saldos
    pg.evaluate(LOAD,json.dumps(st([it('inc',50000,5)],op(10000,'2026-10-01',note='Dinheiro em casa'))));pg.evaluate("go('rec')");pg.wait_for_timeout(300)
    ok('22. Aba Receitas não tem mais o cartão "Saldo inicial"; o saldo inicial não aparece nas receitas do mês',pg.locator('#s-rec .opc').count()==0 and 'Saldo inicial' not in pg.inner_text('#s-rec') and pg.evaluate("vMonth.toString().includes('data-act=\"sini\"')")==False)
    pg.evaluate("go('cfg',{cat:'contas'})");pg.wait_for_timeout(300)
    t=pg.inner_text('#cs-sal') if pg.locator('#cs-sal').count() else ''
    ok('23. Ajustes tem "Contas e saldos" com saldo inicial, data de referência, movimentações desde a referência, saldo atual e previsto',all(x in t for x in ('Contas e saldos','Saldo inicial','R$ 100,00','01/10/2026','Dinheiro em casa','Saldo atual','Saldo previsto','Editar saldo inicial')),t.replace('\n',' | ')[:260])
    pg.click('#cs-sal [data-act=sini]');pg.wait_for_timeout(300)
    pg.fill('#f input[inputmode=decimal],#f input[type=text]','250,00') if pg.locator('#f input[inputmode=decimal]').count() else None
    ok('24. "Editar saldo inicial" abre o formulário com valor, data de referência e observação',pg.locator('#f').count()==1 and pg.locator('#f input[type=date],#f [data-k=d],#f input').count()>=2)
    pg.keyboard.press('Escape');pg.evaluate("closeOv&&closeOv()")
    # texto de reconciliação
    pg.evaluate(LOAD,json.dumps(s8));pg.evaluate("go('cfg',{cat:'contas'})");pg.wait_for_timeout(300)
    ok('25. Reconciliação visível: avisa que 1 movimentação anterior à data de referência não entra no saldo (e continua guardada)',pg.locator('#salpre').count()==1 and 'Reconciliação' in pg.inner_text('#salpre') and 'continuam guardados' in pg.inner_text('#salpre'))
    # persistência após recarregar
    pg.evaluate(LOAD,json.dumps(s2));before=pg.evaluate(Q);pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
    after=pg.evaluate(Q);ok('26. Persistência: depois de recarregar a página saldo atual e previsto são idênticos',before['b']==after['b'] and before['p']['prev']==after['p']['prev'] and after['b']==10000,(before['b'],after['b']))
    ok('27. Sem erros de JavaScript',not pg.errs,pg.errs[:3]);c.close()
    # offline
    c,pg=page();pg.evaluate(LOAD,json.dumps(s2));pg.wait_for_timeout(1500);c.set_offline(True)
    try:
        pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=10000);pg.wait_for_timeout(500);o=pg.evaluate("[balance(),prevSaldo().prev]")
    except Exception as e:o=str(e)[:120]
    ok('28. Offline: abre sem rede e mostra os mesmos saldos (atual 100, previsto −50)',o==[10000,-5000],o);c.close()
    # integridade: nenhuma outra data afetada
    c,pg=page();pg.evaluate(LOAD,json.dumps(s14));pg.evaluate("VIEWS.rel[2]=()=>'<h2>Relatórios</h2>'+['sit','mes','comp','cat','rec','hm','div','cmp','ano','shr'].map(rptBody).join('');go('rel')");pg.wait_for_timeout(300)
    ok('29. Relatórios continuam coerentes com o saldo da Home (saldo final do mês = saldo atual)',pg.evaluate("relFlow('2026-11').fin")==pg.evaluate("balance()"))
    ok('30. Sem erros',not pg.errs,pg.errs[:3]);c.close()
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
