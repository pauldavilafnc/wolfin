"""v7.30: redesign visual de "Minha situação financeira" (Relatórios) com os 4 mascotes de nível. Só dados fictícios.
Confere: 4 níveis com dados reais, mascote certo, transparência, estado sem dados, mudança dinâmica, cálculos intactos,
cores semânticas em todos os temas, resoluções mobile (sem rolagem horizontal/sobreposição/corte), animações e escopo."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html');sw=rd('sw.js')
NOW='2026-11-15T10:00:00-03:00'
def inc(c,i='i1'):return {'id':i,'t':'inc','d':'Salário','c':c,'day':5,'fixed':True,'from':'2026-01','done':{'2026-11':c},'cat':'Salário','pay':'Pix'}
def exp(c,i='e1'):return {'id':i,'t':'exp','d':'Contas','c':c,'day':10,'fixed':True,'from':'2026-01','done':{'2026-11':c},'cat':'Outros','pay':'Pix'}
def st(items,opening=0,debts=None):
    return {'v':2,'owner':'T','opening':{'c':opening,'d':'2026-01-01'} if opening else None,'limits':{},'ntf':{'read':{}},'pref':{'theme':'dark','pal':'midnight','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':items,'inst':[],'parc':[],'debts':debts or [],'boxes':[]}
CASES={ # nível esperado -> estado fictício que realmente produz o nível pelas regras já existentes
 'ok':st([inc(500000),exp(100000)],300000),
 'est':st([inc(500000),exp(325000)],1000000),
 'atn':st([inc(500000),exp(425000)],2000000),
 'crt':st([inc(500000),exp(650000)],100000),
 'none':{'v':2,'owner':'T','opening':None,'limits':{},'ntf':{'read':{}},'pref':{'theme':'dark','pal':'midnight','av':{'v':2,'m':0,'an':1,'set':0},'ms':'terno','ma':0,'mt':0},'items':[],'inst':[],'parc':[],'debts':[],'boxes':[]},
 'none2':st([dict(exp(100000),done={})],0)}
NIVD={'crt':'rgb(252, 165, 165)','atn':'rgb(245, 158, 11)','est':'rgb(96, 165, 250)','ok':'rgb(34, 197, 94)'}
NIVL={'crt':'rgb(185, 28, 28)','atn':'rgb(146, 64, 14)','est':'rgb(29, 78, 216)','ok':'rgb(22, 101, 52)'}
NIVC={'crt':'rgb(239, 68, 68)','atn':'rgb(245, 158, 11)','est':'rgb(59, 130, 246)','ok':'rgb(34, 197, 94)'}
LOAD="(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};nivLoad();VIEWS.rel[2]=()=>'<h2>Relatórios</h2>'+['sit0','mes','comp','cat','rec','hm','div','cmp','ano','shr'].map(x=>x==='sit0'?sitCard()+sitCard(true):rptBody(x)).join('');go('rel')}"
SIT="()=>{const r=finSit();return JSON.stringify({l:r.level,m:r.m,f:r.flags,w:r.why,g:r.good,r:r.recs})}"
with sync_playwright() as p:
    b=p.chromium.launch()
    def page(w=393,h=851,motion=None):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,timezone_id='America/Sao_Paulo',reduced_motion=motion or 'no-preference')
        c.add_init_script("window.__WS_NOTOUR=1;window.__WS_OPENDET=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' else None)
        pg.clock.set_fixed_time(NOW);pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(700);return c,pg
    def show(pg,k):
        pg.evaluate(LOAD,json.dumps(CASES[k]));pg.wait_for_selector('.sitw');pg.wait_for_timeout(250)
    def imgok(pg):
        pg.wait_for_function("(()=>{const i=document.querySelector('.nvw img');return i&&i.complete&&i.naturalWidth>0})()",timeout=8000)
    c,pg=page()
    # ---- 1/2 quatro níveis com dados reais + mascote certo ----
    srcs={};sizes={}
    for k in ('crt','atn','est','ok'):
        show(pg,k);imgok(pg)
        lv=pg.evaluate("finSit().level")
        info=pg.evaluate("""async()=>{const i=document.querySelector('.nvw img'),n=WOLFIMG.niv[finSit().level];const r=await fetch(i.src),a=new Uint8Array(await r.arrayBuffer());const b=atob(n.s.split(',')[1]);let same=a.length===b.length;for(let j=0;same&&j<b.length;j+=7)if(a[j]!==b.charCodeAt(j))same=false;
          return {same,w:i.naturalWidth,h:i.naturalHeight,cls:document.querySelector('.sitw').className,name:document.querySelector('.fsn').textContent,on:document.querySelectorAll('.meter i.on').length,onc:getComputedStyle(document.querySelector('.fsn')).color,mc:document.querySelectorAll('.meter i').length}}""")
        ok(f'1. Dados fictícios reais geram o nível "{k}" pelas regras existentes',lv==k,lv)
        ok(f'2. Nível {k}: mascote correto ({info["w"]}x{info["h"]}), nome "{info["name"]}", 4 marcadores com 1 destacado, cor semântica fixa',info['same'] and info['on']==1 and info['mc']==4 and info['onc']==NIVD[k] and 'lv-'+k in info['cls'],info)
        srcs[k]=pg.evaluate("document.querySelector('.nvw img').src");sizes[k]=(info['w'],info['h'])
    ok('2. Os 4 mascotes são imagens diferentes entre si',len(set(srcs.values()))==4)
    # ---- 3 transparência ----
    tr=pg.evaluate("""async()=>{const out={};for(const k of ['crt','atn','est','ok']){const n=WOLFIMG.niv[k];const im=new Image();im.src=n.s;await im.decode();const c=document.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;const x=c.getContext('2d');x.drawImage(im,0,0);const W=c.width,H=c.height,g=(a,b)=>x.getImageData(a,b,1,1).data[3];
      let tp=0,tot=0;const d=x.getImageData(0,0,W,H).data;for(let i=3;i<d.length;i+=4){tot++;if(d[i]<8)tp++}
      out[k]={corners:[g(0,0),g(W-1,0),g(0,H-1),g(W-1,H-1)],transp:tp/tot,type:n.s.slice(0,22)}}return out}""")
    ok('3. Imagens dos 4 níveis têm fundo transparente (cantos com alfa 0 e boa parte dos pixels transparentes) e sem moldura',all(v['corners'][0]==0 and v['corners'][1]==0 and v['transp']>.15 for v in tr.values()),tr)
    ok('3. Sem círculo/moldura/fundo atrás do mascote (CSS .nvw sem background/border/radius circular)',not re.search(r'\.nvw\{[^}]*(background|border:|border-radius)',html))
    # ---- 4 estado sem dados ----
    for k in ('none','none2'):
        show(pg,k)
        i=pg.evaluate("({nv:document.querySelectorAll('.nvw').length,me:document.querySelectorAll('.meter').length,lv:finSit().level,t:document.querySelector('.sith').innerText,cls:document.querySelector('.sitw').className})")
        ok(f'4. Estado "{k}" (dados insuficientes): sem mascote, sem escala de nível e mensagem informativa, sem classificar',i['nv']==0 and i['me']==0 and i['lv']=='none' and ('Sem avaliação' in i['t'] or 'Cadastre' in i['t'] or 'avali' in i['t'].lower()),i)
    # ---- 5 mudança dinâmica ----
    show(pg,'crt');a=pg.evaluate("document.querySelector('.nvw img').src")
    pg.evaluate(LOAD,json.dumps(CASES['ok']));pg.wait_for_timeout(120)
    d=pg.evaluate("({chg:document.querySelector('.sitw').classList.contains('chg'),cls:document.querySelector('.sitw').className,n:document.querySelector('.fsn').textContent,why:[...document.querySelectorAll('.sitb li')].map(x=>x.textContent).join('|')})")
    imgok(pg);b2=pg.evaluate("document.querySelector('.nvw img').src");pg.wait_for_timeout(700)
    ok('5. Crítica → Saudável: nível, cor, mascote, motivos e recomendações trocam, com transição (classe chg) e sem recarregar a página',d['chg'] and 'lv-ok' in d['cls'] and d['n']=='Saudável' and a!=b2,d)
    pg.evaluate(LOAD,json.dumps(CASES['est']));pg.wait_for_timeout(900)
    ok('5. Nível seguinte (Estável) também troca o mascote e a cor',pg.evaluate("document.querySelector('.fsn').textContent")=='Estável' and pg.evaluate("getComputedStyle(document.querySelector('.fsn')).color")==NIVD['est'])
    # ---- 6 cálculos intactos ----
    for k in ('ok','est','atn','crt'):
        pg.evaluate(LOAD,json.dumps(CASES[k]));x=pg.evaluate(SIT);pg.evaluate("sitCard();render()");y=pg.evaluate(SIT)
        m=json.loads(x)['m']
        txt=pg.evaluate("[...document.querySelectorAll('.fk')].map(e=>e.innerText.replace(/\\s+/g,' ')).join('|')")
        brl=lambda v:'R$ '+format(abs(v)/100,',.2f').replace(',','X').replace('.',',').replace('X','.')
        exp_=['Saldo atual','Saldo previsto','Receitas do mês','Despesas do mês']
        ok(f'6. Nível {k}: finSit idêntico antes/depois de desenhar o cartão e os cartões de resumo mostram os valores calculados (saldo {brl(m["bal"])})',x==y and all(t in txt for t in exp_) and brl(m['bal']).replace('R$ ','') in txt.replace('−','').replace('-',''),txt[:200])
    ok('6. Lógica não foi tocada: finSit() contém os mesmos critérios (comp100, comp80, atraso50, reserva05) e níveis crt/atn/est/ok',all(s in html for s in ("'comp100'","'comp80'","'atraso50'","'reserva05'","?'crt':","?'atn':","?'est':'ok'")))
    ok('6. Seções POR QUE / O QUE ESTÁ BEM / O QUE FAZER AGORA e "Como a avaliação é feita" preservadas',all(s in html for s in ("sec('Por que'","sec('O que está bem'","sec('O que fazer agora'",'Como a avaliação é feita')))
    ok('6. Sem erros de JavaScript/console até aqui',not pg.errs,pg.errs[:3]);c.close()
    # ---- 7 temas ----
    c,pg=page();bad=[];n=0
    PALS=['midnight','blue','violet','teal','pink','orange','ouro','esmeralda','grafite']
    for lvk in ('crt','ok'):
        show(pg,lvk)
        for th in ('dark','light'):
            for pal in PALS:
                pg.evaluate(f"document.documentElement.dataset.theme='{th}';document.documentElement.dataset.pal='{pal}'");pg.wait_for_timeout(40)
                r=pg.evaluate("""()=>{const q=s=>getComputedStyle(document.querySelector(s));const h=document.querySelector('.sith');return {c:q('.fsn').color,dot:q('.fsd').backgroundColor,card:q('.sith').backgroundColor,txt:q('.fst').color,ov:document.documentElement.scrollWidth>innerWidth}}""")
                n+=1
                if r['c']!=(NIVD if th=='dark' else NIVL)[lvk] or r['dot']!=NIVC[lvk] or r['ov'] or r['card']==r['c']:bad.append((lvk,th,pal,r))
    ok(f'7. {n} combinações (2 níveis × claro/escuro × 9 paletas): cor do nível fixa (vermelho/verde; tom mais escuro no tema claro para ter contraste), cartão segue o tema e sem rolagem horizontal',not bad,bad[:2])
    pg.evaluate("document.documentElement.dataset.theme='dark';document.documentElement.dataset.pal='midnight'");pg.wait_for_timeout(80)
    ok('7. Midnight Violet + escuro: cartão translúcido (Liquid Glass) com desfoque de fundo',pg.evaluate("(()=>{const s=getComputedStyle(document.querySelector('.sith'));const a=(s.backgroundColor.match(/[\\d.]+/g)||[]);return (a.length==4&&+a[3]<1)&&(/blur/.test(s.backdropFilter||s.webkitBackdropFilter||''))})()"))
    ok('7. Sem erros de JavaScript',not pg.errs,pg.errs[:3]);c.close()
    # ---- 8 resoluções, sobreposição, cortes ----
    GEO="""()=>{const r=e=>e.getBoundingClientRect(),card=document.querySelector('.sith'),t=document.querySelector('.sitt'),v=document.querySelector('.nvw'),im=v&&v.querySelector('img'),cr=r(card),tr=r(t),out={ov:document.documentElement.scrollWidth>innerWidth,cw:cr.width,cardH:cr.height};
      if(v){const vr=r(v);out.sep=vr.left-tr.right;out.inR=vr.right<=cr.right+1;out.bot=Math.abs(vr.bottom-cr.bottom);out.top=cr.top-vr.top;out.head=r(im).top-cr.top;out.vw=vr.width}
      out.txtClip=[...document.querySelectorAll('.sitw .fk b,.sitw .fsn,.sitw .fst,.sitw h3')].filter(e=>e.scrollWidth>e.clientWidth+1||r(e).right>innerWidth+1||r(e).left<-1).map(e=>e.className||e.tagName);
      out.cardsOut=[...document.querySelectorAll('.sitw .card,.sitw .fk')].filter(e=>r(e).right>innerWidth+.5||r(e).left<-.5).length;return out}"""
    for w,h in ((320,640),(360,740),(375,667),(390,844),(412,915),(768,1024)):
        c,pg=page(w,h)
        for k in ('crt','atn','est','ok'):
            show(pg,k);imgok(pg);g=pg.evaluate(GEO)
            good=(not g['ov']) and g['sep']>=-1 and g['inR'] and g['bot']<=2 and g['top']<=40 and not g['txtClip'] and g['cardsOut']==0 and g['cardH']<=360
            ok(f'8. {w}px, nível {k}: sem rolagem horizontal, texto não toca o mascote (folga {g.get("sep",0):.0f}px), mascote alinhado ao rodapé do cartão, cabeça acima ≤ 40px, sem textos cortados, altura {g["cardH"]:.0f}px',good,g)
        show(pg,'ok');pg.evaluate("window.scrollTo(0,document.body.scrollHeight)");pg.wait_for_timeout(300)
        nv=pg.evaluate("(()=>{const n=document.querySelector('nav,.nav,#nav,.bar');return n?n.getBoundingClientRect().top:null})()")
        ok(f'8. {w}px: com o fim da página, conteúdo não fica escondido atrás da navegação',pg.evaluate("(()=>{const l=[...document.querySelectorAll('#s-rel .card,.card')].pop(),n=document.querySelector('.nav,nav,#nav');if(!l||!n)return true;return l.getBoundingClientRect().bottom<=n.getBoundingClientRect().top+2})()"),nv)
        ok(f'8. {w}px: sem erros',not pg.errs,pg.errs[:2]);c.close()
    # ---- 9 animações ----
    c,pg=page();show(pg,'est');imgok(pg)
    an=pg.evaluate("({img:getComputedStyle(document.querySelector('.nvw img')).animationName,dur:getComputedStyle(document.querySelector('.nvw img')).animationDuration,wrap:getComputedStyle(document.querySelector('.nvw')).animationName,gpu:getComputedStyle(document.querySelector('.nvw img')).willChange})")
    kf=re.findall(r'@keyframes (nvbr|nvin|nvchg)\{([^}]*\{[^}]*\}[^}]*)\}',html)
    ok('9. Mascote com respiração (5,2 s, loop) e entrada suaves; animações só com transform/opacity (leves, sem relayout)',an['img']=='nvbr' and an['wrap'] in('nvin','nvchg') and all(not re.search(r'(width|height|top|left|margin|filter)\s*:',m[1]) for m in kf) and len(kf)>=2,(an,len(kf)))
    pg.evaluate("document.body.style.minHeight='4000px';window.scrollTo(0,0)")
    pg.evaluate("(()=>{const s=document.createElement('div');s.style.height='3000px';document.querySelector('#s-rel,#app,main,body').appendChild(s)})()");pg.evaluate("window.scrollTo(0,2500)");pg.wait_for_timeout(500)
    ok('9. Fora da tela a animação do mascote é pausada (IntersectionObserver → data-off)',pg.evaluate("(()=>{const v=document.querySelector('.nvw');return v.hasAttribute('data-off')&&getComputedStyle(v.querySelector('img')).animationPlayState==='paused'})()"))
    pg.evaluate("window.scrollTo(0,0)");pg.wait_for_timeout(500)
    ok('9. De volta à tela a animação retoma',pg.evaluate("(()=>{const v=document.querySelector('.nvw');return !v.hasAttribute('data-off')&&getComputedStyle(v.querySelector('img')).animationPlayState==='running'})()"))
    # custo: frames durante 2 s
    fr=pg.evaluate("new Promise(r=>{let n=0,t0=performance.now(),long=0,last=t0;function f(t){n++;if(t-last>100)long++;last=t;if(t-t0<2000)requestAnimationFrame(f);else r({fps:n/((t-t0)/1000),long})}requestAnimationFrame(f)})")
    ok('9. Desempenho (Chromium simulado, sem GPU real): ≥ 20 quadros/s e nenhum travamento > 100 ms com a animação rodando',fr['fps']>=20 and fr['long']==0,fr)
    ok('9. Sem erros',not pg.errs,pg.errs[:2]);c.close()
    c,pg=page(motion='reduce');show(pg,'ok');imgok(pg)
    rm=pg.evaluate("({i:getComputedStyle(document.querySelector('.nvw img')).animationName,w:getComputedStyle(document.querySelector('.nvw')).animationName,d:getComputedStyle(document.querySelector('.fsd')).animationName})")
    pg.evaluate(LOAD,json.dumps(CASES['crt']));pg.wait_for_timeout(100)
    rm2=pg.evaluate("({i:getComputedStyle(document.querySelector('.nvw img')).animationName,w:getComputedStyle(document.querySelector('.nvw')).animationName,f:getComputedStyle(document.querySelector('.fsn')).animationName})")
    ok('9. prefers-reduced-motion: mascote parado, sem entrada e sem transição ao mudar de nível',rm['i']=='none' and rm['w']=='none' and rm2['i']=='none' and rm2['w']=='none' and rm2['f']=='none',(rm,rm2));c.close()
    # ---- 10 escopo / arquivos ----
    c,pg=page();pg.evaluate("(x)=>{S=migrate(JSON.parse(x));S.flags={tour:1};go('home')}",json.dumps(CASES['ok']));pg.wait_for_timeout(300)
    ok('10. Home não recebeu o mascote de nível nem o cartão novo',pg.evaluate("document.querySelectorAll('.nvw,.sitw').length")==0)
    ok('10. Loja: continua com 12 visuais e nenhum mascote de nível foi misturado a eles',pg.evaluate("WLOOKS.length")==12 and not any(k in json.dumps(pg.evaluate("WLOOKS.map(x=>x.id)")) for k in ('crt','atn','"est"','"ok"')) and pg.evaluate("Object.keys(WOLFIMG.sty||{}).filter(k=>['crt','atn','est','ok'].includes(k)).length")==0)
    pg.evaluate("VIEWS.rel[2]=()=>'<h2>Relatórios</h2>'+['sit0','mes','comp','cat','rec','hm','div','cmp','ano','shr'].map(x=>x==='sit0'?sitCard()+sitCard(true):rptBody(x)).join('');go('rel')");pg.wait_for_selector('.sitw');imgok(pg)
    ok('10. Arquivo lazy wolfin-niveis.js: 4 imagens WebP (crt, atn, est, ok) com tamanho; leve (< 150 KB); guardado para uso offline',pg.evaluate("Object.keys(WOLFIMG.niv).sort().join()")=='atn,crt,est,ok' and all(v['s'].startswith('data:image/webp') for v in pg.evaluate("Object.values(WOLFIMG.niv)")) and os.path.getsize(os.path.join(ROOT,'wolfin-niveis.js'))<150_000 and 'wolfin-niveis.js' in sw)
    ok('10. Acessível: mascote com rótulo, escala com aria-label, ícone oculto do leitor',pg.evaluate("(()=>{const v=document.querySelector('.nvw');return v.getAttribute('role')==='img'&&/situação/.test(v.getAttribute('aria-label'))&&/Nível atual/.test(document.querySelector('.meter').getAttribute('aria-label'))&&document.querySelector('.fsd').getAttribute('aria-hidden')==='true'})()"))
    ok('10. Sem erros de JavaScript',not pg.errs,pg.errs[:2]);c.close()
    b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
