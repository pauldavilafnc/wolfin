"""v7.24: Wolfin de volta (mascote Brasil, WolfCoins, Loja). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(w=393,h=851,th='dark',code='',rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,reduced_motion='reduce' if rm else 'no-preference');pg=c.new_page()
        pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};"+code+"S.pref.theme='%s';save();applyPref();go('home')"%th);pg.wait_for_timeout(900)
        return c,pg
    c,pg=home()
    ok('1. Imagens do Wolfin carregam (WF.ok) sem erro de script',pg.evaluate("WF.ok")==True and not pg.errs,pg.errs)
    ok('2. Avatar do Wolfin aparece na faixa da Home com imagens reais',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');if(!w)return false;return [...w.querySelectorAll('img')].every(i=>i.complete&&i.naturalWidth>0)})()"))
    ok('3. Faixa da Home mantém o ícone de aviso (estrutura anterior)',pg.locator('#s-home .mqc .mi svg').count()==1)
    ok('4. Mascote não aumenta a altura da faixa além de 64px',pg.evaluate("document.querySelector('#s-home .mqc').getBoundingClientRect().height")<=64,pg.evaluate("document.querySelector('#s-home .mqc').getBoundingClientRect().height"))
    ok('5. Avatar tem nome acessível e imagens decorativas (alt vazio)',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');return w.getAttribute('role')==='img'&&!!w.getAttribute('aria-label')&&[...w.querySelectorAll('img')].every(i=>i.alt==='')})()"))
    # estruturas
    ok('6. Brasil é o visual padrão, liberado e equipado (sem compra)',pg.evaluate("(()=>{const w=wcEnsure();return w.own.includes('brasil')&&w.look==='brasil'})()"))
    ok('7. Todas as 16 expressões de olhos e 11 de boca existem',pg.evaluate("Object.keys(WOLFIMG.brasil.E).length===16&&Object.keys(WOLFIMG.brasil.M).length===11"))
    ok('8. Toda expressão definida aponta para imagens existentes',pg.evaluate("Object.values(WF.ex).every(e=>WOLFIMG.brasil.body[e[0]]&&WOLFIMG.brasil.E[e[1]]&&WOLFIMG.brasil.M[e[2]])"))
    # moedas
    pg.evaluate("S.wc.n=0;S.wc.tot=0;S.wc.done={};S.wc.log=[];S.ach=null;save()")
    g=pg.evaluate("[wcGrant('t1',5,'x'),wcGrant('t1',5,'x'),wcEnsure().n]")
    ok('9. WolfCoins: cada motivo rende uma única vez',g==[5,0,5],g)
    n=pg.evaluate("(()=>{S.wc.n=0;S.wc.done={};wcDaily();wcDaily();return wcEnsure().n})()");ok('10. Moeda da visita do dia: só uma por dia',n==1,n)
    r=pg.evaluate("""(()=>{S.wc.done={};S.wc.n=0;S.ach={};const a=ACH[0];S.ach[a.id]=undefined;delete S.ach[a.id];const before=wcEnsure().n;const g=wcAch([a]);const g2=wcAch([a]);return[before,g,g2,wcEnsure().n]})()""")
    ok('11. Conquista rende 10 moedas uma vez',r==[0,10,0,10],r)
    pg.evaluate("S.wc.n=0;S.wc.done={};S.ach={};S.items.length=0;save()")
    pg.evaluate("go('rec')");pg.evaluate("S.opening.c=1000;S.ach={};commit('x')");pg.wait_for_timeout(400)
    ok('12. Conquista nova via commit dá moedas e toast cita WolfCoins',pg.evaluate("wcEnsure().n")>=10 and 'WolfCoins' in pg.inner_text('#toast'),(pg.evaluate("wcEnsure().n"),pg.inner_text('#toast')))
    # migração
    r=pg.evaluate("(()=>{const o={wc:{n:'abc',own:['x'],look:'zzz',done:5,log:7}};wcEnsure(o);return[o.wc.n,o.wc.own[0],o.wc.look,typeof o.wc.done,Array.isArray(o.wc.log)]})()")
    ok('13. Dados de moedas corrompidos/ausentes são reparados',r==[0,'brasil','brasil','object',True],r)
    ok('14. Backup antigo sem S.wc abre normalmente (migrate cria S.wc)',pg.evaluate("(()=>{const o=JSON.parse(JSON.stringify(S));delete o.wc;const m=migrate(o);return !!m.wc&&m.wc.own.includes('brasil')})()"))
    # telas
    pg.evaluate("go('conq')");pg.wait_for_timeout(500)
    ok('15. Conquistas mostra Wolfin, saldo de WolfCoins e botão da Loja',pg.locator('#s-conq .wcard .wolf').count()==1 and pg.locator('#s-conq .wcn').count()==1 and pg.locator('#s-conq [data-act=nav][data-id=loja]').count()==1)
    pg.click('#s-conq [data-id=loja]');pg.wait_for_timeout(500)
    t=pg.inner_text('#s-loja')
    ok('16. Loja abre; Brasil "Em uso"; outros visuais "Em breve" (sem compra)',pg.evaluate("view")=='loja' and 'Em uso' in t and t.count('Em breve')==3,t[:200])
    ok('17. Loja: botão Voltar leva para Ajustes',(pg.click('#s-loja .ib'),pg.wait_for_timeout(300),pg.evaluate("view"))[2]=='cfg')
    ok('18. Ajustes tem cartão do Wolfin com chave e jeito de falar',pg.locator('#s-cfg [data-act=wfon]').count()==1 and pg.locator('#s-cfg [data-act=wftone]').count()==2)
    pg.click('#s-cfg [data-act=wfon]');pg.wait_for_timeout(300)
    ok('19. Desligar o Wolfin esconde o mascote da Home e guarda a escolha',(pg.evaluate("go('home')"),pg.wait_for_timeout(300),pg.locator('#s-home .mqc .wolf').count())[2]==0 and pg.evaluate("S.pref.wf.on")==0)
    ok('20. Com Wolfin desligado a faixa volta ao ícone de antes',pg.locator('#s-home .mqc .mi svg').count()==1)
    pg.evaluate("S.pref.wf.on=1;save();go('cfg')");pg.click('#s-cfg [data-act=wftone][data-id=s]');pg.wait_for_timeout(200)
    ok('21. Tom "Sereno" fica salvo',pg.evaluate("S.pref.wf.tone")=='s' and pg.evaluate("wfVoice('conq')")!='' )
    pg.evaluate("S.pref.wf.tone='m';S.opening.c=-900000;save()")
    ok('22. Com saldo negativo o Wolfin sempre fala no tom acolhedor',all(pg.evaluate("wfVoice('welcome')") in pg.evaluate("WV.s.welcome") for _ in range(8)))
    ok('23. Frases têm conteúdo para todos os usos',pg.evaluate("['welcome','tour','conq','coin','loja','daily'].every(k=>WV.m[k].length&&WV.s[k].length)"))
    # negativo na home
    pg.evaluate("MQH.cheer=0;go('home')");pg.wait_for_timeout(500)
    ok('24. Saldo negativo: faixa mantém o texto e o Wolfin fica acolhedor',pg.inner_text('#s-home .mqc').startswith('Seu saldo está negativo')and pg.evaluate("document.querySelector('#s-home .mqc .wolf').dataset.wx")=='acolhe',pg.inner_text('#s-home .mqc'))
    # notificações
    pg.evaluate("go('ntf')");pg.wait_for_timeout(400)
    ok('25. Avisos: Wolfin aparece quando há notificações',pg.locator('#s-ntf .wcard .wolf').count()==1)
    ok('26. Seção de Loja existe, aparece como "Loja do Wolfin" para leitor de tela',pg.evaluate("A11Y_VT.loja")=='Loja do Wolfin' and pg.evaluate("!!document.getElementById('s-loja')"))
    c.close()
    # piscar/animação
    c,pg=home()
    r=pg.evaluate("(()=>{const e=document.querySelector('#s-home .mqc .we');return e.getAttribute('src')})()")
    pg.evaluate("for(let i=0;i<40;i++)wolfBlink()");pg.wait_for_timeout(150)
    ok('27. Piscar troca a imagem do olho e volta ao normal',pg.evaluate("document.querySelector('#s-home .mqc .we').src.startsWith('blob:')") and (pg.wait_for_timeout(400),pg.evaluate("document.querySelector('#s-home .mqc .we').getAttribute('src')"))[1]==r)
    pg.evaluate("go('conq')");pg.wait_for_timeout(300)
    an=pg.evaluate("getComputedStyle(document.querySelector('#s-conq .wolf .wt')).animationName");ok('28. Animação leve da cauda ativa (movimento normal)',an!='none',an)
    c.close()
    c,pg=home(rm=True);pg.evaluate("go('conq')");pg.wait_for_timeout(300)
    an=pg.evaluate("[getComputedStyle(document.querySelector('#s-conq .wolf .wt')).animationName,getComputedStyle(document.querySelector('#s-conq .wolf .ws')).animationName]");ok('29. Movimento reduzido: sem animações do mascote',an==['none','none'],an)
    c.close()
    # telas pequenas
    for w,h in((320,640),(360,740),(393,851)):
        c,pg=home(w,h,'light')
        for v in('home','conq','loja','cfg','ntf'):
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
        m=[]
        for v in('home','conq','loja','cfg','ntf'):
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
            if pg.evaluate("document.documentElement.scrollWidth>innerWidth"):m.append(v)
        ok(f'30. {w}x{h}: sem rolagem lateral nas telas com Wolfin',not m,m);c.close()
    # boas-vindas e tutorial (conta nova)
    c=b.new_context(viewport={'width':360,'height':700},is_mobile=True);pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    pg.add_init_script("window.__WS_NOCSP=1")
    pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(300)
    pg.evaluate("viewWelcome()");pg.wait_for_timeout(900)
    ok('31. Boas-vindas mostra o Wolfin com imagens carregadas',pg.evaluate("(()=>{const w=document.querySelector('#lock .wolf');return !!w&&[...w.querySelectorAll('img')].every(i=>i.naturalWidth>0)})()") and not pg.errs,pg.errs)
    ok('32. Boas-vindas: texto original preservado e botão Começar visível',pg.locator('#lock [data-lk=new]').is_visible() and 'Oi, eu sou Wolfin!' in pg.inner_text('#lock'))
    c.close()
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True);pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    pg.add_init_script("window.__WS_NOCSP=1");pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
    pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};save();go('home');tourStart(true)") if pg.evaluate("typeof tourStart")=='function' else None
    pg.wait_for_timeout(1200)
    if pg.locator('#tour .tcard').count():
        ok('33. Tutorial mostra o Wolfin no cartão, com o texto original',pg.locator('#tour .twfw .wolf').count()==1 and pg.inner_text('#tour .tt')=='Seu painel',pg.errs)
    else:
        ok('33. Tutorial: função de início encontrada',False,'sem tour')
    c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
