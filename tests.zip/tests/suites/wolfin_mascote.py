"""v7.24: Wolfin de volta (mascote Brasil, WolfCoins, Loja). Dados fictícios; Chromium simulado (sem celular real nem TalkBack)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
FXJ=open(os.path.join(FIX,'dados_ficticios.js'),encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch()
    def home(w=393,h=851,th='dark',code='',rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,color_scheme=th,reduced_motion='reduce' if rm else 'no-preference');pg=c.new_page()
        pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
        pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};"+code+"S.pref.theme='%s';save();applyPref();go('home')"%th);pg.wait_for_timeout(900)
        return c,pg
    c,pg=home()
    ok('1. Imagens do Wolfin carregam (WF.ok) sem erro de script',pg.evaluate("WF.ok")==True and not pg.errs,pg.errs)
    ok('2. Avatar do Wolfin aparece na faixa da Home com imagens reais',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');if(!w)return false;return [...w.querySelectorAll('img')].every(i=>i.complete&&i.naturalWidth>0)})()"))
    ok('3. Cartão do mascote mantém o ícone de informações',pg.locator('#s-home .mqc .mqi svg').count()==1)
    ok('4. Cartão do mascote na Home: busto sem moldura, altura ≤ 170px',pg.evaluate("document.querySelector('#s-home .mqc').getBoundingClientRect().height")<=170 and pg.evaluate("getComputedStyle(document.querySelector('#s-home .mqc .wolf')).borderTopWidth")=='0px')
    ok('5. Avatar tem nome acessível e imagens decorativas (alt vazio)',pg.evaluate("(()=>{const w=document.querySelector('#s-home .mqc .wolf');return w.getAttribute('role')==='img'&&!!w.getAttribute('aria-label')&&[...w.querySelectorAll('img')].every(i=>i.alt==='')})()"))
    # estruturas
    ok('6. Padrão (novo Wolfin) é o visual inicial, liberado e equipado; Brasil também liberado (sem compra)',pg.evaluate("(()=>{const w=wcEnsure();return w.own.includes('brasil')&&w.own.includes('padrao')&&w.look==='padrao'})()"))
    ok('7. Todas as 16 expressões de olhos e 11 de boca existem',pg.evaluate("Object.keys(WOLFIMG.brasil.E).length===16&&Object.keys(WOLFIMG.brasil.M).length===11"))
    ok('8. Toda expressão definida aponta para imagens existentes',pg.evaluate("Object.values(WF.ex).every(e=>WOLFIMG.brasil.body[e[0]]&&WOLFIMG.brasil.E[e[1]]&&WOLFIMG.brasil.M[e[2]])"))
    # moedas
    pg.evaluate("S.wc.n=0;S.wc.tot=0;S.wc.done={};S.wc.log=[];S.ach=null;save()")
    g=pg.evaluate("[wcGrant('t1',5,'x'),wcGrant('t1',5,'x'),wcEnsure().n]")
    ok('9. WolfCoins: cada motivo rende uma única vez',g==[5,0,5],g)
    n=pg.evaluate("(()=>{S.wc.n=0;S.wc.done={};wcDaily();wcDaily();return wcEnsure().n})()");ok('10. Moeda da visita do dia: só uma por dia',n==1,n)
    r=pg.evaluate("""(()=>{S.wc.done={};S.wc.n=0;S.ach={};const a=ACH[0];S.ach[a.id]=undefined;delete S.ach[a.id];const before=wcEnsure().n;const g=wcAch([a]);const g2=wcAch([a]);return[before,g,g2,wcEnsure().n]})()""")
    ok('11. Conquista rende 10 moedas uma vez',r==[0,10,0,10],r)
    pg.evaluate("S.wc.n=0;S.wc.done={};S.ach={};S.items.length=0;save()")
    pg.evaluate("go('rec')");pg.evaluate("S.opening.c=1000;S.ach={};commit('x')");pg.wait_for_timeout(400)
    ok('12. Conquista nova via commit dá moedas e toast cita WolfCoins',pg.evaluate("wcEnsure().n")>=10 and 'WolfCoins' in pg.inner_text('#toast'),(pg.evaluate("wcEnsure().n"),pg.inner_text('#toast')))
    # migração
    r=pg.evaluate("(()=>{const o={wc:{n:'abc',own:['x'],look:'zzz',done:5,log:7}};wcEnsure(o);return[o.wc.n,o.wc.own[0],o.wc.look,typeof o.wc.done,Array.isArray(o.wc.log)]})()")
    ok('13. Dados de moedas corrompidos/ausentes são reparados',r==[0,'padrao','padrao','object',True],r)
    ok('14. Backup antigo sem S.wc abre normalmente (migrate cria S.wc)',pg.evaluate("(()=>{const o=JSON.parse(JSON.stringify(S));delete o.wc;const m=migrate(o);return !!m.wc&&m.wc.own.includes('brasil')})()"))
    # telas
    pg.evaluate("go('conq')");pg.wait_for_timeout(500)
    ok('15. Conquistas mostra Wolfin, saldo de WolfCoins e botão da Loja',pg.locator('#s-conq .wcard .wolf').count()==1 and pg.locator('#s-conq .wcn').count()==1 and pg.locator('#s-conq [data-act=nav][data-id=loja]').count()==1)
    pg.click('#s-conq [data-id=loja]');pg.wait_for_timeout(500)
    t=pg.inner_text('#s-loja')
    ok('16. Loja abre: 12 personagens (Padrão equipado, os outros equipáveis no modo de testes) e saldo no cabeçalho',pg.evaluate("view")=='loja' and pg.locator('#s-loja .lc').count()==12 and pg.locator('#s-loja .lc.st-eq').count()==1 and pg.locator('#s-loja .lc [data-act=wlook]').count()==11 and pg.locator('#s-loja .sbar .lbal2 .wcn').count()==1,t[:200])
    ok('17. Loja: botão Voltar do cabeçalho leva à tela anterior (Conquistas) e a barra inferior some',(pg.evaluate("getComputedStyle(document.getElementById('nav')).display")=='none',pg.click('#s-loja .sbk'),pg.wait_for_timeout(400),pg.evaluate("view"))[3]=='conq')
    pg.evaluate("go('cfg')");pg.wait_for_timeout(400)
    ok('18. (v7.34) Ajustes tem a seção "Wolfin, o mascote" com a chave, sem "Jeito de falar"',pg.locator('#s-cfg #cs-wolf [data-act=wfon]').count()==1 and pg.locator('#s-cfg [data-act=wftone]').count()==0 and 'Jeito de falar' not in pg.inner_text('#s-cfg') and 'Malandro' not in pg.inner_text('#s-cfg'))
    pg.evaluate("go('loja')");pg.wait_for_timeout(400)
    ok('18b. Loja tem a chave Mostrar o Wolfin (Ligado)',pg.locator('#s-loja [data-act=wfon]').count()==1 and pg.inner_text('#s-loja .lonoff').count('Ligado')==1)
    pg.click('#s-loja [data-act=wfon]');pg.wait_for_timeout(300)
    ok('19. Desligar o Wolfin esconde o mascote da Home e guarda a escolha',(pg.evaluate("go('home')"),pg.wait_for_timeout(300),pg.locator('#s-home .mqc .wolf').count())[2]==0 and pg.evaluate("S.pref.wf.on")==0)
    ok('20b. (v7.34) Com o Wolfin desligado NÃO há ícone/botão da Loja na Home; Ajustes abre a Loja e religa o Wolfin',pg.locator('#s-home .mqshop').count()==0 and pg.locator('#s-home [data-act=nav][data-id=loja]').count()==0 and (pg.evaluate("go('cfg')"),pg.wait_for_timeout(300),pg.click('#cs-wolf [data-act=nav][data-id=loja]'),pg.wait_for_timeout(400),pg.evaluate("view"))[4]=='loja' and (pg.click('#s-loja [data-act=wfon]'),pg.wait_for_timeout(300),pg.evaluate("S.pref.wf.on"))[2]==1 and (pg.evaluate("go('home')"),pg.wait_for_timeout(300),pg.locator('#s-home .mqb[data-id=loja]').count())[2]==1)
    pg.evaluate("S.pref.wf.on=0;save();go('home')");pg.wait_for_timeout(300)
    ok('20. Com Wolfin desligado a faixa volta ao ícone de antes',pg.locator('#s-home .mqc .mi svg').count()==1)
    pg.evaluate("S.pref.wf.on=0;go('loja')");pg.wait_for_timeout(300);pg.click('#s-loja [data-act=wfon]');pg.wait_for_timeout(300)
    ok('21. Religar pela Loja volta a mostrar o Wolfin; o tom é fixo (sem opção) e a fala funciona',pg.evaluate("S.pref.wf.on")==1 and pg.evaluate("wfTone()")=='m' and pg.evaluate("wfVoice('conq')")!='' )
    pg.evaluate("S.pref.wf.tone='m';S.opening.c=-900000;save()")
    ok('22. Com saldo negativo o Wolfin sempre fala no tom acolhedor',all(pg.evaluate("wfVoice('welcome')") in pg.evaluate("WV.s.welcome") for _ in range(8)))
    ok('23. Frases têm conteúdo para todos os usos',pg.evaluate("['welcome','tour','conq','coin','loja','daily'].every(k=>WV.m[k].length&&WV.s[k].length)"))
    # negativo na home
    pg.evaluate("MQH.cheer=0;go('home')");pg.wait_for_timeout(500)
    ok('24. Saldo negativo: cartão mantém o texto de aviso e o mascote continua visível',pg.inner_text('#s-home .mqc').startswith('Seu saldo registrado está negativo')and pg.locator('#s-home .mqc .wolf').count()==1,pg.inner_text('#s-home .mqc'))
    # notificações
    pg.evaluate("go('ntf')");pg.wait_for_timeout(400)
    ok('25. Avisos: Wolfin aparece quando há notificações',pg.locator('#s-ntf .wcard .wolf').count()==1)
    ok('26. Seção de Loja existe, aparece como "Loja do Wolfin" para leitor de tela',pg.evaluate("A11Y_VT.loja")=='Loja do Wolfin' and pg.evaluate("!!document.getElementById('s-loja')"))
    c.close()
    # piscar/animação
    c,pg=home();pg.evaluate("ACT.wlook('brasil')");pg.evaluate("go('conq')");pg.wait_for_timeout(600)   # só o Brasil tem camadas (piscar, orelha, cauda); o Padrão é uma imagem só
    r=pg.evaluate("(()=>{const e=document.querySelector('#s-conq .wolf .we');return e.getAttribute('src')})()")
    pg.evaluate("for(let i=0;i<40;i++)wolfBlink()");pg.wait_for_timeout(150)
    ok('27. (Conquistas, mascote em camadas) Piscar troca a imagem do olho e volta ao normal',pg.evaluate("document.querySelector('#s-conq .wolf .we').src.startsWith('blob:')") and (pg.wait_for_timeout(400),pg.evaluate("document.querySelector('#s-conq .wolf .we').getAttribute('src')"))[1]==r)
    pg.evaluate("ACT.wlook('brasil');go('conq')");pg.wait_for_timeout(300)
    an=pg.evaluate("getComputedStyle(document.querySelector('#s-conq .wolf .wt')).animationName");ok('28. Animação leve da cauda ativa (movimento normal)',an!='none',an)
    c.close()
    c,pg=home(rm=True);pg.evaluate("ACT.wlook('brasil');go('conq')");pg.wait_for_timeout(300)
    an=pg.evaluate("[getComputedStyle(document.querySelector('#s-conq .wolf .wt')).animationName,getComputedStyle(document.querySelector('#s-conq .wolf .ws')).animationName]");ok('29. Movimento reduzido: sem animações do mascote',an==['none','none'],an)
    c.close()
    # telas pequenas
    for w,h in((320,640),(360,740),(393,851)):
        c,pg=home(w,h,'light')
        for v in('home','conq','loja','cfg','ntf'):
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
        m=[]
        for v in('home','conq','loja','cfg','ntf'):
            pg.evaluate(f"go('{v}')");pg.wait_for_timeout(250)
            if pg.evaluate("document.documentElement.scrollWidth>innerWidth"):m.append(v)
        ok(f'30. {w}x{h}: sem rolagem lateral nas telas com Wolfin',not m,m);c.close()
    # boas-vindas e tutorial (conta nova)
    c=b.new_context(viewport={'width':360,'height':700},is_mobile=True);pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    pg.add_init_script("window.__WS_NOCSP=1")
    pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(300)
    pg.evaluate("viewWelcome()");pg.wait_for_timeout(900)
    ok('31. Boas-vindas mostra o Wolfin com imagens carregadas',pg.evaluate("(()=>{const w=document.querySelector('#lock .wolf');return !!w&&[...w.querySelectorAll('img')].every(i=>i.naturalWidth>0)})()") and not pg.errs,pg.errs)
    ok('32. Boas-vindas: texto original preservado e botão Começar visível',pg.locator('#lock [data-lk=new]').is_visible() and 'Oi, eu sou Wolfin!' in pg.inner_text('#lock'))
    c.close()
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True);pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
    pg.add_init_script("window.__WS_NOCSP=1");pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');OB_NOSEC(pg,'Paul');pg.wait_for_function("document.getElementById('lock').hidden")
    pg.evaluate("S="+FXJ+";S.org=S.org||{notes:[],rems:[],lists:[]};save();go('home');tourStart(true)") if pg.evaluate("typeof tourStart")=='function' else None
    pg.wait_for_timeout(1200)
    if pg.locator('#tour .tcard').count():
        ok('33. Tutorial mostra o Wolfin no cartão, com o texto original',pg.locator('#tour .twfw .wolf').count()==1 and pg.inner_text('#tour .tt')=='Seu painel',pg.errs)
    else:
        ok('33. Tutorial: função de início encontrada',False,'sem tour')
    c.close()
    # ===== v7.25: entrada reordenada, olhos que fecham, olho único, animações =====
    def novo(w=393,h=851,rm=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,reduced_motion='reduce' if rm else 'no-preference');pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.add_init_script("window.__WS_NOCSP=1");pg.goto(URL);pg.wait_for_selector('[data-lk=new]');return c,pg
    c,pg=novo();pg.wait_for_timeout(500)
    ok('34. Ordem: tela inicial → aparência → nome → senha, com contador 1/3, 2/3 e 3/3',
       (pg.locator('.obdots').count()==0,pg.click('[data-lk=new]'),pg.wait_for_selector('#cf'),pg.locator('.obdots[aria-label="Etapa 1 de 3"]').count())[3]==1 and
       (pg.click('#cf button:not([type=button])'),pg.wait_for_selector('#nf'),pg.locator('.obdots[aria-label="Etapa 2 de 3"]').count())[2]==1 and
       (pg.fill('#nf [name=n]','Bia'),pg.click('#nf .b1'),pg.wait_for_selector('#sf'),pg.locator('.obdots[aria-label="Etapa 3 de 3"]').count())[3]==1)
    ok('35. Criar acesso: sem mascote (ícone de vidro no lugar) e um só olho',pg.locator('#lock .wolf').count()==0 and pg.locator('#lock .obic').count()==1 and pg.locator('#sf .eyl').count()==1)
    pg.evaluate("viewLogin()");pg.wait_for_selector('#lf')
    ok('35b. Tela de Entrar mantém o Wolfin de corpo inteiro',pg.locator('#lock .wolf.sty.lkw').count()==1 and pg.locator('#lf .eyl').count()==1)
    pg.click('#lf [name=p]');pg.wait_for_timeout(300)
    ok('36. Sem versão "vendado": focar a senha não troca a imagem do Wolfin (só a imagem normal existe)',pg.evaluate("(()=>{const w=document.querySelector('#lock .wolf');return !w.querySelector('.sv')&&w.querySelectorAll('img').length===1&&w.querySelector('.sn').src===wfSty(wfLook(),'n')})()"))
    pg.click('#lf .eyl');pg.wait_for_timeout(200);ok('37. O olho da tela de Entrar mostra e oculta a senha',pg.evaluate("document.querySelector('#lf [name=p]').type")=='text' and (pg.click('#lf .eyl'),pg.evaluate("document.querySelector('#lf [name=p]').type"))[1]=='password')  # 37b
    pg.evaluate("viewName()");pg.wait_for_selector('#nf')
    ok('40. Sem erros de script na entrada',not pg.errs,pg.errs);c.close()
    c,pg=novo();pg.wait_for_timeout(300)
    ok('41. Tela inicial: Wolfin em busto, com a imagem do estilo carregada',pg.evaluate("(()=>{const w=document.querySelector('#lock .wolf'),i=w.querySelector('.sn');return w.classList.contains('sty')&&w.classList.contains('lkb')&&w.dataset.k==='b'&&i.complete&&i.naturalWidth>0&&w.getBoundingClientRect().height>=84})()"))
    ok('42. Entrada suave do mascote (sequência do painel) e Começar visível sem rolar em 393x851',pg.evaluate("getComputedStyle(document.querySelector('#lock .wolf')).animationName")!='none' and pg.evaluate("(()=>{const r=document.querySelector('[data-lk=new]').getBoundingClientRect();return r.bottom<=innerHeight})()"))
    c.close()
    c,pg=novo(320,568);pg.wait_for_timeout(800)
    ok('43. 320x568: botão Começar e "Entrar" visíveis sem rolar',pg.evaluate("(()=>{const a=document.querySelector('[data-lk=new]').getBoundingClientRect(),e=document.querySelector('[data-lk=enter]').getBoundingClientRect();return a.bottom<=innerHeight&&e.bottom<=innerHeight})()"));c.close()
    c,pg=novo(393,851,True);pg.wait_for_timeout(300)
    ok('45. Boas-vindas: botão de tema não sobrepõe o cartão',pg.evaluate("(()=>{const a=document.querySelector('.lkth').getBoundingClientRect(),b=document.querySelector('#lock .lk').getBoundingClientRect();return a.bottom<=b.top+2})()"))
    ok('44. Movimento reduzido: sem aceno nem animação de entrada',pg.evaluate("document.querySelector('#lock .wolf').dataset.wx")!='tchau' and pg.evaluate("getComputedStyle(document.querySelector('#lock .wolf')).animationName")=='none');c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
