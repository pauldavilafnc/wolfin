"""Ferramentas rápidas (v7.6): botão encaixado na borda, mini painel, calculadora, notas e tarefas.
Só dados fictícios; Chromium simulado (sem celular real)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json,tempfile
from playwright.sync_api import sync_playwright
from PIL import Image
URL=HTTP_URL;PW="Senha-Forte-123";TMP=tempfile.mkdtemp(prefix='fr_')
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def lum(c):
    f=lambda v:(v/255/12.92) if v/255<=.03928 else ((v/255+.055)/1.055)**2.4
    return .2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2])
def ratio(a,b):
    x,y=lum(a),lum(b);return (max(x,y)+.05)/(min(x,y)+.05)
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th='light',**k):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th,**k)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        return c,pg
    def conta(w=393,h=851,th='light',nome='Ana',**k):
        c,pg=ctx(w,h,th,**k);pg.goto(URL);OB_NOSEC(pg,nome);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_selector('#cfab');pg.wait_for_timeout(700)
        pg.evaluate(f"S.pref.theme='{th}';applyPref()");return c,pg
    R_=lambda pg,s:pg.evaluate("s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return{l:r.left,t:r.top,r:r.right,b:r.bottom,w:r.width,h:r.height}}",s)
    vis=lambda pg,s:pg.evaluate("s=>{const e=document.querySelector(s);return !!e&&!e.hidden&&e.offsetWidth>0}",s)
    inside=lambda pg,s:pg.evaluate("s=>{const r=document.querySelector(s).getBoundingClientRect();return r.left>=-0.5&&r.top>=-0.5&&r.right<=innerWidth+0.5&&r.bottom<=innerHeight+0.5}",s)
    def tool(pg,n):
        if not vis(pg,'#tpan'):pg.evaluate("document.querySelector('#cfab').click()")   # v7.17: o botão fica no canto inferior; em telas minúsculas (320x568) com 2 janelas abertas uma janela pode cobri-lo (dá para arrastar a janela); aqui acionamos o mesmo botão por script
        pg.wait_for_selector('#tpan:not([hidden])');pg.click(f'[data-tool={n}]');pg.wait_for_timeout(350)
    def drag(pg,sel,dx,dy):
        r=R_(pg,sel);x,y=r['l']+r['w']/2,r['t']+(r['h']/2 if sel=='#cfab' else 20)
        pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+dx/2,y+dy/2,steps=4);pg.mouse.move(x+dx,y+dy,steps=4);pg.mouse.up();pg.wait_for_timeout(500)
    # ---------- 1. botão + painel ----------
    c,pg=conta()
    f=R_(pg,'#cfab')
    ok('1. Botão de ferramentas rápidas encaixado na borda direita, com nome acessível',abs(f['r']-393)<1.5 and pg.get_attribute('#cfab','aria-label')=='Ferramentas rápidas' and pg.get_attribute('#cfab','aria-expanded')=='false',f)
    pg.click('#cfab');pg.wait_for_timeout(400)
    items=pg.evaluate("[...document.querySelectorAll('#tpan .tmi')].map(x=>[x.querySelector('b').textContent,!!x.querySelector('svg'),x.dataset.tool])")
    m=R_(pg,'#tpan');f=R_(pg,'#cfab')
    ok('1. Toque abre o painel "FERRAMENTAS RÁPIDAS" com exatamente 3 opções (Calculadora, Notas, Lista de tarefas), cada uma com ícone',pg.inner_text('#tpan .tpt')=='FERRAMENTAS RÁPIDAS' and items==[['Calculadora',True,'calc'],['Notas',True,'notes'],['Lista de tarefas',True,'tasks']] and pg.get_attribute('#cfab','aria-expanded')=='true',items)
    ok('1. O painel abre ao lado do botão, dentro da tela',inside(pg,'#tpan') and m['r']<=f['l']+1 and m['t']<=f['b'] and m['b']>=f['t'],(m,f))
    pg.click('#tpx');pg.wait_for_timeout(400);a=not vis(pg,'#tpan')
    pg.click('#cfab');pg.wait_for_timeout(300);pg.mouse.click(40,300);pg.wait_for_timeout(400);b2=not vis(pg,'#tpan')
    pg.click('#cfab');pg.wait_for_timeout(300);pg.keyboard.press('Escape');pg.wait_for_timeout(400);c3=not vis(pg,'#tpan') and pg.evaluate("document.activeElement.id")=='cfab'
    pg.click('#cfab');pg.wait_for_timeout(300);fr_=R_(pg,'#cfab');pg.mouse.click(fr_['l']+20,fr_['t']+28);pg.wait_for_timeout(400);d=not vis(pg,'#tpan')
    ok('1. Fecha pelo X, tocando fora, com Esc (foco volta ao botão) e tocando no botão de novo',a and b2 and c3 and d,(a,b2,c3,d))
    n0=pg.evaluate("1")
    pg.click('#cfab');pg.wait_for_timeout(300);anim=pg.evaluate("getComputedStyle(document.getElementById('tpan')).animationName");pg.keyboard.press('Escape')
    ok('1. Animação suave de abertura (e de fechamento) definida',anim=='tpin',anim)
    # ---------- 2/3. arrastar, voltar à borda, esquerda e direita ----------
    c2,p2=conta()
    drag(p2,'#cfab',-260,-120);f=R_(p2,'#cfab');dk=p2.evaluate("JSON.parse(localStorage.getItem('wolfin.dock'))")
    ok('2. Arrastado para o meio-esquerdo, o botão volta suavemente e encaixa na borda ESQUERDA',abs(f['l'])<1.5 and dk['s']=='l',(f,dk))
    drag(p2,'#cfab',300,80);f=R_(p2,'#cfab');dk=p2.evaluate("JSON.parse(localStorage.getItem('wolfin.dock'))")
    ok('3. Arrastado para o lado direito, encaixa na borda DIREITA',abs(f['r']-393)<1.5 and dk['s']=='r',(f,dk))
    drag(p2,'#cfab',-60,0);f1=R_(p2,'#cfab')
    ok('2. Soltar em cima do meio da tela (perto do centro) leva à borda mais próxima, nunca fica no meio',f1['l']<1.5 or abs(f1['r']-393)<1.5,f1)
    p2.evaluate("document.getElementById('cfab').focus()");p2.keyboard.press('ArrowLeft');p2.wait_for_timeout(500);fl=R_(p2,'#cfab')
    p2.keyboard.press('ArrowRight');p2.wait_for_timeout(500);fr=R_(p2,'#cfab')
    ok('3. Pelo teclado (setas) também dá para escolher esquerda/direita',abs(fl['l'])<1.5 and abs(fr['r']-393)<1.5,(fl,fr))
    # limites verticais: não cobre o menu inferior nem a área do topo
    drag(p2,'#cfab',0,2000);fb=R_(p2,'#cfab');navb=R_(p2,'nav')
    drag(p2,'#cfab',0,-2000);ft=R_(p2,'#cfab')
    ok('2. Limites: nunca cobre a barra de navegação inferior nem sai pelo topo (áreas seguras respeitadas)',fb['b']<=navb['t']+0.5 and ft['t']>=40 and inside(p2,'#cfab'),(fb,navb,ft))
    # memória
    drag(p2,'#cfab',-300,-200);before=R_(p2,'#cfab')
    p2.evaluate("go('des')");p2.wait_for_timeout(300);p2.evaluate("go('rel')");p2.wait_for_timeout(300);mid=R_(p2,'#cfab')
    p2.reload();p2.wait_for_selector('#cfab');p2.wait_for_function("document.getElementById('lock').hidden",timeout=8000);p2.wait_for_timeout(700);after=R_(p2,'#cfab')
    ok('2. A posição do botão é memorizada ao navegar entre páginas e depois de recarregar',abs(before['t']-mid['t'])<1 and abs(before['t']-after['t'])<2 and abs(before['l']-after['l'])<1.5,(before,mid,after))
    ok('2. O botão continua visível e funcional em todas as páginas',all((p2.evaluate(f"go('{v}')"),p2.wait_for_timeout(150),vis(p2,'#cfab'))[2] for v in ['home','rec','des','div','cx','rel','cfg']))
    c2.close()
    # ---------- 4/5. calculadora ----------
    pg.evaluate("go('home')");tool(pg,'calc')
    ok('4. Calculadora abre pelo painel numa janela compacta, sem sair da página',vis(pg,'#cpan') and not vis(pg,'#tpan') and R_(pg,'#cpan')['w']<=230 and pg.evaluate("view")=='home')
    for k in ['7','+','8','=']:pg.click(f'#ck [data-k="{k}"]')
    ok('4. Operações existentes continuam funcionando (7 + 8 = 15)',pg.inner_text('#cr').strip()=='15',pg.inner_text('#cr'))
    r0=R_(pg,'#cpan');drag(pg,'#cpan',-40,150);r1=R_(pg,'#cpan')
    ok('5. A calculadora continua arrastável pelo cabeçalho',abs((r1['l']-r0['l'])+40)<3 and abs((r1['t']-r0['t'])-150)<3,(r0,r1))
    drag(pg,'#cpan',-900,-900);ra=R_(pg,'#cpan');drag(pg,'#cpan',900,2000);rb=R_(pg,'#cpan')
    ok('5. Nunca fica presa fora da tela (limites visíveis)',inside(pg,'#cpan') and ra['l']>=0 and ra['t']>=0 and rb['r']<=393 and rb['b']<=851,(ra,rb))
    pg.click('#cm');pg.wait_for_timeout(200);mn=not vis(pg,'#ck') and pg.get_attribute('#cm','aria-expanded')=='false'
    pg.click('#cm');pg.wait_for_timeout(200);rs=vis(pg,'#ck')
    ok('4. Minimizar recolhe a janela (só o cabeçalho) e restaurar volta ao normal; os controles continuam acessíveis',mn and rs and inside(pg,'#cpan'))
    pg.click('#cx');pg.wait_for_timeout(200);ok('4. Fechar fecha a calculadora e o botão continua no lugar',not vis(pg,'#cpan') and vis(pg,'#cfab'))
    # ---------- 6/7. notas ----------
    c3,p3=conta(nome='Notas')
    ok('6. Sem notas de início (nada criado automaticamente)',p3.evaluate("S.org.notes.length")==0)
    tool(p3,'notes')
    ok('6. Janela Notas abre compacta com botão de nova nota',vis(p3,'#npan') and p3.locator('#npan [data-nq=new]').count()==1 and inside(p3,'#npan'))
    p3.click('#npan [data-nq=new]');p3.fill('#nqT','Pagar internet dia 20');p3.fill('#nqD','Conferir valor da fatura');p3.wait_for_timeout(800)
    n=p3.evaluate("S.org.notes.map(x=>[x.t,x.d])")
    ok('7. Salvamento automático: a nota já está nos dados poucos instantes depois de digitar (sem botão salvar)',n==[['Pagar internet dia 20','Conferir valor da fatura']] and 'Salva automaticamente ✓' in p3.inner_text('#nqS'),n)
    p3.click('[data-nq=back]');p3.wait_for_timeout(200)
    ok('6. A nota aparece na lista da janela',p3.inner_text('#npan .qrow b')=='Pagar internet dia 20')
    p3.click('#npan [data-nq=open]');p3.fill('#nqD','Conferir valor da fatura e vencimento');p3.wait_for_timeout(800);p3.click('[data-nq=back]')
    ok('6. Editar: o texto novo foi salvo',p3.evaluate("S.org.notes[0].d")=='Conferir valor da fatura e vencimento')
    p3.click('#npan [data-nq=new]');p3.click('[data-nq=back]');p3.wait_for_timeout(200)
    ok('6. Nota nova deixada vazia não vira lixo (é descartada)',p3.evaluate("S.org.notes.length")==1)
    p3.click('#npan [data-nq=new]');p3.fill('#nqT','Segunda nota');p3.wait_for_timeout(700);p3.click('[data-nq=back]')
    p3.evaluate("go('nt')");p3.wait_for_timeout(400)
    ok('6. Integração: as mesmas notas aparecem na área Anotações da Home (sem duplicidade)','Pagar internet dia 20' in p3.inner_text('#s-nt') and 'Segunda nota' in p3.inner_text('#s-nt') if p3.locator('#s-nt').count() else 'Pagar internet dia 20' in p3.inner_text('main'),p3.inner_text('main')[:120])
    ok('6. A janela de notas continua aberta durante a navegação entre páginas',vis(p3,'#npan'))
    p3.reload();p3.wait_for_function("document.getElementById('lock').hidden",timeout=8000);p3.wait_for_timeout(600);tool(p3,'notes')
    ok('7. Persistência: as notas continuam depois de recarregar o site',p3.locator('#npan .qrow').count()==2)
    p3.click('#npan [data-nq=open] >> nth=0');p3.click('[data-nq=del]');p3.wait_for_timeout(150)
    ok('6. Excluir pede confirmação antes de apagar',p3.evaluate("S.org.notes.length")==2 and p3.locator('[data-nq=yes]').count()==1)
    p3.click('[data-nq=no]');ok('6. Cancelar mantém a nota',p3.evaluate("S.org.notes.length")==2)
    p3.click('[data-nq=del]');p3.click('[data-nq=yes]');p3.wait_for_timeout(300)
    ok('6. Confirmar exclui a nota',p3.evaluate("S.org.notes.length")==1 and p3.locator('#npan .qrow').count()==1)
    ok('8. As notas usam o armazenamento do app (dentro da conta); a chave do botão não guarda texto de nota','Segunda' not in p3.evaluate("String(localStorage.getItem('wolfin.dock'))+String(localStorage.getItem('wolfin.win'))"))
    # ---------- 8. tarefas ----------
    ok('8. Sem tarefas criadas automaticamente (nenhuma lista antes de o usuário adicionar)',p3.evaluate("S.org.lists.length")==0)
    tool(p3,'tasks')
    ok('8. Janela Lista de tarefas com campo para adicionar',vis(p3,'#kpan') and p3.locator('#qkin').count()==1 and inside(p3,'#kpan'))
    for t in ['Pagar contas','Fazer backup','Verificar vencimentos']:
        p3.fill('#qkin',t);p3.press('#qkin','Enter');p3.wait_for_timeout(120)
    ok('8. Adicionar tarefas (Enter ou botão)',p3.evaluate("S.org.lists[0].items.map(i=>i.t)")==['Pagar contas','Fazer backup','Verificar vencimentos'] and p3.locator('#kpan .qk').count()==3)
    p3.click('#kpan [data-k=tog] >> nth=0');p3.wait_for_timeout(150)
    st=p3.evaluate("(()=>{const d=document.querySelector('#kpan .qk.ok');return{n:document.querySelectorAll('#kpan .qk.ok').length,td:getComputedStyle(d.querySelector('.qkt')).textDecorationLine,ar:d.querySelector('[data-k=tog]').getAttribute('aria-checked'),last:[...document.querySelectorAll('#kpan .qk')].pop().classList.contains('ok'),saved:S.org.lists[0].items.filter(i=>i.ok).length}})()")
    ok('8. Marcar como concluída: riscada, caixa marcada, vai para o fim e fica salva',st['n']==1 and 'line-through' in st['td'] and st['ar']=='true' and st['last'] and st['saved']==1,st)
    p3.click('#kpan .qk.ok [data-k=tog]');p3.wait_for_timeout(150)
    ok('8. Desmarcar volta a pendente',p3.evaluate("S.org.lists[0].items.filter(i=>i.ok).length")==0 and p3.locator('#kpan .qk.ok').count()==0)
    p3.click('#kpan [data-k=del] >> nth=1');p3.wait_for_timeout(150)
    ok('8. Excluir tarefa',p3.evaluate("S.org.lists[0].items.map(i=>i.t)")==['Pagar contas','Verificar vencimentos'])
    p3.click('#kpan [data-k=tog] >> nth=0')
    p3.reload();p3.wait_for_function("document.getElementById('lock').hidden",timeout=8000);p3.wait_for_timeout(600);tool(p3,'tasks')
    ok('9. Persistência: tarefas e o estado concluída/pendente continuam depois de recarregar',p3.locator('#kpan .qk').count()==2 and p3.locator('#kpan .qk.ok').count()==1)
    p3.evaluate("NTV='lists';go('nt')");p3.wait_for_timeout(400);txt=p3.inner_text('main')
    ok('9. Integração: as tarefas aparecem como a lista "Tarefas rápidas" em Anotações (mesmos dados)','Tarefas rápidas' in txt,txt[:150])
    # ---------- 10. janelas independentes e navegação ----------
    c4,p4=conta(1280,800,nome='Jan')
    tool(p4,'calc');tool(p4,'notes');tool(p4,'tasks')
    rs=[R_(p4,s) for s in ('#cpan','#npan','#kpan')]
    ov=lambda a,b:max(0,min(a['r'],b['r'])-max(a['l'],b['l']))*max(0,min(a['b'],b['b'])-max(a['t'],b['t']))
    ok('10. No computador as três janelas abrem ao mesmo tempo, sem se sobrepor e sem cobrir o menu lateral',ov(rs[0],rs[1])==0 and ov(rs[0],rs[2])==0 and ov(rs[1],rs[2])==0 and all(inside(p4,s) for s in ('#cpan','#npan','#kpan')) and all(r['l']>=R_(p4,'nav')['r']-1 for r in rs) or all(r['l']>=0 for r in rs),rs)
    p4.evaluate("go('des')");p4.wait_for_timeout(300);p4.evaluate("go('cfg')");p4.wait_for_timeout(300)
    ok('10. As janelas ficam abertas ao navegar entre as páginas (dá para consultar uma conta e usar a ferramenta)',all(vis(p4,s) for s in ('#cpan','#npan','#kpan')))
    drag(p4,'#npan',200,100);rn=R_(p4,'#npan');drag(p4,'#kpan',-3000,-3000);rk=R_(p4,'#kpan')
    ok('10. Notas e tarefas também são arrastáveis e não saem da tela',abs(rn['l']-rs[1]['l']-200)<3 and rk['l']>=0 and rk['t']>=0 and inside(p4,'#kpan'),(rn,rk))
    p4.click('#npan [data-q=min]');p4.click('#kpan [data-q=min]');p4.wait_for_timeout(200)
    ok('10. Minimizar notas e tarefas (só o cabeçalho) e fechar funcionam',p4.evaluate("document.querySelector('#npan').classList.contains('min')&&document.querySelector('#kpan').classList.contains('min')&&document.querySelector('#npan .qbd').offsetHeight===0"))
    p4.click('#npan [data-q=x]');p4.click('#kpan [data-q=x]');p4.click('#cx');p4.wait_for_timeout(200)
    ok('10. Fechar as três janelas',not any(vis(p4,s) for s in ('#cpan','#npan','#kpan')))
    c4.close()
    # ---------- 11. tema claro/escuro (contraste por pixel) ----------
    def contraste(pg,sel):
        r=R_(pg,sel);im=Image.open(__import__('io').BytesIO(pg.screenshot(clip={'x':r['l'],'y':r['t'],'width':max(1,r['w']),'height':max(1,r['h'])}))).convert('RGB')
        px=list(im.getdata());from collections import Counter;bg=Counter(px).most_common(1)[0][0]
        fg=max(px,key=lambda c:ratio(c,bg));return round(ratio(fg,bg),1)
    for th in ('light','dark'):
        cc,pp=conta(th=th,nome='Tm'+th[0])
        pp.evaluate("S.org.notes.unshift({id:'z1',t:'Nota de teste',d:'texto',u:Date.now()});S.org.lists.unshift({id:'qk',n:'Tarefas rápidas',items:[{id:'i1',t:'Pagar contas',ok:0},{id:'i2',t:'Fazer backup',ok:1}]})")
        pp.click('#cfab');pp.wait_for_timeout(400);cm=[contraste(pp,'#tpan .tpt'),contraste(pp,'#tpan .tmn b'),contraste(pp,'#tpan .tmn small')]
        tool(pp,'notes');cn=[contraste(pp,'#npan .qt'),contraste(pp,'#npan .qrow b')]
        tool(pp,'tasks');ck=[contraste(pp,'#kpan .qt'),contraste(pp,'#kpan .qk:not(.ok) .qkt'),contraste(pp,'#kpan .qkc')]
        ok(f'11. Tema {th}: painel, notas e tarefas legíveis (contraste ≥ 4,5:1 nos textos principais)',min(cm+cn+ck[:2])>=4.5 and ck[2]>=3.8,(cm,cn,ck))
        pp.screenshot(path=os.path.join(TMP,f'fr_{th}.png'));cc.close()
    # ---------- 12. celulares ----------
    for w,h in ((393,851),(360,640),(320,568),(851,393)):
        cc,pp=conta(w,h,nome=f'R{w}')
        pp.click('#cfab');pp.wait_for_timeout(350);mi=inside(pp,'#tpan');pp.click('#tpx');pp.wait_for_timeout(300)
        tool(pp,'tasks');tool(pp,'notes');tool(pp,'calc')
        ins=all(inside(pp,s) for s in ('#kpan','#npan','#cpan'))
        sm=pp.evaluate("[...document.querySelectorAll('#npan button,#kpan button,#cpan #chd button,#tpan button')].filter(x=>x.offsetWidth>0&&(x.getBoundingClientRect().height<39||x.getBoundingClientRect().width<39)).map(x=>x.className+x.getAttribute('aria-label'))")
        wd=pp.evaluate("[...document.querySelectorAll('.qw')].every(w=>w.getBoundingClientRect().width<=innerWidth-8)&&document.documentElement.scrollWidth<=innerWidth+1")
        ok(f'12. {w}x{h}: painel e janelas dentro da tela, controles ≥ 40 px, janelas não ocupam a tela inteira, sem rolagem lateral',mi and ins and not sm and wd,(mi,ins,sm,wd))
        pp.click('#cx');pp.click('#kpan [data-q=x]');pp.click('#npan [data-q=x]')
        drag(pp,'#cfab',-200,-50);fb=R_(pp,'#cfab')
        ok(f'12. {w}x{h}: botão arrastável e encaixado na borda',fb['l']<1.5 or abs(fb['r']-w)<1.5,fb);cc.close()
    # ---------- 13. conta protegida: dados cifrados e isolados ----------
    cc,pp=ctx();pp.goto(URL);OB_TO_SETUP(pp,'Pro');pp.fill('#sf [name=p]',PW);pp.fill('#sf [name=c]',PW);pp.click('#sf .b1');pp.wait_for_selector('#skcode',timeout=25000);pp.check('#skok');pp.click('#skdone');pp.wait_for_function("document.getElementById('lock').hidden",timeout=25000);pp.wait_for_selector('#cfab');pp.wait_for_timeout(700)
    tool(pp,'notes');pp.click('#npan [data-nq=new]');pp.fill('#nqT','SEGREDO-DA-NOTA-123');pp.wait_for_timeout(900);pp.click('[data-nq=back]')
    tool(pp,'tasks');pp.fill('#qkin','TAREFA-SECRETA-456');pp.press('#qkin','Enter');pp.wait_for_timeout(900)
    raw=pp.evaluate("Object.keys(localStorage).map(k=>localStorage.getItem(k)).join('|')")
    ok('13. Conta com senha: notas e tarefas ficam criptografadas (o texto não aparece em claro no armazenamento do navegador)','SEGREDO-DA-NOTA-123' not in raw and 'TAREFA-SECRETA-456' not in raw,len(raw))
    pp.wait_for_timeout(400);pp.evaluate("lockNow()");pp.wait_for_selector('#lf');pp.wait_for_timeout(300)
    body=pp.evaluate("document.documentElement.innerText+document.getElementById('nbd').innerHTML+document.getElementById('kbd').innerHTML")
    ok('13. Ao bloquear/sair: janelas fecham e nenhum conteúdo de notas/tarefas continua na tela',not vis(pp,'#npan') and not vis(pp,'#kpan') and not vis(pp,'#tpan') and 'SEGREDO-DA-NOTA-123' not in body and 'TAREFA-SECRETA-456' not in body)
    pp.fill('#lf [name=p]',PW);pp.click('#lf button:not([type=button])');pp.wait_for_function("document.getElementById('lock').hidden",timeout=25000);pp.wait_for_timeout(600)
    tool(pp,'notes');t1=pp.inner_text('#npan .qrow b');tool(pp,'tasks');t2=pp.inner_text('#kpan .qkt')
    ok('13. Depois de entrar de novo, notas e tarefas estão lá (persistem dentro da conta)',t1=='SEGREDO-DA-NOTA-123' and t2=='TAREFA-SECRETA-456',(t1,t2))
    ok('13. Sem erros no console durante o uso',not pp.errs and not p3.errs and not pg.errs,(pp.errs+p3.errs+pg.errs)[:3]);cc.close()
    # ---------- 14. PWA offline ----------
    cc,pp=ctx(service_workers='allow');pp.goto(URL);OB_NOSEC(pp,'Off');pp.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pp.evaluate("navigator.serviceWorker.ready.then(()=>1)");pp.wait_for_timeout(2500)
    cc.set_offline(True);pp.reload();pp.wait_for_selector('#cfab',timeout=15000);pp.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pp.wait_for_timeout(600)
    tool(pp,'notes');pp.click('#npan [data-nq=new]');pp.fill('#nqT','Nota offline');pp.wait_for_timeout(800);pp.click('[data-nq=back]');tool(pp,'tasks');pp.fill('#qkin','Tarefa offline');pp.press('#qkin','Enter');pp.wait_for_timeout(300)
    tool(pp,'calc');pp.click('#ck [data-k="9"]');pp.click('#ck [data-k="×"]');pp.click('#ck [data-k="9"]');pp.click('#ck [data-k="="]')
    ok('14. Offline (com o app em cache): botão, painel, calculadora, notas e tarefas funcionam e salvam',pp.inner_text('#cr').strip()=='81' and pp.evaluate("S.org.notes[0].t")=='Nota offline' and pp.evaluate("S.org.lists[0].items[0].t")=='Tarefa offline')
    pp.reload();pp.wait_for_selector('#cfab',timeout=15000);pp.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pp.wait_for_timeout(500)
    ok('14. Offline: os dados continuam depois de recarregar',pp.evaluate("S.org.notes[0].t")=='Nota offline' and pp.evaluate("S.org.lists[0].items.length")==1);cc.close()
    b.close()
print(sum(R),'/',len(R))
