"""v7.38: menu de perfil simplificado + Configurações como índice de categorias + Gerenciamento de dados. Dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import json,tempfile
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
CATS=['perfil','aparencia','contas','segbkp','mascote','conquistas','sobre']
TIT={'perfil':'Perfil','aparencia':'Aparência','contas':'Contas e saldos','segbkp':'Segurança e backups','mascote':'Wolfin, o mascote','conquistas':'Conquistas','sobre':'Sobre o Wolfin'}
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,timezone_id='America/Sao_Paulo');c.add_init_script("window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.goto(HTTP_URL);OB_NOSEC(pg,'Maria Teste');pg.wait_for_function("document.getElementById('lock').hidden");pg.wait_for_timeout(500);return c,pg
    menu=lambda pg:(pg.click('#avh'),pg.wait_for_selector('#pm.on'),pg.wait_for_timeout(250))
    pick=lambda pg,i:(pg.click(f'#pm [data-act=pmgo][data-id={i}]'),pg.wait_for_selector('#s-cfg:not([hidden])'),pg.wait_for_timeout(300))
    cat=lambda pg,i:(pg.click(f'#s-cfg [data-act=cat][data-id={i}]'),pg.wait_for_timeout(250))
    tit=lambda pg:pg.inner_text('#s-cfg .sbar h2').strip()
    back=lambda pg:(pg.click('#s-cfg [data-act=back]'),pg.wait_for_timeout(300))
    st=lambda pg:pg.evaluate("[view,CFGCAT]")
    c,pg=app()
    # 1 menu abre/fecha
    menu(pg)
    it=pg.evaluate("[...document.querySelectorAll('#pm .pml .pmi')].map(b=>b.innerText.trim())")
    ok('1. Menu do perfil abre com 4 opções, na ordem: Meu perfil, Configurações, Backups, Segurança',it==['Meu perfil','Configurações','Backups','Segurança'],it)
    ok('1. Sem os atalhos "Aparência e temas" e "Ativar proteção por senha" (sem senha ativa nem rodapé)',pg.locator('#pm [data-id=apa]').count()==0 and pg.locator('#pm [data-id=secon]').count()==0 and 'proteção por senha' not in pg.inner_text('#pm'),pg.inner_text('#pm'))
    ok('1. Cabeçalho: foto, nome e informação de armazenamento local',pg.locator('#pm .pmav').count()==1 and 'Maria Teste' in pg.inner_text('#pm .pmn b') and 'Dados só neste aparelho' in pg.inner_text('#pm .pmn'))
    pg.keyboard.press('Escape');pg.wait_for_timeout(350)
    ok('1. Fecha com Esc',not pg.evaluate("PMO"))
    menu(pg);pg.click('#pm .pmsc',position={'x':5,'y':600});pg.wait_for_timeout(350)
    ok('1. Fecha tocando fora',not pg.evaluate("PMO"))
    # 2 Meu perfil
    menu(pg);pick(pg,'own')
    ok('2. Meu perfil abre Configurações > Perfil (nome do proprietário + foto), sem duplicar função',st(pg)==['cfg','perfil'] and tit(pg)=='Perfil' and pg.locator('#own').count()==1 and pg.locator('[data-act=avs]').count()==1)
    pg.fill('#own','Joana Teste');pg.click('[data-act=own]');pg.wait_for_timeout(300)
    ok('2. Salvar nome continua funcionando',pg.evaluate("S.owner")=='Joana Teste')
    pg.click('[data-act=avs]');pg.wait_for_selector('#ov .avs');ok('2. "Alterar foto" abre a personalização da foto',True);pg.keyboard.press('Escape');pg.wait_for_timeout(300)
    if pg.evaluate("!document.getElementById('ov').hidden"): pg.evaluate("closeOv()")
    # 3 Configurações = índice
    pg.evaluate("go('home')");pg.wait_for_timeout(200);menu(pg);pick(pg,'cfg')
    ids=pg.evaluate("[...document.querySelectorAll('#s-cfg [data-act=cat]')].map(b=>b.dataset.id)")
    ok('3. Configurações abre o índice com as 7 categorias, na ordem pedida',ids==CATS and st(pg)==['cfg',None],ids)
    ok('3. Índice só tem os cartões de categorias + Gerenciamento de dados (conteúdo das categorias não é desenhado)',pg.locator('#cs-own,#cs-apa,#cs-bkp,#cs-sec,#cs-sal,#cs-wolf,#cs-foto').count()==0 and pg.locator('#cs-reset [data-act=reset]').count()==1 and pg.locator('#cs-fresh [data-act=fresh]').count()==1)
    sub=pg.evaluate("[...document.querySelectorAll('#s-cfg .cfgcat small')].map(e=>e.innerText.trim())")
    ok('3. Cada categoria tem descrição curta',all(len(x)>8 for x in sub) and len(sub)==7,sub)
    # 9 sem barra inferior
    ok('9. Sem barra inferior de abas nas Configurações (índice)',not pg.evaluate("(()=>{const n=document.getElementById('nav');return !!n&&!n.hidden&&getComputedStyle(n).display!=='none'&&n.getBoundingClientRect().height>0})()"))
    # 6 navegação entre categorias + títulos + sem rolagem horizontal
    allok=True;det=[]
    for k in CATS:
        pg.evaluate("go('cfg')") if st(pg)[0]!='cfg' else None
        if st(pg)[1]: back(pg)
        cat(pg,k);t=tit(pg);sh=pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1");nb=pg.evaluate("(()=>{const n=document.getElementById('nav');return !n||n.hidden||getComputedStyle(n).display==='none'||n.getBoundingClientRect().height===0})()")
        good=(t==TIT[k] and st(pg)==['cfg',k] and sh and nb);allok=allok and good;det.append((k,t,sh,nb))
        back(pg);good2=st(pg)==['cfg',None] and tit(pg)=='Configurações';allok=allok and good2
    ok('6. Cada categoria abre com o título certo, sem barra inferior e sem rolagem horizontal; Voltar leva ao índice',allok,det)
    # 4/5 diretos
    c.close();c,pg=app();menu(pg);pick(pg,'bkp')
    ok('4. Backups abre direto a seção de backup (categoria Segurança e backups, cartão de backup visível)',st(pg)==['cfg','segbkp'] and pg.is_visible('#cs-bkp [data-act=exp]') and pg.evaluate("(()=>{const r=document.getElementById('cs-bkp').getBoundingClientRect();return r.top<innerHeight*0.6&&r.bottom>0})()"))
    c.close();c,pg=app();menu(pg);pick(pg,'sec')
    ok('5. Segurança abre direto a seção de segurança',st(pg)==['cfg','segbkp'] and pg.is_visible('#cs-sec') and pg.evaluate("(()=>{const r=document.getElementById('cs-sec').getBoundingClientRect();return r.top<innerHeight*0.6&&r.bottom>0})()"))
    ok('5. Segurança e Backups ficam na mesma categoria, com Segurança primeiro',pg.evaluate("document.getElementById('cs-sec').compareDocumentPosition(document.getElementById('cs-bkp'))&4")>0)
    # 7/8 Voltar do app e do Android
    c.close();c,pg=app();menu(pg);pick(pg,'bkp')
    back(pg);ok('7. Botão Voltar do app: categoria → índice',st(pg)==['cfg',None])
    back(pg);ok('7. Botão Voltar do app: índice → tela anterior (Home)',pg.evaluate("view")=='home')
    c.close();c,pg=app();menu(pg);pick(pg,'bkp');pg.go_back();pg.wait_for_timeout(350)
    ok('8. Voltar do Android (history.back): categoria → índice',st(pg)==['cfg',None],st(pg))
    pg.go_back();pg.wait_for_timeout(350)
    ok('8. Voltar do Android: índice → tela anterior (Home)',pg.evaluate("view")=='home',st(pg))
    c.close();c,pg=app();menu(pg);pick(pg,'cfg');cat(pg,'aparencia');pg.go_back();pg.wait_for_timeout(300);a=st(pg);pg.go_back();pg.wait_for_timeout(300)
    ok('8. Índice → Aparência → Android Voltar → índice → Android Voltar → Home',a==['cfg',None] and pg.evaluate("view")=='home',(a,st(pg)))
    # contexto preservado: formulário digitado e Loja
    c.close();c,pg=app();menu(pg);pick(pg,'own');pg.fill('#own','Texto Digitado');pg.click('[data-act=avs]');pg.wait_for_selector('#ov .avs');pg.evaluate('closeOv()');pg.wait_for_timeout(300)
    ok('7. Abrir/fechar a janela da foto dentro da categoria não perde o texto digitado',pg.input_value('#own')=='Texto Digitado' and st(pg)==['cfg','perfil'])
    # 10/11 temas e persistência
    pg.evaluate("go('home')");pg.wait_for_timeout(150);OPEN_CFG(pg,'aparencia')
    pg.click('[data-act=theme][data-id=dark]');pg.wait_for_timeout(300)
    d1=pg.evaluate("S.pref.theme")=='dark' and pg.evaluate("document.documentElement.dataset.theme||document.body.dataset.theme||getComputedStyle(document.body).colorScheme")
    pg.click('#s-cfg details[data-det=aparencia] summary');pg.wait_for_timeout(200)
    pg.click('[data-act=pal]:not(.on)');pg.wait_for_timeout(250);pal=pg.evaluate("S.pref.pal")
    pg.select_option('#glSel','0');pg.select_option('#anSel','0');pg.wait_for_timeout(250)
    ok('10. Tema escuro, paleta, vidro e animações mudam na categoria Aparência',d1 and pg.evaluate("S.pref.gl")==0 and pg.evaluate("S.pref.av.an")==0 and pal,pal)
    pg.reload();pg.wait_for_selector('#lock',state='attached');pg.wait_for_timeout(1200)
    ok('11. Preferências persistem depois de recarregar',pg.evaluate("(()=>{const s=JSON.parse(localStorage.getItem(KEY)||'{}');return s.pref&&s.pref.theme==='dark'&&s.pref.gl===0&&s.pref.av&&s.pref.av.an===0})()"))
    c.close()
    # 12 contas e saldos
    c,pg=app();OPEN_CFG(pg,'contas')
    ok('12. Contas e saldos mostra saldo inicial, movimentações, saldo atual, previsto e histórico/conferência',all(x in pg.inner_text('#cs-sal') for x in ['Saldo inicial','Saldo atual']) and pg.locator('#cs-sal [data-act]').count()>=2,pg.inner_text('#cs-sal')[:400])
    pg.evaluate("S.opening={c:100000,d:todayStr()};save();render()");pg.wait_for_timeout(300)
    ok('12. Valores do saldo vêm do mesmo cálculo de antes (balance())',pg.evaluate("document.getElementById('cs-sal').innerText.includes(brl(balance()))"))
    # 13 backup e restauração
    pg.evaluate("S.items.push({id:'a1',t:'exp',d:'Teste',c:5000,day:5,fixed:false,ym:'2026-11',cat:'Outros',pay:'Pix'});save()");OPEN_CFG(pg,'bkp');txt=pg.evaluate("bkpExportText()");f=tempfile.NamedTemporaryFile('w',suffix='.json',delete=False,encoding='utf-8');f.write(txt);f.close()
    pg.evaluate("S.items=[];save()");pg.set_input_files('#file',f.name);pg.wait_for_timeout(400)
    ok('13. Importar backup (pela categoria) abre a confirmação',pg.locator('[data-act=yes]').count()>=1)
    pg.click('[data-act=yes]');pg.wait_for_timeout(700)
    ok('13. Backup restaurado: o lançamento volta e sem erros',not pg.errs and pg.evaluate("S.items.some(i=>i.id==='a1')"),pg.errs[:2])
    ok('13. Exportar, importar, criptografado, último backup e "Como fazer backup?" continuam na seção Backups',all(pg.locator(f'#s-cfg #cs-bkp {x}').count()==1 for x in ['[data-act=exp]','[data-act=imp]','[data-act=expenc]','[data-act=bkt]']) and 'backup' in pg.inner_text('#cs-bkp').lower())
    # 14 senha
    OPEN_CFG(pg,'sec');pg.click('#cs-sec [data-act=secon]');pg.wait_for_timeout(500)
    ok('14. "Ativar proteção" continua na seção Segurança e abre a configuração de usuário e senha',pg.evaluate("!document.getElementById('lock').hidden")and pg.locator('#lock input').count()>=2,pg.inner_text('#lock')[:150])
    c.close();c,pg=app()
    # 15 e 16 mascote e loja
    OPEN_CFG(pg,'mascote');on0=pg.evaluate("wfOn()");pg.click('[data-act=wfon]');pg.wait_for_timeout(300)
    ok('15. Interruptor do mascote liga/desliga',pg.evaluate("wfOn()")!=on0)
    pg.click('[data-act=wfon]');pg.wait_for_timeout(200)
    pg.click('#cs-wolf [data-act=nav][data-id=loja]');pg.wait_for_timeout(400)
    ok('16. "Abrir a Loja do Wolfin" abre a Loja',pg.evaluate("view")=='loja')
    pg.click('#s-loja [data-act=back]');pg.wait_for_timeout(350)
    ok('16. Voltar da Loja retorna à categoria do mascote (contexto preservado)',st(pg)==['cfg','mascote'],st(pg))
    pg.evaluate("go('home')");pg.wait_for_timeout(300)
    ok('16. Tocar no mascote na Home continua abrindo a Loja',pg.locator('.mqb[data-id=loja],[data-act=nav][data-id=loja]').count()>=1)
    # 17 conquistas
    OPEN_CFG(pg,'conquistas');pg.click('#s-cfg [data-act=nav][data-id=conq]');pg.wait_for_timeout(300)
    ok('17. Conquistas abre a tela de conquistas já existente',pg.evaluate("view")=='conq')
    # 18 sobre
    OPEN_CFG(pg,'sobre');tx=pg.inner_text('#s-cfg')
    ok('18. Sobre: nome, versão, verificar atualização, tutorial, criador, desenvolvimento e finalidade',all(x.lower() in tx.lower() for x in ['Wolfin','Versão 7.38','Verificar atualização','Ver o tutorial','Paul D','Desenvolvimento','Finalidade']) and pg.locator('#s-cfg img').count()>=1,tx[:300])
    ok('18. Avisos importantes e direitos autorais ficam numa seção expansível (fechada de início) com o texto completo',pg.locator('#s-cfg details[data-det=avisos]').count()==1 and not pg.evaluate("document.querySelector('details[data-det=avisos]').open") and 'não uma instituição financeira' in pg.evaluate("document.querySelector('details[data-det=avisos]').textContent") and 'Todos os direitos reservados' in pg.evaluate("document.querySelector('details[data-det=avisos]').textContent"))
    pg.click('#s-cfg [data-act=tourgo]');pg.wait_for_timeout(500);ok('18. "Ver o tutorial" abre o tutorial',pg.evaluate("!!TOUR||!!document.querySelector('.tour,#tour')"))
    c.close()
    # 19-21 gerenciamento de dados
    c,pg=app();pg.evaluate("S.items.push({id:'a1',t:'exp',d:'Teste',c:5000,day:5,fixed:false,ym:'2026-11',cat:'Outros',pay:'Pix'});S.owner='Maria Teste';save();render()")
    OPEN_CFG(pg,'cfg');t=pg.inner_text('#s-cfg .cfgdm')
    ok('19. "Gerenciamento de dados" fica no fim do índice, com as duas opções separadas',pg.evaluate("(()=>{const d=document.querySelector('#s-cfg .cfgdm'),k=[...document.querySelectorAll('#s-cfg .cfgcat')].pop();return !!d&&(k.compareDocumentPosition(d)&4)>0})()") and 'Zerar todos os dados' in t and 'Voltar ao início' in t)
    ok('19. Texto explica a diferença (limpeza parcial × restauração completa), recomenda backup e não afirma apagar backups externos',all(x in t for x in ['Limpeza parcial','Restauração completa','exporte um backup','não são apagados']),t[:200])
    ok('19. "Voltar ao início" é diferenciado visualmente',pg.evaluate("getComputedStyle(document.getElementById('cs-fresh')).borderTopColor!==getComputedStyle(document.getElementById('cs-reset')).borderTopColor"))
    pg.click('[data-act=reset]');pg.wait_for_selector('#f');pg.fill('#f input','zerar');pg.click('#f button[type=submit]');pg.wait_for_timeout(500)
    ok('19. Zerar todos os dados: apaga lançamentos e mantém nome/tema/senha (comportamento v7.37)',pg.evaluate("S.items.length")==0 and pg.evaluate("S.owner")=='Maria Teste')
    pg.evaluate("S.items.push({id:'a2',t:'exp',d:'Teste',c:5000,day:5,fixed:false,ym:'2026-11',cat:'Outros',pay:'Pix'});save()")
    pg.click('[data-act=reset]');pg.wait_for_selector('#f');pg.fill('#f input','errado');pg.click('#f button[type=submit]');pg.wait_for_timeout(300)
    ok('19. Confirmação errada em Zerar não apaga nada e mostra mensagem',pg.evaluate("S.items.length")==1 and 'ZERAR' in pg.inner_text('#er'));pg.evaluate("closeOv()")
    pg.click('#cs-fresh [data-act=fresh]');pg.wait_for_selector('#f');pg.fill('#f input','apagar');pg.click('#f button[type=submit]');pg.wait_for_timeout(400)
    ok('21. Voltar ao início exige digitar APAGAR TUDO; texto errado não apaga nada',pg.evaluate("S.items.length")==1 and 'APAGAR TUDO' in pg.inner_text('#er') and pg.evaluate("localStorage.getItem(KEY)")!=None)
    pg.keyboard.press('Escape');pg.evaluate("closeOv()");pg.wait_for_timeout(200)
    ok('21. Nenhuma exclusão acontece só por abrir Configurações ou as categorias',pg.evaluate("S.items.length")==1)
    pg.click('#cs-fresh [data-act=fresh]');pg.wait_for_selector('#f');pg.fill('#f input','APAGAR TUDO')
    with pg.expect_navigation(): pg.click('#f button[type=submit]')
    pg.wait_for_timeout(1200)
    ok('20. Voltar ao início: tudo some do aparelho e o app abre nas boas-vindas',pg.evaluate("!document.getElementById('lock').hidden")and 'Oi, eu sou Wolfin' in pg.inner_text('#lock') and pg.evaluate("S.items.length")==0)
    c.close()
    # menu com senha ativa: "Sair da conta" continua
    c,pg=app();pg.evaluate("SECMODE=true;SECOBJ={u:'maria'}");menu(pg)
    ok('1. Com proteção ativa, o menu mantém o item "Sair da conta" além das 4 opções',pg.evaluate("[...document.querySelectorAll('#pm .pmf .pmi')].map(b=>b.innerText.trim())")==['Sair da conta'] and pg.evaluate("document.querySelectorAll('#pm .pml .pmi').length")==4)
    c.close();b.close()
print('\n%d/%d'%(sum(R),len(R)));sys.exit(0 if all(R) else 1)
