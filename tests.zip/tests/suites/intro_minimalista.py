"""v7.15: intro minimalista (~2,6 s) com a nova logo e som gerado pelo aparelho (WebAudio, sem arquivo). Só dados fictícios; Chromium simulado
(o som real num celular depende da permissão do navegador — aqui o áudio é verificado com um AudioContext de teste e com o do próprio Chromium)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json,time
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html')
# AudioContext de teste: registra o que seria tocado
STUB="""(()=>{window.__au={osc:[],started:0,resumes:0,closed:0,state:'%s',maxStop:0};
class G{constructor(){this.gain={value:1,setValueAtTime(){},exponentialRampToValueAtTime(){}}}connect(){}}
class AC{constructor(){this.state=window.__au.state;this.currentTime=0;this.destination={}}
resume(){window.__au.resumes++;if(window.__au.unlock){this.state='running'}return Promise.resolve()}
close(){window.__au.closed++;return Promise.resolve()}createGain(){return new G()}createDelay(){return{delayTime:{value:0},connect(){}}}
createOscillator(){const o={type:'',frequency:{value:0},connect(){},start(t){window.__au.started++;o.t0=t},stop(t){window.__au.maxStop=Math.max(window.__au.maxStop,t)}};window.__au.osc.push(o);return o}}
window.AudioContext=AC})()"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th='light',stub=None,reduce=False,csp=False,**k):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th,reduced_motion='reduce' if reduce else 'no-preference',**k)
        if not csp:c.add_init_script("window.__WS_NOCSP=1")
        c.add_init_script("window.__v=[];addEventListener('securitypolicyviolation',e=>window.__v.push(e.violatedDirective))")
        if stub:c.add_init_script(stub)
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));return c,pg
    ev=lambda pg,x:pg.evaluate(x)
    # ---- estrutura ----
    ok('A intro existe no código com a logo (icon-512.png), nome e slogan; sem vídeo nem arquivo de mídia',all(x in html for x in ('id="intro"','src="icon-512.png"','>WOLFIN</b>','Domine seu dinheiro.</span>')) and not re.search(r'<video|\.mp4|\.webm(?![a-z])',html))
    ok('Intro leve: o código da intro (CSS + script) ocupa menos de 8 KB',len(html[html.index('<style id="intro-css">'):html.index('</style>',html.index('<style id="intro-css">'))])+len(html[html.index('<script>/* intro:'):html.index('</script>',html.index('<script>/* intro:'))])<8000)
    ok('A intro só usa transform/opacidade (nada de largura/altura/posição animadas)',not re.search(r'@keyframes (ilogo|itx)\{[^}]*(width|height|top|left|margin)',html))
    # ---- abertura real: aparece, cobre, some sozinha em ~2,6 s e o login já está por baixo ----
    for th in ('light','dark'):
        c,pg=ctx(th=th);t0=time.time();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached')
        if th=='dark':pass
        pg.wait_for_timeout(1300)
        r=ev(pg,"(()=>{const i=document.getElementById('intro'),l=document.getElementById('lock'),e=document.elementFromPoint(innerWidth/2,innerHeight/2),img=i.querySelector('img'),r=i.getBoundingClientRect();return{cobre:r.width>=innerWidth&&r.height>=innerHeight,z:+getComputedStyle(i).zIndex,topo:!!e&&i.contains(e),img:img.naturalWidth>=512,nome:i.querySelector('.in').textContent,slogan:i.querySelector('.is').textContent,aria:i.getAttribute('aria-hidden'),imgw:img.getBoundingClientRect().width}})()")
        ok(f'Intro ({th}): cobre a tela, fica na frente de tudo, mostra a logo nova, "WOLFIN" e o slogan',r['cobre'] and r['z']>=300 and r['topo'] and r['img'] and r['nome']=='WOLFIN' and r['slogan']=='Domine seu dinheiro.' and r['aria']=='true' and 120<=r['imgw']<=210,r)
        pg.wait_for_function("!document.getElementById('intro')",timeout=6000);dur=time.time()-t0
        ok(f'Intro ({th}): termina sozinha em poucos segundos (2 a 4,5 s) e some do código da página',2.0<=dur<=4.5 and not ev(pg,"!!document.getElementById('intsnd')"),round(dur,2))
        ok(f'Intro ({th}): depois dela a tela de boas-vindas está pronta e sem erros',ev(pg,"!!document.querySelector('#lock [data-lk=enter], #mf')")  and not pg.errs,pg.errs[:2]);c.close()
    # ---- contraste do texto (final da animação) ----
    for th in ('light','dark'):
        c,pg=ctx(th=th);pg.add_init_script("try{localStorage.setItem('x','1')}catch(e){}")
        pg.goto(HTTP_URL);pg.evaluate("S&&S.pref&&0");pg.evaluate("document.documentElement.setAttribute('data-theme','%s')"%th);pg.wait_for_timeout(1700)
        cc=ev(pg,"""(()=>{const rgb=s=>s.match(/[\\d.]+/g).slice(0,3).map(Number),L=c=>{c=c.map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]};
          const bg=rgb(getComputedStyle(document.getElementById('intro')).backgroundColor),r=(a,b)=>{const x=L(a),y=L(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
          return{nome:r(rgb(getComputedStyle(document.querySelector('#intro .in')).color),bg),slogan:r(rgb(getComputedStyle(document.querySelector('#intro .is')).color),bg)}})()""")
        ok(f'Intro ({th}): contraste do nome e do slogan ≥ 4,5:1',cc['nome']>=4.5 and cc['slogan']>=4.5,cc);c.close()
    # ---- pular e repetição ----
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(500);pg.touchscreen.tap(200,400);pg.wait_for_function("!document.getElementById('intro')",timeout=2000)
    ok('Tocar na tela pula a intro (some em menos de 1 s)',True)
    pg.reload();pg.wait_for_timeout(600);ok('Recarregar na mesma sessão NÃO repete a intro',not ev(pg,"!!document.getElementById('intro')"));c.close()
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.keyboard.press('Tab');pg.wait_for_timeout(300)
    ok('A tecla Tab não pula a intro (só toque ou outras teclas)',ev(pg,"!!document.getElementById('intro')"))
    c.close();c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(300);pg.keyboard.press('Escape');pg.wait_for_function("!document.getElementById('intro')",timeout=2000);ok('Outra tecla (ex.: Esc) pula a intro',True);c.close()
    c,pg=ctx();c.add_init_script("window.__WS_NOTOUR=1");pg.goto(HTTP_URL);pg.wait_for_timeout(300);ok('No modo de testes (gancho) a intro não aparece',not ev(pg,"!!document.getElementById('intro')"));c.close()
    # ---- movimento reduzido: curta, sem som, sem botão ----
    c,pg=ctx(reduce=True,stub=STUB%'running');t0=time.time();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');
    ok('Movimento reduzido: sem botão de som e sem áudio',ev(pg,"document.getElementById('intsnd').hidden")  and ev(pg,"window.__au.started")==0)
    pg.wait_for_function("!document.getElementById('intro')",timeout=3000);ok('Movimento reduzido: intro bem curta (< 1,5 s)',time.time()-t0<1.5,round(time.time()-t0,2));c.close()
    # ---- som: navegador permite (AudioContext "running") ----
    c,pg=ctx(stub=STUB%'running');pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(500)
    au=ev(pg,"({n:window.__au.started,stop:window.__au.maxStop,on:document.getElementById('intsnd').classList.contains('on'),vis:!document.getElementById('intsnd').hidden,pr:document.getElementById('intsnd').getAttribute('aria-pressed')})")
    ok('Som: com permissão do navegador toca um acorde curto (5 notas, termina em menos de 2,6 s)',au['n']==5 and au['stop']<2.6,au)
    ok('Som: botão de som visível e marcado como ligado',au['vis'] and au['on'] and au['pr']=='true',au)
    pg.click('#intsnd');pg.wait_for_timeout(200)
    ok('Som: tocar no botão desliga o som (lembrado) e NÃO pula a intro',ev(pg,"!!document.getElementById('intro')") and ev(pg,"localStorage.getItem('wolfin.introsnd')")=='0' and ev(pg,"document.getElementById('intsnd').getAttribute('aria-pressed')")=='false')
    st=c.storage_state();c.close()
    c2=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True,storage_state=st);c2.add_init_script("window.__WS_NOCSP=1");c2.add_init_script(STUB%'running');pg=c2.new_page();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(400)
    ok('Som: na próxima abertura (nova sessão) a intro vem muda, como escolhido, e o botão permite religar',ev(pg,"window.__au.started")==0 and ev(pg,"!document.getElementById('intsnd').hidden"))
    pg.click('#intsnd');pg.wait_for_timeout(200);ok('Som: religar toca o acorde',ev(pg,"window.__au.started")==5 and ev(pg,"localStorage.getItem('wolfin.introsnd')")=='1');c2.close()
    # ---- som: navegador bloqueia (suspenso) → botão libera ----
    c,pg=ctx(stub=STUB%'suspended');pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(400)
    ok('Som bloqueado pelo navegador: a intro segue muda, sem erro, e o botão de som aparece desligado',ev(pg,"window.__au.started")==0 and ev(pg,"!document.getElementById('intsnd').hidden") and ev(pg,"document.getElementById('intsnd').getAttribute('aria-pressed')")=='false' and not pg.errs)
    pg.evaluate("window.__au.unlock=1");pg.click('#intsnd');pg.wait_for_timeout(300)
    ok('Som bloqueado: tocar no botão libera o áudio e toca o acorde',ev(pg,"window.__au.started")==5 and ev(pg,"window.__au.resumes")>=1);
    pg.wait_for_function("!document.getElementById('intro')",timeout=5000);pg.wait_for_timeout(2300)
    ok('Ao terminar, o áudio é encerrado (sem consumo em segundo plano)',ev(pg,"window.__au.closed")>=1);c.close()
    # ---- áudio real do Chromium (política de reprodução liberada) ----
    b2=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);c=b2.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True);c.add_init_script("window.__WS_NOCSP=1")
    c.add_init_script("(()=>{const A=window.AudioContext;window.__real={n:0,state:''};window.AudioContext=class extends A{constructor(){super();window.__real.n++;window.__real.ctx=this}}})()")
    pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(700)
    rs=ev(pg,"({n:window.__real.n,s:window.__real.ctx&&window.__real.ctx.state,on:document.getElementById('intsnd').classList.contains('on')})")
    ok('Áudio real (Chromium com reprodução liberada): o contexto de áudio fica ativo e o som é marcado como ligado',rs['n']==1 and rs['s']=='running' and rs['on'] and not pg.errs,rs);c.close();b2.close()
    # ---- CSP real (sem o gancho que a desliga) ----
    c,pg=ctx(csp=True,stub=STUB%'running');pg.goto(HTTP_URL);t0=time.time()
    while time.time()-t0<8 and not (ev(pg,"document.readyState")=='complete' and not ev(pg,"!!document.getElementById('intro')") and ev(pg,"window.__au.started")>0):time.sleep(.3)
    ok('Sob a política de conteúdo (CSP) real: a intro e o som funcionam sem nenhuma violação',ev(pg,"window.__v.length")==0 and ev(pg,"window.__au.started")==5 and not pg.errs,(ev(pg,"window.__v"),pg.errs[:1]));c.close()
    # ---- telas: celular pequeno, tablet, paisagem ----
    for w,h in ((360,640),(393,851),(768,1024),(844,390)):
        c,pg=ctx(w=w,h=h);pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached');pg.wait_for_timeout(1300)
        m=ev(pg,"(()=>{const r=e=>document.querySelector(e).getBoundingClientRect(),i=r('#intro .ib'),n=r('#intro .in'),s=r('#intro .is'),b=r('#intsnd');return{ib:[i.left,i.top,i.right,i.bottom].map(Math.round),inside:i.left>=0&&i.right<=innerWidth&&i.top>=0&&s.bottom<=innerHeight&&n.top>=i.bottom-1,btn:b.width,ovx:document.documentElement.scrollWidth>innerWidth,cx:Math.abs((i.left+i.right)/2-innerWidth/2)<2}})()")
        ok(f'Intro {w}x{h}: logo e texto centralizados e dentro da tela, botão de som ≥ 44 px, sem rolagem lateral',m['inside'] and m['cx'] and m['btn']>=44 and not m['ovx'],m);c.close()
    # ---- paleta: a intro usa as cores do tema escolhido (e não fixa cor própria) ----
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('#intro',state='attached')
    a=ev(pg,"getComputedStyle(document.getElementById('intro')).backgroundColor");pg.evaluate("document.documentElement.setAttribute('data-theme','dark')");pg.wait_for_timeout(100)
    d=ev(pg,"getComputedStyle(document.getElementById('intro')).backgroundColor");ok('A intro segue o tema: fundo diferente no claro e no escuro (usa as variáveis de cor do app)',a!=d,(a,d));c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
