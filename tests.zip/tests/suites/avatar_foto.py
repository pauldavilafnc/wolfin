"""v7.19: mascotes removidos de todo o site + avatar com foto própria no canto superior esquerdo da Home.
Só dados fictícios (imagens geradas aqui); Chromium simulado (sem celular real, sem câmera/galeria reais)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json,io,base64
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw
URL=HTTP_URL
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:260] if d else ''),flush=True)
SRC=open(ROOT+'/index.html',encoding='utf-8').read()
def mkimg(name,w,h,fmt='PNG'):
    im=Image.new('RGB',(w,h));d=ImageDraw.Draw(im)
    for x in range(w):d.line([(x,0),(x,h)],fill=(int(255*x/w),90,200-int(150*x/w)))
    d.ellipse([w*.3,h*.2,w*.7,h*.8],fill=(250,220,40));p=os.path.join(TMP,name);im.save(p,fmt);return p
IMG_L=mkimg('foto_paisagem.png',800,500);IMG_P=mkimg('foto_retrato.jpg',500,900,'JPEG');IMG_BIG=mkimg('foto_grande.png',4000,3000)
TXT=os.path.join(TMP,'x.txt');open(TXT,'w').write('nao e imagem');BAD=os.path.join(TMP,'quebrada.png');open(BAD,'wb').write(b'\x89PNG\r\n\x1a\nlixo')
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th='light',csp=False):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=False,color_scheme=th,timezone_id='America/Sao_Paulo')
        c.add_init_script("" if csp else "window.__WS_NOTOUR=1;window.__WS_NOCSP=1");pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None);return c,pg
    def conta(w=393,h=851,th='light',csp=False,pw=False):
        c,pg=ctx(w,h,th,csp);pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(300)
        if th=='dark':pg.evaluate("S.pref.theme='dark';applyPref()")
        if pw:
            OB_TO_SETUP(pg,'Paul');pg.wait_for_selector('#sf');pg.fill('#sf [name=p]','Senha-Forte-123');pg.fill('#sf [name=c]','Senha-Forte-123');pg.click('#sf button:not([type=button])');pg.wait_for_selector('#skcode',timeout=30000);pg.check('#skok');pg.click('#skdone')
        else:OB_NOSEC(pg,'Paul')
        pg.wait_for_function("document.getElementById('lock').hidden",timeout=30000)
        if csp:
            pg.wait_for_selector('#tour',timeout=8000);pg.click('#tour [data-tr=skip]')
        pg.wait_for_timeout(300);return c,pg
    # ===== A. mascotes removidos =====
    ok('A. Código: nenhuma imagem de mascote (MCB), roupas, níveis ou frases do Wolfin sobraram',not any(k in SRC for k in ('const MCB','mcUrl','loboHtml','lvSheet','LVQ','image/webp','Roupas do Wolfin','Meu mascote','Mendigo','Magnata','Conheça o Wolfin')))
    c,pg=ctx();pg.goto(URL);pg.wait_for_selector('#lock [data-lk=enter]');pg.wait_for_timeout(400)
    ok('A. Cadastro: sem a etapa de mascote; abre direto em "Escolha sua aparência" (Etapa 1 de 2)',pg.locator('#cf').count()==1 and 'etapa 1 de 2' in pg.inner_text('#lock').lower() and pg.locator('#mf').count()==0 and pg.locator('#lock .mc,#lock .wolf,#lock img').count()==0,pg.inner_text('#lock')[:80])
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('[data-lk=new]')
    ok('A. Boas-vindas (Etapa 2 de 2): sem mascote na tela',pg.locator('#lock .mc,#lock .wolf,#lock img').count()==0 and 'etapa 2 de 2' in pg.inner_text('#lock').lower() and 'mascote' not in pg.inner_text('#lock').lower())
    pg.click('[data-lk=new]');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]','Paul');pg.click('#nf button:not([type=button])');pg.wait_for_selector('#sf')
    ok('A. Tela de criar acesso: sem mascote',pg.locator('#lock .mc,#lock .wolf,#lock img').count()==0 and 'WOLFIN' in pg.inner_text('#lock'));c.close()
    c,pg=conta()
    txt={}
    for v in ('home','rec','des','div','cx','rel','cfg','conq','ntf','nt','cc'):
        pg.evaluate(f"go('{v}')");pg.wait_for_timeout(150);txt[v]=pg.evaluate(f"document.getElementById('s-{v}').innerText")
    bad=[v for v,t in txt.items() if re.search(r'mascote|roupa|Wolfin, o lobo|Nível \d',t,re.I)]
    ok('A. Nenhuma tela (Home, Receitas, Despesas, Dívidas, Caixinhas, Relatórios, Ajustes, Conquistas, Avisos, Anotações, Cartões) cita mascote/roupa/nível',not bad,bad)
    pg.evaluate("go('home')");pg.wait_for_timeout(150)
    ok('A. Home: nenhum elemento de mascote (.mc, .wolf, .mqbtn) e nenhuma imagem blob',pg.evaluate("document.querySelectorAll('.mc,.wolf,.mqbtn,.mcav,img[src^=blob]').length")==0)
    ok('A. Home: o balão de dicas continua, agora só com texto, e o atalho Conquistas funciona',pg.locator('#s-home .mqc .bub p').count()==1 and len(pg.inner_text('#s-home .mqc .bub p'))>5 and pg.locator('#s-home .hmore .cql').count()==1)
    pg.evaluate("go('cfg')");pg.wait_for_timeout(150)
    ok('A. Ajustes: o cartão virou "Conquistas" e o botão "Ver conquistas" abre as Conquistas',pg.evaluate("[...document.querySelectorAll('#s-cfg h3')].some(h=>h.textContent.trim()==='Conquistas')") and pg.evaluate("[...document.querySelectorAll('#s-cfg h3')].every(h=>h.textContent.trim()!=='Meu mascote')"))
    pg.evaluate("document.querySelector('#s-cfg [data-act=nav][data-id=conq]').click()");pg.wait_for_timeout(200);ok('A. "Ver conquistas" leva às Conquistas',pg.evaluate("view")=='conq')
    pg.evaluate("go('home')");pg.wait_for_timeout(150)
    # dados antigos (v7.18) continuam abrindo
    ok('A. Dados da v7.18 (pref.lv/lm/lp/mc) continuam compatíveis: abrem sem erro e o app ignora esses campos',pg.evaluate("(()=>{const o=JSON.parse(JSON.stringify(S));o.pref.lv=4;o.pref.lm='m';o.pref.lp=2;o.pref.mc='wolfin';const m=migrate(o);return !!m&&m.pref.theme!=null})()") and not pg.errs,pg.errs[:2])
    # ===== B. avatar =====
    g=pg.evaluate("(()=>{const a=document.getElementById('avh').getBoundingClientRect(),h=document.querySelector('#s-home .hello').getBoundingClientRect(),bl=document.querySelector('#s-home .bellw').getBoundingClientRect();return{l:a.left,t:a.top,w:a.width,h:a.height,gapH:h.left-a.right,bell:bl.left,txt:document.getElementById('avh').innerText.trim(),lbl:document.getElementById('avh').getAttribute('aria-label'),tag:document.getElementById('avh').tagName,img:!!document.querySelector('#avh img')}})()")
    ok('B. Avatar no canto superior esquerdo da Home, ≥ 44 px, sem encostar no nome, é um botão',g['l']<=24 and g['t']<=70 and g['w']>=44 and g['h']>=44 and g['gapH']>=4 and g['tag']=='BUTTON',g)
    ok('B. Sem foto: mostra a inicial do nome (P) e o rótulo "Abrir menu do perfil"',g['txt']=='P' and g['lbl']=='Abrir menu do perfil' and not g['img'],g)
    OPEN_PHOTO(pg)
    t=pg.inner_text('#ov')
    ok('B. Tocar no avatar abre "Sua foto" (diálogo) com "Escolher foto" e "Fechar", sem "Remover" enquanto não há foto',pg.get_attribute('#ov .sheet','role')=='dialog' and 'Sua foto' in t and 'Escolher foto' in t and 'Fechar' in t and 'Remover' not in t,t[:120])
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(150);ok('B. Fechar volta para a Home sem mudar nada',pg.evaluate("document.getElementById('ov').hidden")==True and pg.evaluate("S.pref.ph")==None)
    # arquivo que não é imagem / imagem quebrada
    OPEN_PHOTO(pg)
    with pg.expect_file_chooser() as fc:pg.click('#ov [data-act=avpick]')
    fc.value.set_files(TXT);pg.wait_for_timeout(300)
    ok('B. Arquivo que não é imagem: aviso claro e nada muda',pg.evaluate("document.getElementById('toast').innerText").startswith('Escolha um arquivo de imagem') and pg.locator('#avcv').count()==0 and pg.evaluate("S.pref.ph")==None,pg.evaluate("document.getElementById('toast').innerText"))
    pg.set_input_files('#phf',BAD);pg.wait_for_timeout(500)
    ok('B. Imagem quebrada: aviso claro, sem erro no console e nada muda',('abrir essa imagem' in pg.evaluate("document.getElementById('toast').innerText")) and pg.locator('#avcv').count()==0 and pg.evaluate("S.pref.ph")==None and not pg.errs,(pg.evaluate("document.getElementById('toast').innerText"),pg.errs[:2]))
    # foto paisagem: recorte
    pg.set_input_files('#phf',IMG_L);pg.wait_for_selector('#avcv');pg.wait_for_timeout(200)
    ok('B. Escolher foto abre "Ajustar a foto" com prévia circular, zoom, Salvar e Cancelar',pg.get_attribute('#ov .sheet','aria-label')=='Ajustar a foto' and pg.locator('#avz').count()==1 and pg.locator('#ov [data-act=avsave]').count()==1 and pg.locator('#ov [data-act=close]').count()==1)
    h0=pg.evaluate("document.getElementById('avcv').toDataURL()")
    box=pg.locator('#avcv').bounding_box();cx,cy=box['x']+box['width']/2,box['y']+box['height']/2
    pg.mouse.move(cx,cy);pg.mouse.down();pg.mouse.move(cx-60,cy,steps=5);pg.mouse.up();pg.wait_for_timeout(100)
    h1=pg.evaluate("document.getElementById('avcv').toDataURL()")
    ok('B. Arrastar a prévia move a foto (foto paisagem tem folga na horizontal)',h1!=h0 and pg.evaluate("AVC.x")<0,pg.evaluate("AVC.x"))
    pg.mouse.move(cx,cy);pg.mouse.down();pg.mouse.move(cx-900,cy,steps=5);pg.mouse.up()
    ok('B. Não dá para arrastar além da borda (nunca aparece fundo branco): deslocamento limitado',pg.evaluate("(()=>{AVC.z=1;avGeo(240);const w=AVC.im.naturalWidth,h=AVC.im.naturalHeight,s=Math.max(240/w,240/h);return Math.abs(AVC.x)<=(w*s-240)/2/240+1e-9})()"))
    pg.evaluate("(()=>{const z=document.getElementById('avz');z.value=2.5;z.dispatchEvent(new Event('input',{bubbles:true}))})()")
    h2=pg.evaluate("document.getElementById('avcv').toDataURL()");ok('B. Zoom muda a prévia',h2!=h1 and pg.evaluate("AVC.z")==2.5)
    pg.focus('#avcv');pg.keyboard.press('ArrowDown');pg.keyboard.press('ArrowRight');pg.wait_for_timeout(80)
    ok('B. Teclado: setas movem a foto na prévia (acessível sem arrastar)',pg.evaluate("document.getElementById('avcv').toDataURL()")!=h2)
    pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(300)
    ph=pg.evaluate("S.pref.ph")
    dim=pg.evaluate("new Promise(r=>{const i=new Image();i.onload=()=>r([i.naturalWidth,i.naturalHeight]);i.src=S.pref.ph})")
    ok('B. Salvar: foto guardada como JPEG 256×256 (pequena, < 150 KB) em S.pref.ph',isinstance(ph,str) and ph.startswith('data:image/jpeg;base64,') and len(ph)<150000 and dim==[256,256],(len(ph or ''),dim))
    g=pg.evaluate("(()=>{const a=document.getElementById('avh'),i=a.querySelector('img'),r=a.getBoundingClientRect(),ir=i&&i.getBoundingClientRect();return{img:!!i,src:i&&i.src===S.pref.ph,fit:i&&getComputedStyle(i).objectFit,w:ir&&ir.width,lbl:a.getAttribute('aria-label'),ach:!!(S.ach&&S.ach.av),hid:document.getElementById('ov').hidden,r:r.width}})()")
    ok('B. Home mostra a foto no avatar (recortada em círculo), rótulo "Abrir menu do perfil", o diálogo fechou e a conquista "Cara própria" liberou',g['img'] and g['src'] and g['fit']=='cover' and g['lbl'].startswith('Abrir menu do perfil') and g['ach'] and g['hid'] and g['r']>=44,g)
    ok('B. Cantos do avatar: é circular (border-radius 50%) e a foto fica recortada',pg.evaluate("getComputedStyle(document.getElementById('avh')).borderRadius")in('50%','22px') and pg.evaluate("getComputedStyle(document.getElementById('avh')).overflow")=='hidden')
    # persistência
    pg.reload();pg.wait_for_selector('#s-home .hello');pg.wait_for_timeout(500)
    ok('B. A foto continua depois de recarregar o app',pg.evaluate("!!document.querySelector('#avh img')&&phOk(S.pref.ph)"))
    ok('B. A foto entra no registro principal e passa pelo "migrate" (usado na importação de backup)',pg.evaluate("(()=>{const o=migrate(JSON.parse(localStorage.getItem('wallstreet.v1')));return phOk(o.pref.ph)})()"))
    ok('B. Valor inválido ou gigante em pref.ph é descartado (backup adulterado não quebra nem injeta nada)',pg.evaluate("(()=>{const bad=['data:text/html;base64,AAAA','javascript:alert(1)','data:image/jpeg;base64,'+'A'.repeat(200000),123,'<img src=x onerror=alert(1)>','data:image/jpeg;base64,AAA\"onerror=\"x'];return bad.every(v=>{const o=JSON.parse(JSON.stringify(S));o.pref.ph=v;return !('ph' in migrate(o).pref)})})()"))
    # backup real
    ok('B. Exportar backup inclui a foto (pref.ph no arquivo)',pg.evaluate("JSON.stringify(S).includes('data:image/jpeg;base64,')"))
    # trocar / remover
    OPEN_PHOTO(pg);t=pg.inner_text('#ov')
    ok('B. Com foto: o diálogo mostra a foto, "Trocar foto" e "Remover foto"',pg.locator('#ov .avpv img').count()==1 and 'Trocar foto' in t and 'Remover foto' in t)
    pg.set_input_files('#phf',IMG_P);pg.wait_for_selector('#avcv');pg.click('#ov [data-act=close]');pg.wait_for_timeout(200)
    ok('B. Cancelar o ajuste mantém a foto anterior',pg.evaluate("S.pref.ph")==ph and pg.evaluate("AVC")==None)
    OPEN_PHOTO(pg);pg.set_input_files('#phf',IMG_P);pg.wait_for_selector('#avcv');pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(300)
    ph2=pg.evaluate("S.pref.ph");ok('B. Trocar por foto em retrato: salva outra foto 256×256',ph2!=ph and pg.evaluate("new Promise(r=>{const i=new Image();i.onload=()=>r(i.naturalWidth+'x'+i.naturalHeight);i.src=S.pref.ph})")=='256x256')
    OPEN_PHOTO(pg);pg.set_input_files('#phf',IMG_BIG);pg.wait_for_selector('#avcv',timeout=15000);pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(500)
    ok('B. Foto enorme (4000×3000) é aceita e reduzida: continua 256×256 e < 150 KB',pg.evaluate("S.pref.ph.length")<150000 and pg.evaluate("new Promise(r=>{const i=new Image();i.onload=()=>r(i.naturalWidth+'x'+i.naturalHeight);i.src=S.pref.ph})")=='256x256')
    OPEN_PHOTO(pg);pg.click('#ov [data-act=avrm]');pg.wait_for_timeout(300)
    g=pg.evaluate("({ph:S.pref.ph,img:!!document.querySelector('#avh img'),txt:document.getElementById('avh').innerText.trim(),ach:!!S.ach.av,lbl:document.getElementById('avh').getAttribute('aria-label')})")
    ok('B. Remover foto: volta para a inicial, o rótulo segue "Abrir menu do perfil"',g['ph'] is None and not g['img'] and g['txt']=='P' and g['lbl']=='Abrir menu do perfil',g)
    ok('B. Sem erros no console durante todo o fluxo',not pg.errs,pg.errs[:3]);c.close()
    # ===== C. zerar todos os dados mantém o app coerente =====
    c,pg=conta();pg.set_input_files('#phf',IMG_L) if False else None
    OPEN_PHOTO(pg);pg.set_input_files('#phf',IMG_L);pg.wait_for_selector('#avcv');pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(300)
    ok('C. Com a foto salva, a Home não tem rolagem lateral e o nome do usuário continua visível',pg.evaluate("document.documentElement.scrollWidth<=document.documentElement.clientWidth+1")and 'Paul' in pg.inner_text('#s-home .hello'));c.close()
    # ===== D. telas e temas =====
    for w,h in ((393,851),(360,640),(320,568),(851,393),(1280,800)):
        for th in ('light','dark'):
            c,pg=conta(w,h,th)
            r1=pg.evaluate("(()=>{const a=document.getElementById('avh').getBoundingClientRect(),t=document.querySelector('#s-home .tb').getBoundingClientRect(),x=document.querySelector('#s-home .hello').getBoundingClientRect();const m=document.getElementById('s-home').getBoundingClientRect();return a.left<=m.left+30&&a.top<110&&a.right<=x.left+1&&x.right<=t.left+1&&document.documentElement.scrollWidth<=document.documentElement.clientWidth+1})()")
            OPEN_PHOTO(pg);pg.wait_for_timeout(500)
            r2=pg.evaluate("(()=>{const bs=[...document.querySelectorAll('#ov .btns button')].map(x=>x.getBoundingClientRect());return bs.every(r=>r.top>=0&&r.bottom<=innerHeight&&r.height>=44&&r.left>=0&&r.right<=innerWidth)})()")
            pg.set_input_files('#phf',IMG_L);pg.wait_for_selector('#avcv');pg.wait_for_timeout(500)
            r3=pg.evaluate("(()=>{const bs=[...document.querySelectorAll('#ov .btns button,#avz,#avcv')].map(x=>x.getBoundingClientRect());const sh=document.querySelector('#ov .sheet');return bs.every(r=>r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth)||sh.scrollHeight>sh.clientHeight})()")
            pg.evaluate("document.querySelector('#ov .sheet').scrollTo(0,9999)");r4=pg.evaluate("[...document.querySelectorAll('#ov .btns button')].every(x=>{const r=x.getBoundingClientRect();return r.bottom<=innerHeight&&r.top>=0&&r.height>=44})")
            ok(f'D. {w}x{h} [{th}]: avatar no canto, sem encostar no nome/sino; diálogo e ajuste com botões ≥ 44 px alcançáveis; sem rolagem lateral',r1 and r2 and r3 and r4 and not pg.errs,(r1,r2,r3,r4,pg.errs[:2]));c.close()
    # ===== E. contraste da inicial (9 cores x 2 temas) =====
    c,pg=conta()
    PROBE="""v=>{const e=document.createElement('div');document.body.appendChild(e);e.style.color=v;const cc=getComputedStyle(e).color;e.remove();const k=document.createElement('canvas').getContext('2d');k.fillStyle='#000';k.fillStyle=cc;k.fillRect(0,0,1,1);return [...k.getImageData(0,0,1,1).data].slice(0,3)}"""
    lum=lambda c:sum(w*((x/255)/12.92 if x/255<=.03928 else (((x/255)+.055)/1.055)**2.4) for w,x in zip((.2126,.7152,.0722),c))
    cr=lambda a,b:(max(lum(a),lum(b))+.05)/(min(lum(a),lum(b))+.05)
    worst=99;wn=''
    pals=pg.evaluate("PALS.map(x=>x[0])")
    for th in ('light','dark'):
        for pl in pals:
            pg.evaluate(f"S.pref.theme='{th}';S.pref.pal='{pl}';applyPref();render()");pg.wait_for_timeout(60)
            for v in ('var(--av1)','var(--av2)'):
                x=cr((255,255,255),pg.evaluate(PROBE,v))
                if x<worst:worst=x;wn=(th,pl,v)
    ok(f'E. Inicial branca sobre o fundo do avatar: pior contraste {worst:.2f}:1 {wn} (texto grande, mínimo 3:1)',worst>=3.0,wn);c.close()
    # ===== F. CSP ligada: salvar foto não gera violação =====
    c,pg=conta(csp=True)
    ok('F. Com a política de segurança (CSP) ativa, a página tem a meta CSP e img-src permite data:',pg.evaluate("[...document.querySelectorAll('meta[http-equiv=Content-Security-Policy]')].some(m=>m.content.includes('img-src')&&m.content.includes('data:'))"))
    OPEN_PHOTO(pg);pg.set_input_files('#phf',IMG_L);pg.wait_for_selector('#avcv');pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(400)
    ok('F. Com CSP ativa: a foto aparece e não há nenhum erro/violação no console',pg.evaluate("!!document.querySelector('#avh img')&&document.querySelector('#avh img').naturalWidth===256") and not pg.errs,pg.errs[:3])
    reqs=[];pg.on('request',lambda r:reqs.append(r.url))
    OPEN_PHOTO(pg);pg.click('#ov [data-act=close]')
    ok('F. Nenhuma requisição de rede para fora do app ao usar a foto',all(u.startswith(('http://127.0.0.1','data:','blob:')) for u in reqs),reqs[:3]);c.close()
    # ===== G. modo protegido: com o app bloqueado, a foto não fica na tela =====
    c,pg=conta(pw=True)
    OPEN_PHOTO(pg);pg.set_input_files('#phf',IMG_L);pg.wait_for_selector('#avcv');pg.click('#ov [data-act=avsave]');pg.wait_for_timeout(500)
    ok('G. Conta com senha: a foto é salva e aparece na Home',pg.evaluate("!!document.querySelector('#avh img')&&phOk(S.pref.ph)"))
    pg.evaluate("lockNow()");pg.wait_for_timeout(800)
    ok('G. Depois de bloquear: tela de login visível e a foto NÃO está em nenhum lugar da página (nem no DOM, nem no armazenamento em texto puro)',pg.evaluate("!document.getElementById('lock').hidden")and pg.evaluate("!document.documentElement.innerHTML.includes('data:image/jpeg')") and pg.evaluate("!Object.keys(localStorage).some(k=>localStorage.getItem(k).includes('data:image/jpeg'))"),pg.evaluate("[document.getElementById('lock').hidden,document.documentElement.innerHTML.includes('data:image/jpeg'),Object.keys(localStorage).filter(k=>localStorage.getItem(k).includes('data:image/jpeg'))]"));c.close()
    b.close()
print(f'{sum(R)} / {len(R)}')
