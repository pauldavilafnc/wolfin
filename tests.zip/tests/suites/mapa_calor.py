"""v7.9: mapa de calor de gastos por dia (Relatórios + por categoria). Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import calendar,json
from playwright.sync_api import sync_playwright
URL=HTTP_URL;R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    def conta(w=393,h=851,th='light',nome='Ana',**k):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th,**k)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
        pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        pg.goto(URL);OB_NOSEC(pg,nome);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_selector('#cfab');pg.wait_for_timeout(500)
        pg.evaluate(f"S.pref.theme='{th}';applyPref()");return c,pg
    # helpers JS
    HELP="""window.X=(id,m,d,c,day,cat,done=true)=>S.items.push(Object.assign({id,t:'exp',d,c,day,ym:m,cat},done?{done:{[m]:c}}:{}));0"""
    def setup(pg):pg.evaluate(HELP)
    def goto(pg,m):
        pg.evaluate(f"(()=>{{HMS.main.m='{m}';HMS.main.sel=0;go('rel')}})()")
        try:pg.wait_for_selector('.hmw[data-hm=main] .hmc',timeout=8000)
        except Exception:print('DBG',m,pg.errs[:2],pg.evaluate("[view,document.body.innerText.slice(0,100)]"),flush=True);raise
        pg.wait_for_timeout(150)
    lv=lambda pg:pg.evaluate("[...document.querySelectorAll('.hmw[data-hm=main] .hmc')].map(e=>+(e.className.match(/hm(\\d)/)||[0,0])[1])")
    # ===== A. 28/29/30/31 dias e dia da semana =====
    c,pg=conta();setup(pg)
    for m in ('2027-02','2028-02','2026-11','2026-12','2026-10','2027-01'):
        goto(pg,m);y,mo=map(int,m.split('-'));dim=calendar.monthrange(y,mo)[1];off=(calendar.monthrange(y,mo)[0]+1)%7
        r=pg.evaluate("[document.querySelectorAll('.hmw[data-hm=main] .hmc').length,document.querySelectorAll('.hmw[data-hm=main] .hmx').length,document.querySelector('.hmw[data-hm=main] .hmc b').textContent,[...document.querySelectorAll('.hmw[data-hm=main] .hmc b')].pop().textContent]")
        ok(f'A. {m}: {dim} dias, começa na coluna {off} (dia da semana certo)',r==[dim,off,'1',str(dim)],r)
    ok('A. Anos bissexto e comum: fev/2028 tem 29 dias; fev/2027 tem 28 (conferido acima)',True)
    r=pg.evaluate("[...document.querySelectorAll('.hmd')].map(x=>x.textContent).join('')");ok('A. Cabeçalho da semana D S T Q Q S S',r=='DSTQQSS',r)
    ok('A. Título da seção "Mapa de calor — Gastos por dia" em Relatórios',pg.locator('.hmcard h3').inner_text()=='Mapa de calor — Gastos por dia')
    # ===== B. navegação =====
    pg.evaluate("window.X('b1','2026-10','Out','x',1,'Lazer')") if False else None
    pg.evaluate("(()=>{X('o1','2026-10','Mercado Out',10000,3,'Alimentação');X('n1','2026-11','Mercado Nov',20000,4,'Alimentação');X('d1','2026-12','Presente Dez',30000,24,'Lazer');save()})()")
    goto(pg,'2026-11');tt=lambda:pg.inner_text('.hmw[data-hm=main] .sw b')
    ok('B. Mostra mês e ano selecionados',tt()=='Novembro de 2026',tt())
    pg.click('.hmw[data-hm=main] [data-act=hmn]');pg.wait_for_timeout(200)
    ok('B. Seta ›: Dezembro de 2026, 31 dias, valor do dia 24 atualizado',tt()=='Dezembro de 2026' and pg.locator('.hmw[data-hm=main] .hmc').count()==31 and pg.inner_text('.hmw[data-hm=main] [data-d="24"] span')=='300',tt())
    ok('B. O foco continua na seta depois de navegar (acessibilidade)',pg.evaluate("document.activeElement.dataset.act")=='hmn')
    pg.click('.hmw[data-hm=main] [data-act=hmn]');pg.wait_for_timeout(200);ok('B. Dezembro → Janeiro de 2027 (virada de ano)',tt()=='Janeiro de 2027' and pg.locator('.hmw[data-hm=main] .hmc').count()==31)
    pg.click('.hmw[data-hm=main] [data-act=hmp]');pg.click('.hmw[data-hm=main] [data-act=hmp]');pg.click('.hmw[data-hm=main] [data-act=hmp]');pg.wait_for_timeout(200)
    ok('B. Seta ‹ volta mês a mês (Outubro de 2026) e recalcula (total, dia com gasto)',tt()=='Outubro de 2026' and pg.inner_text('.hmw[data-hm=main] [data-d="3"] span')=='100' and 'R$ 100,00' in pg.inner_text('.hmw[data-hm=main] .hmk'))
    pg.click('.hmw[data-hm=main] [data-d="3"]');pg.click('.hmw[data-hm=main] [data-act=hmn]');pg.wait_for_timeout(200)
    ok('B. Trocar de mês limpa o dia selecionado',pg.locator('.hmw[data-hm=main] .hmc.sel').count()==0 and 'Toque em um dia' in pg.inner_text('.hmw[data-hm=main]'))
    ok('B. Animação suave ao trocar de mês (e desligada com "reduzir movimento")',pg.evaluate("getComputedStyle(document.querySelector('.hmg.fade')).animationName")=='hmin')
    c.close()
    c,pg=conta();setup(pg);pg.evaluate("go('rel')");pg.wait_for_selector('.hmc');pg.emulate_media(reduced_motion='reduce');pg.wait_for_timeout(300);ok('B. Com reduzir movimento a animação fica desligada',pg.evaluate("getComputedStyle(document.querySelector('.hmg.fade')).animationName")=='none');c.close()
    # ===== C. seleção e detalhes =====
    c,pg=conta();setup(pg)
    pg.evaluate("(()=>{const m='2026-11';X('s1',m,'Mercado',18000,8,'Alimentação');X('s2',m,'Cinema',6000,8,'Lazer');X('s3',m,'Uber',3000,12,'Transporte');save()})()");goto(pg,'2026-11')
    pg.click('.hmw[data-hm=main] [data-d="8"]');pg.wait_for_timeout(250);dt=pg.inner_text('#hmdt-main')
    ok('C. Dia selecionado ganha destaque e aria-pressed',pg.locator('.hmc.sel').count()==1 and pg.get_attribute('.hmc.sel','aria-pressed')=='true' and pg.evaluate("getComputedStyle(document.querySelector('.hmc.sel')).outlineStyle")=='solid')
    ok('C. Detalhe: data completa por extenso (Domingo, 8 de novembro de 2026)','Domingo, 8 de novembro de 2026' in dt,dt)
    ok('C. Detalhe: total do dia, quantidade, descrição, categoria e valor de cada despesa','R$ 240,00' in dt and '2 movimentações' in dt and 'Mercado' in dt and 'Alimentação' in dt and 'Cinema' in dt and 'Lazer' in dt and 'R$ 180,00' in dt and 'R$ 60,00' in dt,dt)
    pg.click('.hmw[data-hm=main] [data-d="12"]');pg.wait_for_timeout(200);ok('C. Selecionar outro dia move o destaque (1 movimentação, no singular)',pg.locator('.hmc.sel').count()==1 and '1 movimentação' in pg.inner_text('#hmdt-main') and '2 movimentações' not in pg.inner_text('#hmdt-main'))
    pg.click('.hmw[data-hm=main] [data-d="20"]');pg.wait_for_timeout(200);ok('C. Dia sem gastos: mensagem simples "Nenhum gasto registrado neste dia."','Nenhum gasto registrado neste dia.' in pg.inner_text('#hmdt-main'))
    pg.click('.hmw[data-hm=main] [data-d="20"]');pg.wait_for_timeout(200);ok('C. Tocar de novo desmarca o dia',pg.locator('.hmc.sel').count()==0)
    pg.focus('.hmw[data-hm=main] [data-d="8"]');pg.keyboard.press('Enter');pg.wait_for_timeout(200);ok('C. Funciona pelo teclado (Enter) e mantém o foco no dia',pg.locator('.hmc.sel').count()==1 and pg.evaluate("document.activeElement.dataset.d")=='8')
    lab=pg.get_attribute('.hmw[data-hm=main] [data-d="8"]','aria-label');ok('C. Cada dia tem texto para leitor de tela (data, valor, movimentações)','8 de novembro' in lab and 'R$ 240,00' in lab and '2 movimentações' in lab,lab)
    # abrir movimentação existente
    pg.click('#hmdt-main .hmr >> nth=0');pg.wait_for_timeout(300)
    ok('C. Tocar numa despesa abre a edição existente (itemForm) com os dados dela',pg.locator('#ov .sheet h3').inner_text().startswith('Editar') and pg.input_value('#ov input[name=d]') in ('Mercado','Cinema'),pg.locator('#ov .sheet h3').inner_text())
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(200);c.close()
    # ===== D. intensidade =====
    c,pg=conta();setup(pg)
    def seed_vals(vals,m='2026-11',mult=1):
        pg.evaluate("S.items=S.items.filter(i=>!i.id.startsWith('v'))")
        pg.evaluate("(vals)=>{vals.forEach(([d,c],i)=>X('v'+i,'2026-11','D'+i,c,d,'Lazer'));save()}",[[d,c*mult] for d,c in vals]);goto(pg,m)
    seed_vals([(2,1000),(5,2000),(9,3000),(14,4000)])
    L=lv(pg);ok('D. 4 dias com gasto → faixas 1,2,3,4 (clara → muito alta); demais dias neutros',[L[1],L[4],L[8],L[13]]==[1,2,3,4] and sum(1 for x in L if x==0)==26,L)
    seed_vals([(2,1000),(5,2000),(9,3000),(14,4000)],mult=1000);L2=lv(pg);ok('D. A escala é relativa ao próprio mês (valores 1000× maiores dão as mesmas faixas)',L2==L)
    seed_vals([(2,100),(5,200),(9,300),(14,100000)]);L=lv(pg);ok('D. Um valor muito alto não achata os outros (faixas 1,2,3,4)',[L[1],L[4],L[8],L[13]]==[1,2,3,4],L)
    seed_vals([(7,5000)]);L=lv(pg);ok('D. Só um dia com gasto: faixa alta fixa (3), sem inventar comparação',L[6]==3 and sum(1 for x in L if x>0)==1,L)
    seed_vals([(2,500),(3,500),(4,500)]);L=lv(pg);ok('D. Valores iguais ficam na mesma faixa',L[1]==L[2]==L[3]>0,L)
    seed_vals([]);L=lv(pg);ok('D. Sem gastos: tudo neutro (faixa 0)',set(L)=={0})
    seed_vals([(d,100*d) for d in range(1,31)]);L=lv(pg);ok('D. 30 dias distintos: faixas distribuídas igualmente 1–4 (sem limites arbitrários)',all(L.count(k)>=6 for k in (1,2,3,4)) and L==sorted(L),[L.count(k) for k in range(5)])
    leg=pg.evaluate("[...document.querySelectorAll('.hml i')].map(e=>e.className)");ok('D. Legenda visual menor → maior (sem gastos, 4 faixas) com "Menos" e "Mais"',leg==['hm0','hm1','hm2','hm3','hm4'] and 'Menos' in pg.inner_text('.hml') and 'Mais' in pg.inner_text('.hml'),leg)
    c.close()
    # ===== E. regras financeiras =====
    c,pg=conta();setup(pg)
    pg.evaluate("""(()=>{const m='2026-11';
X('r1',m,'Pago',10000,5,'Alimentação');X('r2',m,'Pendente',50000,5,'Alimentação',false);X('r3',m,'Zero',0,6,'Lazer');
S.items.push({id:'r4',t:'inc',d:'Salário',c:300000,day:5,ym:m,cat:'Salário',done:{[m]:300000}});
X('r5',m,'Dia 31 em mês de 30',7000,31,'Lazer');
S.debts.push({id:'db',n:'Dívida',o:100000,due:'',pays:[{id:'pp',c:40000,d:m+'-05'}]});S.boxes.push({id:'bx',n:'Caixa',g:100000,m:0,dl:'',ic:0,moves:[{id:'mv',c:30000,d:m+'-05'}]});
S.cards=[{id:'cc1',n:'Cartão',lim:500000,cl:25,dd:5,buys:[{id:'b1',d:'Compra à vista',c:20000,dt:m+'-10',np:1,cat:'Alimentação'},{id:'b2',d:'TV parcelada',c:30000,dt:m+'-12',np:3,cat:'Casa'}],pays:[{id:'cp',c:20000,d:m+'-28',ym:m}]}];
S.inst=[{id:'in1',n:'Celular',c:90000,np:3}];S.parc=[{id:'q1',iid:'in1',ym:m,c:30000,paid:true,paidOn:m+'-20'},{id:'q2',iid:'in1',ym:'2026-12',c:30000,paid:false}];save()})()""");goto(pg,'2026-11')
    byd=lambda d:pg.inner_text(f'.hmw[data-hm=main] [data-d="{d}"] span')
    ok('E. Despesa paga entra no dia dela; pendente, valor zero e receita NÃO entram (dia 5 = R$ 100)',byd(5)=='100',byd(5))
    ok('E. Dívidas pagas e caixinhas não contam como gasto do dia (dia 5 continua 100)',byd(5)=='100')
    ok('E. Dia 31 em mês de 30 dias vai para o dia 30 (não some, não inventa dia)',byd(30)=='70')
    ok('E. Compra no cartão conta na data da compra (dia 10 = 200); parcelada: 1ª parcela no dia 12 (100)',byd(10)=='200' and byd(12)=='100',[byd(10),byd(12)])
    ok('E. Pagamento da fatura não é contado de novo (dia 28 vazio)',byd(28)=='')
    ok('E. Parcelamento pago entra no dia do pagamento (dia 20 = 300)',byd(20)=='300',byd(20))
    tot=pg.evaluate("hmCalc('2026-11',null).tot");ok('E. Total do mês = 100 + 70 + 200 + 100 + 300 = R$ 770,00',tot==77000,tot)
    cs=pg.evaluate("(()=>{const o=catSpend('2026-11');return Object.values(o).reduce((a,r)=>a+r.paid,0)})()");ok('E. Bate com o "Pago no mês" de Gastos por categoria (itens pagos + cartão): 470',cs==47000 and pg.evaluate("hmCalc('2026-11',null).tot-30000")==cs,cs)
    goto(pg,'2026-12');ok('E. Parcela da TV (2/3) cai no mês seguinte, na data da compra (dia 12 de dezembro = R$ 100)',byd(12)=='100',byd(12))
    ok('E. Parcela de dezembro não paga (Celular) não entra',pg.evaluate("hmCalc('2026-12',null).tot")==10000)
    goto(pg,'2026-11');d0=json.dumps(pg.evaluate("JSON.stringify(S)"))
    pg.click('.hmw[data-hm=main] [data-d="5"]');pg.click('.hmw[data-hm=main] [data-act=hmn]');pg.click('.hmw[data-hm=main] [data-act=hmp]')
    ok('E. Usar o mapa não altera nenhum dado do usuário',json.dumps(pg.evaluate("JSON.stringify(S)"))==d0)
    ok('E. Estornos/cancelamentos: o Wolfin não tem esse recurso; despesas só contam quando pagas, e valores ≤ 0 são ignorados (testado acima)',True)
    c.close()
    # ===== F. por categoria =====
    c,pg=conta();setup(pg)
    pg.evaluate("""(()=>{const m=ymOf(new Date()),p=shift(m,-1);X('c1',m,'Mercado',18000,2,'Alimentação');X('c2',m,'Padaria',2500,2,'Alimentação');X('c3',m,'Uber',3200,5,'Transporte');X('c4',m,'Sem cat',1000,6,'');X('c5',p,'Mercado ant',20000,3,'Alimentação');save()})()""")
    pg.evaluate("go('rel')");pg.wait_for_selector('[data-act=catlim]')
    pg.click('[data-act=catlim][data-id="Alimentação"]');pg.wait_for_selector('#ov .hmw[data-hm=cat]');pg.wait_for_timeout(250)
    r=pg.evaluate("[document.querySelector('#ov .sheet h3').textContent,[...document.querySelectorAll('#ov .hmc')].filter(e=>e.querySelector('span').textContent).map(e=>e.dataset.d),document.querySelector('#ov .sheet').getAttribute('role')]")
    ok('F. Abrir uma categoria mostra o mapa só dos gastos dela (Alimentação: só o dia 2; Uber/Sem categoria ficam de fora)',r[0]=='Alimentação' and r[1]==['2'] and r[2]=='dialog',r)
    pg.click('#ov .hmw[data-hm=cat] [data-d="2"]');pg.wait_for_timeout(200);ok('F. Seleção de dia e detalhes funcionam na categoria (2 movimentações, R$ 205,00)','R$ 205,00' in pg.inner_text('#hmdt-cat') and '2 movimentações' in pg.inner_text('#hmdt-cat') and 'Uber' not in pg.inner_text('#ov .sheet'))
    pg.click('#ov .hmw[data-hm=cat] [data-act=hmp]');pg.wait_for_timeout(200);ok('F. Navegação de mês na categoria (mês anterior: Mercado ant, R$ 200,00)','R$ 200,00' in pg.inner_text('#ov .hmk') and pg.locator('#ov .hmc.sel').count()==0)
    pg.click('#ov .hmw[data-hm=cat] [data-act=hmn]');ok('F. O mapa geral de Relatórios continua independente (mês e filtro)',pg.evaluate("HMS.main.cat")is None and pg.evaluate("HMS.cat.cat")=='Alimentação')
    pg.click('#ov [data-act=hmlim]');pg.wait_for_timeout(250);ok('F. "Definir limite" abre o formulário de limite de sempre',pg.locator('#ov .sheet h3').inner_text()=='Limite mensal · Alimentação' and pg.locator('#ov input[name=c]').count()==1)
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(150)
    pg.click('[data-act=catlim][data-id="Sem categoria"]');pg.wait_for_selector('#ov .hmw[data-hm=cat]');ok('F. "Sem categoria" também tem mapa (dia 6)',pg.inner_text('#ov [data-d="6"] span')=='10')
    pg.click('#ov [data-act=close]');pg.wait_for_timeout(150);ok('F. Fechar volta aos Relatórios',pg.locator('#ov .sheet').count()==0 and pg.evaluate("view")=='rel')
    pg.evaluate("S.limits={'Lazer':5000};save();render()");pg.click('[data-act=catlim][data-id="Lazer"]');pg.wait_for_selector('#ov .hmw');ok('F. Categoria com limite e sem gastos: mapa vazio com mensagem','Nenhum gasto registrado neste mês nesta categoria' in pg.inner_text('#ov .hmw'))
    pg.click('#ov [data-act=close]');c.close()
    # ===== G. indicadores =====
    c,pg=conta();setup(pg)
    pg.evaluate("""(()=>{const m='2026-10';// outubro/2026: dia 1 = quinta. 31 dias; todos passados
for(let d=1;d<=31;d++){const w=new Date(2026,9,d).getDay();X('g'+d,m,'G'+d,(w===0||w===6)?20000:10000,d,'Lazer')}
X('gx','2026-09','Set',31000,10,'Lazer');save()})()""");goto(pg,'2026-10');txt=pg.inner_text('.hmw[data-hm=main] .hmk')
    wd=[d for d in range(1,32) if calendar.weekday(2026,10,d)<5];we=31-len(wd);total=len(wd)*10000+we*20000
    br=lambda c:'R$ '+f'{c/100:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
    ok('G. Total gasto no mês',br(total) in txt,(txt,br(total)))
    ok('G. Média diária (mês passado: total ÷ dias do mês)',br(round(total/31)) in txt,br(round(total/31)))
    ok('G. Maior dia do mês (primeiro dia de maior valor)',f'{[d for d in range(1,32) if calendar.weekday(2026,10,d)>=5][0]} de outubro' in txt,txt)
    ok('G. Comparação com mês anterior (Set: R$ 310,00 → +X%)',f'+{round((total-31000)/31000*100)}%' in txt and 'setembro' in txt,txt)
    ok('G. Observação automática calculada dos registros (fim de semana 100% maior por dia)','100% maiores' in pg.inner_text('.hmi'),pg.inner_text('.hmi') if pg.locator('.hmi').count() else 'sem')
    goto(pg,'2026-09');ok('G. Sem mês anterior com dados: "dados insuficientes" e nenhuma observação inventada','dados insuficientes' in pg.inner_text('.hmk') and pg.locator('.hmi').count()==0)
    pg.evaluate("(()=>{S.items=S.items.filter(i=>!i.id.startsWith('g'));[3,4,5].forEach(d=>X('h'+d,'2026-10','H',10000,d,'Lazer'));save()})()");goto(pg,'2026-10');ok('G. Poucos dias com gasto (3): sem observação de fim de semana',pg.locator('.hmi').count()==0)
    pg.evaluate("(()=>{S.items=S.items.filter(i=>!i.id.startsWith('h'));for(let d=1;d<=31;d++)X('k'+d,'2026-10','K',10000+(d%7===0?500:0),d,'Lazer');save()})()");goto(pg,'2026-10');ok('G. Fim de semana ≈ dias úteis (diferença < 10%): sem observação',pg.locator('.hmi').count()==0)
    c.close()
    # mês corrente: média até hoje e comparação do mesmo período
    c,pg=conta();setup(pg)
    pg.evaluate("""(()=>{const m=ymOf(new Date()),pr=shift(m,-1),hj=new Date().getDate();X('t1',m,'A',30000,1,'Lazer');X('t2',pr,'P1',10000,1,'Lazer');X('t3',pr,'P2',90000,Math.min(28,Math.max(hj+1,2)),'Lazer');save()})()""")
    pg.evaluate("go('rel')");pg.wait_for_selector('.hmw[data-hm=main] .hmk');hj=pg.evaluate("new Date().getDate()");k=pg.inner_text('.hmw[data-hm=main] .hmk')
    ok(f'G. Mês corrente: média = total ÷ dias já passados ({hj})',br(round(30000/hj)) in k,k)
    ok('G. Mês corrente compara com o MESMO PERÍODO do mês anterior (não com o mês inteiro): +200%' if hj<28 else 'G. (hoje ≥ 28: comparação equivale ao mês inteiro)',('+200%' in k and 'mesmo período' in k) if hj<28 else True,k)
    c.close()
    # ===== H. abrir cartão =====
    c,pg=conta();setup(pg)
    pg.evaluate("""(()=>{const m=ymOf(new Date());S.cards=[{id:'cc1',n:'Cartão Teste',lim:500000,cl:25,dd:5,buys:[{id:'b1',d:'Compra cartão',c:20000,dt:m+'-02',np:1,cat:'Lazer'}],pays:[]}];save()})()""")
    pg.evaluate("go('rel')");pg.click('.hmw[data-hm=main] [data-d="2"]');pg.wait_for_timeout(200)
    ok('H. Compra no cartão aparece no detalhe com "cartão" e abre a tela do cartão','cartão' in pg.inner_text('#hmdt-main'))
    pg.click('#hmdt-main .hmr');pg.wait_for_timeout(350);ok('H. Tocar leva ao cartão correspondente (funcionalidade existente)',pg.evaluate("view")=='cc' and pg.evaluate("CCO")=='cc1' and 'Cartão Teste' in pg.inner_text('main'))
    c.close()
    # ===== I. temas, contraste, tamanhos =====
    def ratio(a,b):
        L=lambda c:(lambda f:.2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2]))(lambda v:(v/255/12.92) if v/255<=.03928 else ((v/255+.055)/1.055)**2.4)
        x,y=L(a),L(b);return (max(x,y)+.05)/(min(x,y)+.05)
    for th in ('light','dark'):
        c,pg=conta(th=th,nome='T'+th[0]);setup(pg)
        pg.evaluate("(()=>{[[2,1000],[5,2000],[9,3000],[14,4000]].forEach(([d,c],i)=>X('z'+i,'2026-11','Z',c,d,'Lazer'));save()})()");goto(pg,'2026-11')
        cols=pg.evaluate("[2,5,9,14,20].map(d=>{const e=document.querySelector('.hmw[data-hm=main] [data-d=\"'+d+'\"]'),s=getComputedStyle(e),bg=s.backgroundColor.match(/[\\d.]+/g).map(Number),fg=s.color.match(/[\\d.]+/g).map(Number);return[bg,fg]})")
        # fundo translúcido do neutro: compara com o fundo da página aproximado (branco/azul-escuro)
        base=(235,240,250) if th=='light' else (14,22,45)
        rs=[]
        for bg,f in cols:
            a=bg[3] if len(bg)>3 else 1;mix=tuple(bg[i]*a+base[i]*(1-a) for i in range(3));rs.append(ratio(f[:3],mix))
        ok(f'I. Tema {th}: texto legível em todas as faixas (contraste mínimo {min(rs):.1f}:1 ≥ 4,5)',min(rs)>=4.5,[round(x,1) for x in rs])
        ok(f'I. Tema {th}: faixas visualmente diferentes entre si',len({tuple(x[0]) for x in cols})==5)
        c.close()
    for w,h,mn in ((393,851,44),(360,740,40),(412,915,44)):
        c,pg=conta(w,h);setup(pg);pg.evaluate("go('rel')");pg.wait_for_selector('.hmc');pg.locator('.hmcard').scroll_into_view_if_needed()
        r=pg.evaluate("(()=>{const cs=[...document.querySelectorAll('.hmw[data-hm=main] .hmc')].map(e=>e.getBoundingClientRect()),cd=document.querySelector('.hmcard').getBoundingClientRect();return{w:Math.min(...cs.map(x=>x.width)),h:Math.min(...cs.map(x=>x.height)),inside:cs.every(x=>x.left>=cd.left-1&&x.right<=cd.right+1),sx:document.documentElement.scrollWidth>innerWidth+1,rows:new Set(cs.map(x=>Math.round(x.top))).size}})()")
        ok(f'I. {w}x{h}: calendário inteiro dentro do cartão, sem rolagem lateral, quadrados ≥ {mn} px de largura e ≥ 44 px de altura',r['inside'] and not r['sx'] and r['w']>=mn and r['h']>=44 and r['rows']<=6,r);c.close()
    for w,h in ((320,568),(851,393)):
        c,pg=conta(w,h);setup(pg);pg.evaluate("go('rel')");pg.wait_for_selector('.hmc');pg.click('.hmw[data-hm=main] [data-d="3"]')
        r=pg.evaluate("(()=>{const cd=document.querySelector('.hmcard').getBoundingClientRect(),cs=[...document.querySelectorAll('.hmw[data-hm=main] .hmc')].map(e=>e.getBoundingClientRect());return{sx:document.documentElement.scrollWidth>innerWidth+1,inside:cs.every(x=>x.left>=cd.left-1&&x.right<=cd.right+1&&x.right<=innerWidth+1),w:Math.min(...cs.map(x=>x.width))}})()")
        ok(f'I. {w}x{h}: sem rolagem lateral e todos os dias visíveis (quadrado mínimo {r["w"]:.0f} px, ≥ 33 px)',not r['sx'] and r['inside'] and r['w']>=33,r);c.close()
    # ===== J. vazio, sem erros, armazenamento =====
    c,pg=conta();k0=pg.evaluate("Object.keys(localStorage).sort()");pg.evaluate("go('rel')");pg.wait_for_selector('.hmc')
    t=pg.inner_text('.hmcard');ok('J. Dados vazios: calendário neutro, mensagem simples e nenhum indicador inventado','Nenhum gasto registrado neste mês' in t and pg.locator('.hmk').count()==0 and set(lv(pg))=={0},t[-160:])
    for i in range(14):pg.click('.hmw[data-hm=main] [data-act=hmp]')
    ok('J. Navegar muitos meses para trás/frente não quebra (ano muda corretamente)',pg.inner_text('.hmw[data-hm=main] .sw b').endswith(str(int(pg.evaluate("new Date().getFullYear()"))-2 if pg.evaluate("new Date().getMonth()")<2 else int(pg.evaluate("new Date().getFullYear()"))-1)),pg.inner_text('.hmw[data-hm=main] .sw b'))
    k1=pg.evaluate("Object.keys(localStorage).sort()");ok('J. O mapa não cria nenhuma chave nova no armazenamento (calcula tudo na hora)',k1==k0,set(k1)^set(k0))
    ok('J. Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    b.close()
print(sum(R),'/',len(R))
