"""v7.16: intro em vídeo do lobo (720x1280, ~0,5 MB), som opcional, fade final suave, pular, falhas, CSP, offline, telas. Só dados fictícios; Chromium simulado
(o som real num celular depende da permissão do navegador; aqui verifica-se mudo/ligado, decodificação de áudio e o fade de volume)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json,time,struct
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html');sw=rd('sw.js')
mp4=os.path.join(ROOT,'intro-lobo.mp4');webm=os.path.join(ROOT,'intro-lobo.webm')
# ---------- arquivos ----------
ok('Os dois vídeos existem (mp4 para todos os aparelhos, webm de reserva)',os.path.exists(mp4) and os.path.exists(webm))
sm,sw_=os.path.getsize(mp4),os.path.getsize(webm)
ok(f'Leves: mp4 {sm//1024} KB e webm {sw_//1024} KB (o original tinha 3.428 KB → mais de 80% menor)',sm<600_000 and sw_<450_000)
with open(mp4,'rb') as f:head=f.read(200_000)
ok('mp4 pronto para começar a tocar antes de baixar tudo (faststart: "moov" antes de "mdat") e H.264/AAC',head[4:8]==b'ftyp' and head.find(b'moov')>0 and (head.find(b'mdat')<0 or head.find(b'moov')<head.find(b'mdat')) and b'avc1' in head and b'mp4a' in head)
with open(webm,'rb') as f:ok('webm válido (cabeçalho EBML)',f.read(4)==b'\x1aE\xdf\xa3')
ok('Código da intro leve (< 9 KB) e sem biblioteca externa',len(html[html.index('<style id="intro-css">'):html.index('</style>',html.index('<style id="intro-css">'))])+len(html[html.index('<script>/* intro em vídeo'):html.index('</script>',html.index('<script>/* intro em vídeo'))])<9000)
ok('Marcação: <video> mudo, playsinline, mp4 antes do webm; escondido para leitores de tela (aria-hidden)',bool(re.search(r'<div id="intro" aria-hidden="true"><video id="introv" muted playsinline preload="auto"[^>]*><source src="intro-lobo.mp4" type="video/mp4"><source src="intro-lobo.webm" type="video/webm">',html)))
ok('Service Worker: vídeo novo na lista offline + respostas de trechos (206); nomes antigos fora','intro-lobo.mp4' in sw and '206' in sw and 'intro-wolfin' not in sw)
STOP=lambda pg:0
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    def ctx(br=None,w=393,h=851,reduce=False,csp=False,pref=None,**k):
        c=(br or b).new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,reduced_motion='reduce' if reduce else 'no-preference',**k)
        if not csp:c.add_init_script("window.__WS_NOCSP=1")
        c.add_init_script("window.__v=[];addEventListener('securitypolicyviolation',e=>window.__v.push(e.violatedDirective))")
        if pref is not None:c.add_init_script("try{localStorage.setItem('wolfin.introsnd','%s')}catch(e){}"%pref)
        pg=c.new_page();pg.errs=[];pg.reqs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('request',lambda r:pg.reqs.append(r.url));return c,pg
    ev=lambda pg,x:pg.evaluate(x)
    ST="(()=>{const i=document.getElementById('intro'),v=document.getElementById('introv');if(!i)return null;return{cls:i.className,op:+getComputedStyle(i).opacity,ct:v.currentTime,vol:v.volume,muted:v.muted,paused:v.paused,sb:!!document.getElementById('intsnd')}})()"
    # ---------- reprodução e transição (linha do tempo) ----------
    c,pg=ctx();t0=time.time();pg.goto(HTTP_URL);pg.wait_for_selector('#introv',state='attached');pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000)
    info=ev(pg,"(()=>{const v=document.getElementById('introv'),r=document.getElementById('intro').getBoundingClientRect();return{w:v.videoWidth,h:v.videoHeight,d:v.duration,muted:v.muted,cobre:r.width>=innerWidth&&r.height>=innerHeight,z:+getComputedStyle(document.getElementById('intro')).zIndex,fit:getComputedStyle(v).objectFit,src:v.currentSrc.split('/').pop()}})()")
    ok('Vídeo toca sozinho, mudo, em tela cheia e na frente de tudo; resolução original 720x1280 mantida (sem perder qualidade) e ~3,9 s',info['w']==720 and info['h']==1280 and 3.7<info['d']<4.1 and info['muted'] and info['cobre'] and info['z']>=300 and info['src'].startswith('intro-lobo'),info)
    ok('No celular em pé o vídeo preenche a tela (cover)',info['fit']=='cover')
    sb=ev(pg,"(()=>{const s=document.getElementById('intsnd'),r=s.getBoundingClientRect();return{vis:!s.hidden,on:s.classList.contains('on'),pr:s.getAttribute('aria-pressed'),lab:s.getAttribute('aria-label'),w:r.width,h:r.height,inside:r.left>=0&&r.right<=innerWidth&&r.top>=0}})()")
    ok('Botão de som visível, desligado, com nome acessível e ≥ 44 px',sb['vis'] and not sb['on'] and sb['pr']=='false' and 'Ligar' in sb['lab'] and sb['w']>=44 and sb['h']>=44 and sb['inside'],sb)
    ser=[]
    while time.time()-t0<9:
        s=ev(pg,ST)
        if s is None:ser.append((round(time.time()-t0,2),None,None,None));break
        ser.append((round(time.time()-t0,2),s['op'],s['cls'],round(s['ct'],2)));time.sleep(.06)
    tend=ser[-1][0];tout=next((t for t,o,c_,ct in ser if c_ and 'out' in c_),None)
    ok(f'Intro termina sozinha (total {tend} s, entre 3,5 e 7 s) e some do código',ser[-1][1] is None and 3.5<=tend<=7,(tend,tout))
    fade=[o for t,o,c_,ct in ser if o is not None and c_ and 'out' in c_]
    ok('Transição suave: só começa nos últimos ~0,6 s do vídeo, fica 1 até lá e depois diminui sem salto brusco',all(o==1 for t,o,c_,ct in ser if o is not None and not (c_ and 'out' in c_)) and tout is not None and all(a>=b-1e-6 for a,b in zip(fade,fade[1:])) and max((a-b) for a,b in zip(fade,fade[1:]))<0.45,(tout,[round(x,2) for x in fade][:20]))
    ok('Transição suave: passa por vários níveis intermediários de transparência (não corta seco)',len([o for o in fade if 0.08<o<0.92])>=4,[round(x,2) for x in fade])
    ct_out=next(ct for t,o,c_,ct in ser if c_ and 'out' in c_);ok('O desvanecer começa quando faltam ~0,55 s do vídeo',3.1<=ct_out<=3.55,ct_out)
    ok('Depois da intro o app está pronto (tela de boas-vindas) e não há erros',ev(pg,"!!document.querySelector('#lock [data-lk=enter], #mf')") and not pg.errs,pg.errs[:2]);c.close()
    # ---------- som ----------
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000);pg.click('#intsnd');pg.wait_for_timeout(500)
    s=ev(pg,"(()=>{const v=document.getElementById('introv'),s=document.getElementById('intsnd');return{muted:v.muted,vol:v.volume,paused:v.paused,pr:s.getAttribute('aria-pressed'),lab:s.getAttribute('aria-label'),pref:localStorage.getItem('wolfin.introsnd'),aud:v.webkitAudioDecodedByteCount||0,intro:!!document.getElementById('intro')}})()")
    ok('Tocar no botão liga o som (sem pular nem reiniciar o vídeo), muda o rótulo para "Desligar" e lembra a escolha',not s['muted'] and s['vol']==1 and not s['paused'] and s['pr']=='true' and 'Desligar' in s['lab'] and s['pref']=='1' and s['intro'],s)
    ok('O áudio do vídeo é realmente decodificado depois de ligar o som',s['aud']>0,s['aud'])
    vols=[];t1=time.time()
    while time.time()-t1<5:
        x=ev(pg,ST)
        if x is None:break
        vols.append((round(x['ct'],2),round(x['vol'],2)));time.sleep(.05)
    tail=[v for ct,v in vols if ct>3.4];ok('Com som ligado o volume também desvanece no final (não corta seco)',len(tail)>=3 and tail[0]<1 and tail[-1]<tail[0] and all(a>=b-1e-6 for a,b in zip(tail,tail[1:])),tail[:12])
    pg.wait_for_timeout(300);c.close()
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000);pg.click('#intsnd');pg.wait_for_timeout(150);pg.click('#intsnd');pg.wait_for_timeout(150)
    s=ev(pg,"(()=>{const v=document.getElementById('introv');return{muted:v.muted,pref:localStorage.getItem('wolfin.introsnd'),pr:document.getElementById('intsnd').getAttribute('aria-pressed')}})()")
    ok('Tocar de novo desliga o som e lembra "desligado"',s['muted'] and s['pref']=='0' and s['pr']=='false',s);c.close()
    # preferência ligada + navegador permite → começa com som; navegador bloqueia → cai para mudo sem quebrar
    c,pg=ctx(pref='1');pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000)
    ok('Quem deixou o som ligado: a intro já começa com som quando o navegador permite',not ev(pg,"document.getElementById('introv').muted") and ev(pg,"document.getElementById('intsnd').getAttribute('aria-pressed')")=='true');c.close()
    b2=p.chromium.launch()  # política de reprodução padrão: som sem toque é bloqueado
    c,pg=ctx(br=b2,pref='1');pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv')&&document.getElementById('introv').currentTime>0.2",timeout=8000)
    s=ev(pg,ST);ok('Navegador bloqueando som automático: a intro toca MUDA (não trava nem some) e o botão continua para ligar',s is not None and s['muted'] and not s['paused'] and not pg.errs,(s,pg.errs[:1]))
    pg.click('#intsnd');pg.wait_for_timeout(300);ok('...e o toque no botão (gesto do usuário) liga o som',not ev(pg,"document.getElementById('introv').muted"));c.close();b2.close()
    # ---------- pular / repetir / modo teste / movimento reduzido ----------
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000);t1=time.time();pg.touchscreen.tap(200,500);pg.wait_for_function("!document.getElementById('intro')",timeout=3000)
    ok('Tocar na tela pula a intro com um desvanecer rápido (menos de 1 s)',time.time()-t1<1.0,round(time.time()-t1,2))
    pg.reload();pg.wait_for_timeout(700);ok('Recarregar na mesma sessão não repete a intro',not ev(pg,"!!document.getElementById('intro')"));c.close()
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('#introv',state='attached');pg.keyboard.press('Tab');pg.wait_for_timeout(300);ok('Tab não pula a intro',ev(pg,"!!document.getElementById('intro')"));c.close()
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv').currentTime>0.2",timeout=8000);pg.keyboard.press('Escape');pg.wait_for_function("!document.getElementById('intro')",timeout=3000);ok('Outra tecla (Esc) pula a intro',True);c.close()
    c,pg=ctx();c.add_init_script("window.__WS_NOTOUR=1");pg.goto(HTTP_URL);pg.wait_for_timeout(400);ok('No modo de testes (gancho) a intro não aparece nem baixa vídeo',not ev(pg,"!!document.getElementById('intro')") and not [u for u in pg.reqs if 'intro-lobo' in u]);c.close()
    c,pg=ctx(reduce=True);pg.goto(HTTP_URL);pg.wait_for_timeout(500)
    ok('"Reduzir movimento" ligado no aparelho: sem intro e sem baixar o vídeo (vai direto ao app)',not ev(pg,"!!document.getElementById('intro')") and not [u for u in pg.reqs if 'intro-lobo' in u] and ev(pg,"!!document.querySelector('#lock [data-lk=enter], #mf')"));c.close()
    # ---------- falhas ----------
    c,pg=ctx();pg.route(re.compile(r'intro-lobo\.(mp4|webm)'),lambda r:r.abort());t0=time.time();pg.goto(HTTP_URL);pg.wait_for_function("!document.getElementById('intro')",timeout=8000)
    ok('Vídeo não carrega (rede/arquivo ausente): a intro some sozinha em poucos segundos e o app abre normalmente',time.time()-t0<7 and ev(pg,"!!document.querySelector('#lock [data-lk=enter], #mf')") and not pg.errs,(round(time.time()-t0,2),pg.errs[:1]));c.close()
    # ---------- CSP real e offline ----------
    c,pg=ctx(csp=True);pg.goto(HTTP_URL);t0=time.time();ok_play=False
    while time.time()-t0<8:
        if ev(pg,"(()=>{const v=document.getElementById('introv');return !!v&&v.currentTime>0.3})()"):ok_play=True;break
        time.sleep(.2)
    ok('Sob a política de conteúdo (CSP) real o vídeo toca e não há nenhuma violação',ok_play and ev(pg,"window.__v.length")==0 and not pg.errs,(ev(pg,"window.__v"),pg.errs[:1]));c.close()
    c,pg=ctx(service_workers='allow');pg.goto(HTTP_URL);t0=time.time()
    while time.time()-t0<10 and not ev(pg,"navigator.serviceWorker&&navigator.serviceWorker.controller?1:0"):
        time.sleep(.3);pg.evaluate("navigator.serviceWorker&&navigator.serviceWorker.ready.then(()=>0);0")
    cached=ev(pg,"caches.keys().then(async ks=>{for(const k of ks){const c=await caches.open(k);if(await c.match('intro-lobo.mp4'))return true}return false})")
    ok('Offline: o vídeo da intro fica guardado no cache do app (Service Worker)',cached is True,cached);c.close()
    # ---------- telas ----------
    for w,h,fit in ((360,640,'cover'),(393,851,'cover'),(768,1024,'contain'),(844,390,'contain')):
        c,pg=ctx(w=w,h=h);pg.goto(HTTP_URL);pg.wait_for_function("document.getElementById('introv')&&document.getElementById('introv').currentTime>0.3",timeout=8000)
        m=ev(pg,"(()=>{const v=document.getElementById('introv'),r=document.getElementById('intro').getBoundingClientRect(),s=document.getElementById('intsnd').getBoundingClientRect();return{fit:getComputedStyle(v).objectFit,cobre:r.width>=innerWidth&&r.height>=innerHeight,btn:s.width,inside:s.right<=innerWidth&&s.top>=0,ovx:document.documentElement.scrollWidth>innerWidth}})()")
        ok(f'Tela {w}x{h}: vídeo em tela cheia ({fit}), botão de som ≥ 44 px e dentro da tela, sem rolagem lateral',m['fit']==fit and m['cobre'] and m['btn']>=44 and m['inside'] and not m['ovx'],m);c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
