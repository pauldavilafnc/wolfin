"""v7.13: despesas fixas (dia do vencimento) x variáveis (calendário); histórico preservado. Só dados fictícios; Chromium simulado."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
BASE="""{owner:'T',opening:{c:100000,d:'2026-01-01'},items:[
{id:'f1',t:'exp',d:'Aluguel',c:80000,day:5,cat:'Moradia',pay:'Pix',fixed:true,from:'2026-09',done:{'2026-09':80000,'2026-10':80000}},
{id:'v1',t:'exp',d:'Mercado',c:15000,day:8,dt:'2026-11-08',cat:'Alimentação',pay:'Pix',fixed:false,ym:'2026-11',done:{'2026-11':15000}},
{id:'r1',t:'inc',d:'Salário',c:300000,day:5,cat:'Salário',pay:'Pix',fixed:true,from:'2026-01',done:{}}],
inst:[],parc:[],debts:[],boxes:[],cards:[],pref:S.pref,flags:{tour:1}}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def app(w=393,h=851,th='light',base=True):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)))
        pg.clock.set_fixed_time('2026-11-15T10:00:00-03:00');pg.goto(HTTP_URL);OB_NOSEC(pg,'T')
        pg.wait_for_selector('#lock[hidden]',state='attached',timeout=10000);pg.wait_for_timeout(500)
        pg.evaluate("S.pref.theme='%s';applyPref()"%th)
        if base:pg.evaluate("S=migrate("+BASE+");save();render()")
        pg.evaluate("vm='2026-11'");return c,pg
    it=lambda pg,i:pg.evaluate("JSON.parse(JSON.stringify(S.items.find(x=>x.id==='%s')))"%i)
    vis=lambda pg,sel:pg.evaluate("(()=>{const e=document.querySelector('%s');return !!e&&!e.hidden&&e.offsetParent!==null})()"%sel)
    def save(pg):pg.click('#f .b1');pg.wait_for_timeout(250)
    # A. nova despesa fixa
    c,pg=app(base=False)
    pg.evaluate("itemForm('exp',null,1)");pg.wait_for_selector('#f')
    ok('A. Nova despesa Fixa: mostra seletor de dia (1 a 31) e esconde o calendário',vis(pg,'#fxw') and not vis(pg,'#dtw') and pg.evaluate("document.querySelectorAll('#fxw option').length")==31)
    ok('A. Explicação abaixo do campo',pg.inner_text('#fxh')=='Fixa: dia do vencimento, repetido todos os meses. Variável: data exata da despesa.')
    pg.fill('#f [name=d]','Internet');pg.fill('#f [name=c]','100,00');pg.select_option('#fxw select','31');save(pg)
    i=pg.evaluate("S.items[0]")
    ok('A. Cadastrada: fixa, dia 31, a partir de novembro, sem data completa guardada',i['fixed'] and i['day']==31 and i['from']=='2026-11' and 'dt' not in i,i)
    chk=pg.evaluate("['2026-11','2026-12','2027-01','2027-02','2027-04','2028-02'].map(m=>{const d=due(S.items[0],m);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')})")
    ok('A. Datas locais corretas nos meses de 28/29/30/31 dias',chk==['2026-11-30','2026-12-31','2027-01-31','2027-02-28','2027-04-30','2028-02-29'],chk)
    ok('A. Sem duplicação: 1 lançamento aparece em cada mês',pg.evaluate("['2026-11','2026-12','2027-01'].every(m=>rowsOf('exp',m).length===1)") and pg.evaluate("S.items.length")==1)
    # B. nova variável: calendário
    pg.evaluate("itemForm('exp',null,0)");pg.wait_for_selector('#f')
    ok('B. Nova despesa Variável: mostra o calendário completo e esconde o seletor de dia',vis(pg,'#dtw') and not vis(pg,'#fxw') and pg.evaluate("document.querySelectorAll('#dtw .cd').length")==30)
    pg.fill('#f [name=d]','Cinema');pg.fill('#f [name=c]','60,00');pg.click('#dtw .cd[data-d="2026-11-22"]');save(pg)
    i=pg.evaluate("S.items[1]");ok('B. Variável gravada com a data exata (22/11/2026), sem repetição',not i['fixed'] and i['dt']=='2026-11-22' and i['day']==22 and i['ym']=='2026-11',i)
    ok('B. Não aparece em dezembro',pg.evaluate("rowsOf('exp','2026-12').every(x=>x.d!=='Cinema')"))
    # C. troca dinâmica
    pg.evaluate("itemForm('exp',null,1)");pg.wait_for_selector('#f');pg.select_option('#f select[name=fx]','0')
    ok('C. Trocar Fixa → Variável: aparece o calendário e some o seletor',vis(pg,'#dtw') and not vis(pg,'#fxw'))
    pg.select_option('#f select[name=fx]','1');ok('C. Variável → Fixa: volta o seletor de dia',vis(pg,'#fxw') and not vis(pg,'#dtw'))
    ok('C. Explicação permanece visível nos dois tipos',vis(pg,'#fxh'));pg.evaluate("closeOv()")
    # D. editar existentes
    pg.evaluate("S=migrate("+BASE+");save();render();vm='2026-11'")
    pg.evaluate("itemForm(null,'f1')");pg.wait_for_selector('#fxw')
    ok('D. Editar fixa: carrega o dia configurado (05) em seletor, sem calendário',pg.evaluate("document.querySelector('#fxw select').value")=='5' and not vis(pg,'#dtw'))
    save(pg);ok('D. Salvar sem alterar não muda nada (sem histórico novo)',it(pg,'f1')['day']==5 and 'dh' not in it(pg,'f1') and it(pg,'f1')['done']=={'2026-09':80000,'2026-10':80000})
    pg.evaluate("itemForm(null,'f1')");pg.wait_for_selector('#fxw');pg.select_option('#fxw select','12');save(pg);x=it(pg,'f1')
    ok('D. Alterar dia 05 → 12 a partir de novembro; meses anteriores mantêm dia 05 (histórico)',x['day']==12 and pg.evaluate("[dayAt(S.items[0],'2026-09'),dayAt(S.items[0],'2026-10'),dayAt(S.items[0],'2026-11'),dayAt(S.items[0],'2027-03')]")==[5,5,12,12],x)
    ok('D. Pagamentos anteriores intactos; valor, categoria e forma de pagamento preservados',x['done']=={'2026-09':80000,'2026-10':80000} and x['c']==80000 and x['cat']=='Moradia' and x['pay']=='Pix' and x['fixed'])
    # segunda alteração em dezembro
    pg.evaluate("vm='2026-12';itemForm(null,'f1')");pg.wait_for_selector('#fxw');pg.select_option('#fxw select','20');save(pg)
    ok('D. Nova alteração em dezembro (→20) preserva 05 (set/out) e 12 (nov)',pg.evaluate("['2026-09','2026-10','2026-11','2026-12','2027-02'].map(m=>dayAt(S.items[0],m))")==[5,5,12,20,20])
    pg.evaluate("vm='2026-11'");pg.evaluate("go('rel')");pg.evaluate("rpm='2026-10';render()")
    txt=pg.evaluate("rowsOf('exp','2026-10').map(i=>dayAt(i,'2026-10'))");ok('D. Lista de outubro continua mostrando dia 05',txt==[5],txt)
    # E. variável existente
    pg.evaluate("itemForm(null,'v1')");pg.wait_for_selector('#dtw')
    ok('E. Editar variável: calendário completo com a data (08/11/2026) marcada',vis(pg,'#dtw') and pg.evaluate("document.querySelector('#f input[name=dt]').value")=='2026-11-08' and not vis(pg,'#fxw'))
    pg.click('#dtw .cd[data-d="2026-11-10"]');save(pg);x=it(pg,'v1')
    ok('E. Data alterada para 10/11; continua variável; valor/categoria/pagamento preservados',x['dt']=='2026-11-10' and x['day']==10 and not x['fixed'] and x['c']==15000 and x['cat']=='Alimentação' and x['done']=={'2026-11':15000},x)
    # receita não muda
    pg.evaluate("itemForm(null,'r1')");pg.wait_for_selector('#f [name=day]');ok('E. Receitas continuam com o campo "Dia do mês" (fora do escopo)',pg.evaluate("!document.querySelector('#fxw')&&!!document.querySelector('#f [name=day]')"));pg.evaluate("closeOv()")
    # F. mapa de calor e relatórios
    pg.evaluate("(()=>{HMS.main.m='2026-10';HMS.main.sel=0;go('rel')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('F. Mapa de calor de outubro: aluguel pago no dia 5 (dia antigo preservado)',pg.inner_text('.hmw[data-hm=main] [data-d="5"] span')=='800' and pg.inner_text('.hmw[data-hm=main] [data-d="12"] span')=='')
    pg.evaluate("(()=>{HMS.main.m='2026-11';go('rel')})()");pg.wait_for_selector('.hmw[data-hm=main] .hmc')
    ok('F. Mapa de calor de novembro: variável paga no dia 10 (R$ 150)',pg.inner_text('.hmw[data-hm=main] [data-d="10"] span')=='150')
    t=pg.evaluate("({set:relFlow('2026-09').exp,out:relFlow('2026-10').exp,nov:relFlow('2026-11').exp,n:S.items.length})")
    ok('F. Relatórios: totais iguais aos pagamentos registrados, sem duplicar (set 800, out 800, nov 150)',t==dict(set=80000,out=80000,nov=15000,n=3),t)
    ok('Sem erros de JS',pg.errs==[],pg.errs)
    c.close()
    # G. temas e celulares
    for th in('light','dark'):
        for w,h in((360,740),(393,851),(768,1024)):
            c,pg=app(w,h,th);pg.evaluate("itemForm('exp',null,1)");pg.wait_for_selector('#fxw')
            m=pg.evaluate("""(()=>{const r=e=>e.getBoundingClientRect(),s=r(document.querySelector('#fxw select')),sh=r(document.querySelector('#ov .sheet')),h=document.getElementById('fxh');return{sh:s.height,ovx:document.documentElement.scrollWidth>innerWidth,inside:sh.left>=0&&sh.right<=innerWidth,hc:getComputedStyle(h).color,hv:h.offsetParent!==null}})()""")
            pg.select_option('#f select[name=fx]','0');m2=pg.evaluate("document.querySelectorAll('#dtw .cd').length>0&&document.querySelector('#dtw .cd').getBoundingClientRect().height>=33")
            ok(f'G. {th} {w}px: seletor ≥44px, texto de ajuda visível, calendário ok, sem rolagem lateral',m['sh']>=43.5 and m['hv'] and not m['ovx'] and m['inside'] and m2,m)
            c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
