"""v7.29: identidade Midnight Violet + Liquid Glass — sem intro, nova logo/ícones PWA (margens, maskable), paleta Midnight Violet
(Pérola removida), tema escuro inicial só para quem é novo, mascote Padrão (novo Wolfin) com Brasil preservado. Só PIL/Playwright."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json,math
from PIL import Image,ImageChops,ImageStat
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html');sw=rd('sw.js')
# ---------- intro removida ----------
ok('1. Intro animada removida: sem #intro, vídeo, botão de som nem script de intro',not any(k in html for k in ('id="intro"','id="introv"','id="intsnd"','wolfin.introsnd','intro-css')))
ok('1. Arquivos de vídeo da intro não existem mais e o service worker não os guarda',not any(os.path.exists(os.path.join(ROOT,f)) for f in ('intro-lobo.mp4','intro-lobo.webm','intro-wolfin.mp4')) and 'intro-lobo' not in sw)
# ---------- ícones ----------
ref=Image.open(os.path.join(ROOT,'tests','fixtures','logo','logo-referencia-v736.png')).convert('RGB')
def ic(f):return Image.open(os.path.join(ROOT,f))
sizes={'icon-192.png':(192,192),'icon-512.png':(512,512),'icon-maskable-512.png':(512,512),'apple-touch-icon.png':(180,180),'favicon-32.png':(32,32),'favicon-48.png':(48,48)}
ok('2. Os 6 ícones existem com os tamanhos corretos',all(ic(f).size==s for f,s in sizes.items()),{f:ic(f).size for f in sizes})
man=json.loads(rd('manifest.webmanifest'))
ok('2. Manifesto: mesmos 3 arquivos de ícone (192, 512, maskable com purpose próprio) e cores Midnight (#080512)',[i['src'] for i in man['icons']]==['icon-192.png','icon-512.png','icon-maskable-512.png'] and [i['purpose'] for i in man['icons']]==['any','any','maskable'] and man['theme_color']=='#080512' and man['background_color']=='#080512',man['theme_color'])
ok('2. HTML: theme-color Midnight e favicons/apple-touch apontando para os arquivos novos','content="#080512"' in html and 'href="favicon-32.png"' in html and 'href="apple-touch-icon.png"' in html)
for f in ('icon-512.png','icon-192.png'):
    im=ic(f).convert('RGBA');a=im.getchannel('A');bb=a.point(lambda v:255 if v>128 else 0).getbbox();W=im.width
    cw,ch=bb[2]-bb[0],bb[3]-bb[1]
    rim=im.crop(bb).convert('RGB').resize(ref.size,Image.LANCZOS);d=sum(ImageStat.Stat(ImageChops.difference(rim,ref)).mean)/3
    mg=[bb[0]/W,bb[1]/W,(W-bb[2])/W,(W-bb[3])/W]
    ok(f'3. {f}: é a logo enviada (diferença média {d:.1f}/255), com margem interna equilibrada (7–14%), centralizada, sem corte e cantos transparentes',d<12 and all(.07<=m<=.14 for m in mg) and abs(mg[0]-mg[2])<.02 and abs(mg[1]-mg[3])<.02 and a.getpixel((2,2))==0 and a.getpixel((W-3,W-3))==0,(round(d,1),[round(m,3) for m in mg]))
m=ic('icon-maskable-512.png').convert('RGB');W=m.width
lum=m.convert('L').point(lambda v:255 if v>110 else 0);bb=lum.getbbox();cx,cy=(bb[0]+bb[2])/2,(bb[1]+bb[3])/2
far=max(math.hypot(x-W/2,y-W/2) for x,y in((bb[0],bb[1]),(bb[2],bb[1]),(bb[0],bb[3]),(bb[2],bb[3])))
ok('3. icon-maskable: quadrado cheio violeta escuro, símbolo isolado dentro da zona segura (raio ≤ 40%), centralizado e sem quadrado duplo',sum(ImageStat.Stat(m.crop((226,250,286,310)).convert("L")).mean)>70 and (lambda c:0.299*c[0]+0.587*c[1]+0.114*c[2]<70)(m.getpixel((4,4))) and far<=.40*W and abs(cx-W/2)<14 and abs(cy-W/2)<22,(far/W,cx,cy))
t=ic('apple-touch-icon.png').convert('RGB');ok('3. apple-touch-icon: opaco, fundo violeta escuro e lobo claro centralizado',sum(1 for v in t.convert('L').getdata() if v>150)>250 and (lambda c:0.299*c[0]+0.587*c[1]+0.114*c[2]<70)(t.getpixel((3,3))) and t.mode=='RGB')
f48=ic('favicon-48.png').convert('RGBA');f32=ic('favicon-32.png').convert('RGBA')
ok('3. favicons 32/48: logo violeta nítida (centro claro, bordas do quadrado visíveis, canto transparente)',max(v for v in f32.convert('L').getdata())>150 and max(v for v in f48.convert('L').getdata())>170 and f48.getpixel((0,0))[3]==0 and f48.getpixel((24,24))[3]==255)
def _lin(v):
    v/=255;return v/12.92 if v<=.03928 else ((v+.055)/1.055)**2.4
def _cr(f):
    im=ic(f).convert('RGBA');px=im.load();W,H=im.size;vis=[]
    for y in range(H):
        for x in range(W):
            r,g,b,al=px[x,y]
            if al>200:vis.append(.2126*_lin(r)+.7152*_lin(g)+.0722*_lin(b))
    vis.sort();n=len(vis);return (vis[int(n*.90)]+.05)/(vis[int(n*.15)]+.05)
_c={f:round(_cr(f),1) for f in ('icon-512.png','icon-192.png','icon-maskable-512.png','apple-touch-icon.png','favicon-48.png')}
ok('3. Contraste v7.36: símbolo branco contra o fundo violeta ≥ 8:1 em todos os ícones (a logo anterior ficava abaixo disso na tela inicial)',all(v>=8 for v in _c.values()),_c)
ok('3. Compressão: ícones leves (< 300 KB)',all(os.path.getsize(os.path.join(ROOT,f))<300_000 for f in sizes),{f:os.path.getsize(os.path.join(ROOT,f)) for f in sizes})
ok('3. Service worker com versão nova do cache (força a troca da imagem antiga)',re.search(r"VERSAO = '(\d+)'",sw) and int(re.search(r"VERSAO = '(\d+)'",sw).group(1))>=7)
# ---------- paleta ----------
ok('4. Paleta Pérola removida do código e Midnight Violet no lugar dela; as outras 8 continuam',"data-pal=perola" not in html and "['perola'," not in html and "['midnight','Midnight Violet','#65518C']" in html and all(('data-pal='+p+']') in html for p in ['violet','teal','pink','orange','ouro','esmeralda','grafite']) and "['blue','Azul'" in html)
ok('4. Cores de referência presentes (#080512 #151024 #302447 #65518C #A58BEB #D8C8FF #F8F5FF)',all(c.lower() in html.lower() for c in ['#080512','#151024','#302447','#65518C','#A58BEB','#D8C8FF','#F8F5FF']))
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True);c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1");pg=c.new_page();pg.errs=[];pg.on('pageerror',lambda e:pg.errs.append(str(e)));return c,pg
    # novo usuário
    c,pg=ctx();pg.goto(HTTP_URL);pg.wait_for_selector('[data-lk=new]')
    ok('5. Novo usuário abre direto na tela inicial (sem intro) já em tema escuro + Midnight Violet',pg.evaluate("[document.documentElement.dataset.theme,document.documentElement.dataset.pal]")==['dark','midnight'] and pg.locator('#intro').count()==0)
    pg.click('[data-lk=new]');pg.wait_for_selector('#cf')
    ok('5. Onboarding: Escuro e Midnight Violet marcados; Claro e todas as outras cores continuam disponíveis',pg.locator('#cf [data-lk=cmode][data-id=dark]').get_attribute('aria-pressed')=='true' and pg.locator('#cf .pal.on').get_attribute('data-id')=='midnight' and pg.locator('#cf .pal').count()==9 and pg.locator('#cf .pal[data-id=perola]').count()==0)
    pg.click('#cf [data-lk=cmode][data-id=light]');pg.click('#cf [data-lk=cpick][data-id=teal]')
    ok('5. Trocar para Claro + Turquesa funciona na hora',pg.evaluate("[document.documentElement.dataset.theme,document.documentElement.dataset.pal]")==['light','teal'])
    pg.click('#cf button:not([type=button])');pg.wait_for_selector('#nf');pg.fill('#nf [name=n]','Paulo');pg.click('#nf button:not([type=button])');pg.wait_for_selector('#sf');pg.click('[data-lk=nosec]');pg.wait_for_selector('#lock[hidden]',state='attached');pg.wait_for_timeout(500)
    pg.reload();pg.wait_for_selector('#s-home');pg.wait_for_timeout(700)
    ok('5. A escolha (claro + turquesa) fica salva depois de recarregar — o escuro inicial não é forçado de novo',pg.evaluate("[document.documentElement.dataset.theme,document.documentElement.dataset.pal,S.pref.theme,S.pref.pal]")==['light','teal','light','teal'],pg.evaluate("[S.pref.theme,S.pref.pal]"))
    pg.evaluate("go('cfg',{cat:'aparencia'})");pg.wait_for_timeout(300);pg.click('#cs-apa [data-act=theme][data-id=dark]');pg.click('#cs-apa [data-act=pal][data-id=midnight]');pg.wait_for_timeout(300)
    ok('5. Configurações → Aparência: Midnight Violet + escuro selecionáveis e salvos',pg.evaluate("[S.pref.theme,S.pref.pal,document.documentElement.dataset.pal]")==['dark','midnight','midnight'] and pg.locator('#cs-apa [data-act=pal][data-id=perola]').count()==0)
    ok('5. Sem erros de JavaScript',not pg.errs,pg.errs[:2]);c.close()
    # usuário existente: preferências preservadas; Pérola migra para Midnight
    base={"v":2,"owner":"Ana","opening":None,"limits":{},"cards":[],"ntf":{"read":{}},"items":[],"inst":[],"parc":[],"debts":[],"boxes":[]}
    def existing(pref,wc=None):
        d=dict(base);d['pref']=pref
        if wc is not None:d['wc']=wc
        c,pg=ctx();pg.goto(HTTP_URL);pg.evaluate("([d])=>{localStorage.setItem('wallstreet.v1',JSON.stringify(d))}",[d]);pg.reload();pg.wait_for_selector('#s-home');pg.wait_for_timeout(900);return c,pg
    c,pg=existing({"theme":"light","pal":"blue"})
    ok('6. Usuário existente em Claro + Azul NÃO é trocado para escuro/Midnight',pg.evaluate("[document.documentElement.dataset.theme,document.documentElement.dataset.pal,S.pref.theme,S.pref.pal]")==['light','blue','light','blue']);c.close()
    c,pg=existing({"theme":"dark","pal":"ouro"})
    ok('6. Usuário existente em Escuro + Ouro continua igual',pg.evaluate("[S.pref.theme,S.pref.pal,document.documentElement.dataset.pal]")==['dark','ouro','ouro']);c.close()
    c,pg=existing({"theme":"dark","pal":"perola"})
    ok('6. Quem usava a Pérola (removida) passa para a Midnight Violet, sem erro e mantendo o tema',pg.evaluate("[S.pref.theme,S.pref.pal,document.documentElement.dataset.pal]")==['dark','midnight','midnight'] and not pg.errs);c.close()
    # mascote
    c,pg=ctx();pg.goto(HTTP_URL);OB_NOSEC(pg,'Paulo');pg.wait_for_selector('#lock[hidden]',state='attached');pg.wait_for_timeout(900)
    r=pg.evaluate("[S.wc.look,S.wc.own,wfState('padrao'),wfState('brasil'),WLOOKS[0].id,WLOOKS[0].p,!!(window.WOLFIMG&&WOLFIMG.sty&&WOLFIMG.sty.padrao&&WOLFIMG.sty.padrao.n&&WOLFIMG.sty.padrao.b)]")
    ok('7. Novo usuário: mascote Padrão equipado, gratuito (preço 0), com corpo inteiro e busto; Brasil também desbloqueado',r[0]=='padrao' and 'padrao' in r[1] and 'brasil' in r[1] and r[2]=='eq' and r[3]=='own' and r[4]=='padrao' and r[5]==0 and r[6],r)
    r=pg.evaluate("(()=>{const e=document.querySelector('#s-home .mqc .wolf');return[e&&e.dataset.look,e&&e.dataset.k,e&&e.querySelector('img')&&e.querySelector('img').naturalWidth>50]})()")
    ok('7. Home: cartão do mascote usa o busto do Padrão (imagem carregada)',r==['padrao','b',True],r)
    pg.evaluate("go('loja')");pg.wait_for_timeout(700)
    ok('7. Loja: Padrão em primeiro, "Equipado"; Brasil continua na lista e todos os personagens seguem liberados (modo de testes)',pg.evaluate("[...document.querySelectorAll('#s-loja .lc')].map(e=>e.dataset.look).slice(0,2)")==['padrao','brasil'] and pg.locator('#s-loja .lc').count()==12 and pg.evaluate("WF_ALL_FREE")==True)
    pg.evaluate("ACT.wlook('brasil')");pg.wait_for_timeout(300);pg.evaluate("save()");pg.reload();pg.wait_for_selector('#s-home');pg.wait_for_timeout(900)
    ok('7. Escolher Brasil e recarregar: a escolha é respeitada (não volta para o Padrão)',pg.evaluate("[S.wc.look,wfLook()]")==['brasil','brasil'])
    pg.evaluate("ACT.wlook('padrao')");pg.evaluate("save()");pg.reload();pg.wait_for_selector('#s-home');pg.wait_for_timeout(900)
    ok('7. Voltar ao Padrão fica salvo após reiniciar',pg.evaluate("S.wc.look")=='padrao' and not pg.errs,pg.errs[:2]);c.close()
    # existente com Brasil antigo (sem marcador dv): vai uma vez ao Padrão; com dv=2 e Brasil: respeita
    c,pg=existing({"theme":"dark","pal":"blue"},{"n":40,"tot":40,"done":{},"own":["brasil"],"look":"brasil","log":[]})
    ok('7. Usuário antigo que estava no Brasil (padrão anterior) passa uma única vez ao Padrão, sem mexer no saldo de WolfCoins',pg.evaluate("[S.wc.look,S.wc.dv]")==['padrao',2] and pg.evaluate("S.wc.n")>=40);c.close()
    c,pg=existing({"theme":"dark","pal":"blue"},{"n":40,"tot":40,"done":{},"own":["brasil","shelby"],"look":"shelby","log":[],"dv":2})
    ok('7. Usuário que escolheu Shelby continua com Shelby',pg.evaluate("S.wc.look")=='shelby');c.close()
    b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
