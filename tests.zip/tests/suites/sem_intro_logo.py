"""v7.14/7.15: intro em vídeo removida (agora minimalista, sem arquivos de mídia) + nova logo do lobo (ícones do app, favicon, Sobre). Paletas e demais áreas intactas. Só PIL/Playwright."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import re,json
from PIL import Image,ImageChops,ImageStat
from playwright.sync_api import sync_playwright
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
def rd(p):
    with open(os.path.join(ROOT,p),encoding='utf-8') as f:return f.read()
html=rd('index.html');sw=rd('sw.js')
# ---------- intro removida (código e arquivos) ----------
ok('Intro sem vídeo: nenhum <video>, nenhum arquivo de mídia da intro no código',not re.search(r'<video|introv|intro-wolfin|\.mp4|\.webm(?![a-z])',html))
ok('Sem a intro em vídeo no Service Worker (nenhum vídeo guardado nem tratamento de trechos)','intro-wolfin' not in sw and 'ehVideo' not in sw and '206' not in sw)
ok('Arquivos do vídeo da intro não existem mais na pasta do site',not any(os.path.exists(os.path.join(ROOT,f)) for f in ('intro-wolfin.mp4','intro-wolfin.webm')))
ok('Nenhum preload de ícone herdado da intro','rel="preload" as="image" href="icon-512.png"' not in html)
# ---------- ícones novos ----------
ref=Image.open(os.path.join(ROOT,'tests','fixtures','logo','icone-referencia.png')).convert('RGB')
def ic(f):return Image.open(os.path.join(ROOT,f))
sizes={'icon-192.png':(192,192),'icon-512.png':(512,512),'icon-maskable-512.png':(512,512),'apple-touch-icon.png':(180,180),'favicon-32.png':(32,32),'favicon-48.png':(48,48)}
ok('Os 6 ícones existem com os tamanhos de sempre',all(ic(f).size==s for f,s in sizes.items()),{f:ic(f).size for f in sizes})
man=json.loads(rd('manifest.webmanifest'))
ok('Manifesto continua apontando para os mesmos arquivos de ícone (192, 512, maskable), sem mudar cores',[i['src'] for i in man['icons']]==['icon-192.png','icon-512.png','icon-maskable-512.png'] and man['theme_color']=='#0B1730' and man['background_color']=='#0B1730')
for f in ('icon-512.png','icon-192.png'):
    im=ic(f).convert('RGBA');a=im.getchannel('A');bb=a.point(lambda v:255 if v>128 else 0).getbbox()
    cw,ch=bb[2]-bb[0],bb[3]-bb[1]
    rim=im.crop(bb).convert('RGB').resize(ref.size,Image.LANCZOS);d=sum(ImageStat.Stat(ImageChops.difference(rim,ref)).mean)/3
    ok(f'{f}: é a logo enviada (forma e lobo iguais à referência; diferença média {d:.1f}/255) e cantos transparentes',d<14 and a.getpixel((2,2))==0 and a.getpixel((im.width-3,im.height-3))==0 and abs(cw/ch-ref.width/ref.height)<0.03,(d,cw,ch))
m=ic('icon-maskable-512.png').convert('RGB');ok('icon-maskable: quadrado cheio, lobo claro no centro e azul nas bordas (sem cantos vazios)',min(m.getpixel((256,230)))>200 and m.getpixel((8,500))[2]>150 and m.getpixel((503,503))[2]>150 and 'A' not in ic('icon-maskable-512.png').getbands())
t=ic('apple-touch-icon.png').convert('RGB');ok('apple-touch-icon: quadrado cheio com o lobo no centro',min(t.getpixel((90,82)))>190 and t.getpixel((4,176))[2]>140)
f48=ic('favicon-48.png').convert('RGBA');ok('favicons 32/48 com o lobo claro no centro e fundo azul',max(ic('favicon-32.png').convert('RGBA').getpixel((16,15))[:3])>180 and f48.getpixel((24,22))[0]>170 and f48.getpixel((6,24))[2]>150)
ok('Compressão: ícones leves (maiores < 260 KB)',all(os.path.getsize(os.path.join(ROOT,f))<260_000 for f in sizes),{f:os.path.getsize(os.path.join(ROOT,f)) for f in sizes})
# ---------- paletas e áreas não relacionadas intactas ----------
pals=['blue','perola','violet','teal','pink','orange','ouro','esmeralda','grafite']
ok('As 9 paletas de cores continuam no código, com as variáveis de cor originais',all(('data-pal='+p+']') in html for p in pals if p!='blue') and '--navy:#0B1730' in html and '--blue:#2563EB' in html and '--av1' in html)
with sync_playwright() as p:
    b=p.chromium.launch()
    # Sobre: logo nova visível e nítida
    c=b.new_context(viewport={'width':393,'height':851},is_mobile=True,has_touch=True);c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1")
    pg=c.new_page();pg.goto(HTTP_URL);OB_NOSEC(pg,'T');pg.wait_for_selector('#lock[hidden]',state='attached');pg.wait_for_timeout(400)
    pg.evaluate("go('cfg')");pg.wait_for_selector('.abt .ab1 .ico img',state='attached');pg.locator('.abt').scroll_into_view_if_needed();pg.wait_for_timeout(300)
    m=pg.evaluate("(()=>{const i=document.querySelector('.abt .ab1 .ico img'),r=i.getBoundingClientRect();return{nw:i.naturalWidth,w:r.width,h:r.height,vis:getComputedStyle(i).display!=='none'&&r.width>0}})()")
    ok('Sobre: a logo nova aparece (128 px de origem, 64 px na tela, bem nítida)',m['nw']==128 and m['vis'] and 60<=m['w']<=68,m)
    pg.locator('.abt .ab1 .ico').screenshot(path='/tmp/sobre_logo.png');im=Image.open('/tmp/sobre_logo.png').convert('RGB');w,h=im.size
    ok('Sobre: o lobo claro aparece no centro do quadrado azul',min(im.getpixel((w//2,int(h*.42))))>190 and im.getpixel((int(w*.08),int(h*.5)))[2]>150,(im.getpixel((w//2,int(h*.42))),im.getpixel((int(w*.08),int(h*.5)))))
    c.close();b.close()
print(f'\n{sum(R)}/{len(R)}');_sys.exit(0 if all(R) else 1)
