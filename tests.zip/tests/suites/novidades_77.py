"""v7.7: aviso de backup (30 dias), notas fixadas, busca única e resumo do mês em imagem.
Só dados fictícios; Chromium simulado (sem celular real)."""
import os as _os,sys as _sys
_sys.path.insert(0,_os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),'lib'))
from wstest import *
import os,re,json,tempfile
from playwright.sync_api import sync_playwright
from PIL import Image
URL=HTTP_URL;TMP=tempfile.mkdtemp(prefix='n77_')
R=[]
def ok(n,c,d=''): R.append(bool(c));print(('PASS ' if c else 'FAIL ')+n+(' — '+str(d)[:300] if d else ''),flush=True)
SEED="""(()=>{const m=ymOf(new Date());S.items.push({id:'a1',t:'inc',d:'Salário Confidencial',c:300000,day:5,fixed:true,from:m,cat:'Salário',done:{[m]:300000}},{id:'a2',t:'exp',d:'Internet fibra',c:12000,day:20,fixed:true,from:m,cat:'Casa',done:{[m]:12000}},{id:'a3',t:'exp',d:'Mercado do Zé',c:80000,day:8,fixed:true,from:m,cat:'Alimentação',done:{[m]:80000}},{id:'a4',t:'exp',d:'Cinema com Maria',c:6000,day:9,fixed:true,from:m,cat:'Lazer',done:{[m]:6000}});
S.org.notes.push({id:'n1',t:'Pagar internet dia 20',d:'conferir valor da fatura',u:1000,p:0},{id:'n2',t:'Ideia de renda extra',d:'vender edição de vídeo',u:2000,p:0},{id:'n3',t:'Senha do banco NOVA',d:'segredo123',u:3000,p:0});
S.org.lists.unshift({id:'qk',n:'Tarefas rápidas',items:[{id:'t1',t:'Pagar internet',ok:0},{id:'t2',t:'Fazer backup',ok:1}]});save();render()})()"""
with sync_playwright() as p:
    b=p.chromium.launch()
    def ctx(w=393,h=851,th='light',**k):
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=w<600,has_touch=w<600,color_scheme=th,accept_downloads=True,**k)
        c.add_init_script("window.__WS_NOCSP=1;window.__WS_NOTOUR=1;window.__WS_OPENDET=1")
        pg=c.new_page();pg.errs=[]
        pg.on('pageerror',lambda e:pg.errs.append(str(e)));pg.on('console',lambda m:pg.errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
        return c,pg
    def conta(w=393,h=851,th='light',nome='Ana',seed=True,**k):
        c,pg=ctx(w,h,th,**k);pg.goto(URL);OB_NOSEC(pg,nome);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_selector('#cfab');pg.wait_for_timeout(600)
        pg.evaluate(f"S.pref.theme='{th}';applyPref()")
        if seed:pg.evaluate(SEED);pg.wait_for_timeout(250)
        return c,pg
    vis=lambda pg,s:pg.evaluate("s=>{const e=document.querySelector(s);return !!e&&!e.hidden&&e.offsetWidth>0}",s)
    def setf(pg,js):pg.evaluate(f"(()=>{{S.flags=S.flags||{{}};{js};save();render()}})()");pg.wait_for_timeout(200)
    ago="(n=>ymdOf(new Date(Date.now()-n*864e5)))"
    # ================= A. aviso de backup =================
    c,pg=conta()
    ok('A1. Conta nova: nenhum aviso de backup',not vis(pg,'.bkb'))
    setf(pg,f"S.flags.bkpAt={ago}(29)");ok('A2. 29 dias desde o último backup: sem aviso',not vis(pg,'.bkb'))
    setf(pg,f"S.flags.bkpAt={ago}(30)");tx=pg.inner_text('.bkb') if vis(pg,'.bkb') else ''
    ok('A3. 30 dias: aviso discreto na Home com "Exportar agora" e "Depois"','Faz 30 dias' in tx and pg.locator('.bkb [data-act=bkpnow]').inner_text()=='Exportar agora' and pg.locator('.bkb [data-act=bkpsnz]').inner_text()=='Depois',tx)
    r=pg.evaluate("(()=>{const e=document.querySelector('.bkb').getBoundingClientRect();return{w:e.width,sx:document.documentElement.scrollWidth>innerWidth+1,btn:[...document.querySelectorAll('.bkb button')].map(x=>x.getBoundingClientRect().height)}})()")
    ok('A3. O aviso cabe na tela, sem rolagem lateral, com botões de toque ≥ 44 px',r['w']<=393 and not r['sx'] and min(r['btn'])>=44,r)
    pg.click('.bkb [data-act=bkpsnz]');pg.wait_for_timeout(250)
    ok('A4. "Depois" esconde o aviso e adia por 7 dias',not vis(pg,'.bkb') and pg.evaluate("S.flags.bkpSnz")==pg.evaluate(f"{ago}(0)"))
    pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500)
    ok('A4. Continua adiado depois de recarregar',not vis(pg,'.bkb'))
    setf(pg,f"S.flags.bkpSnz={ago}(8)");ok('A4. Passados 7 dias o aviso volta',vis(pg,'.bkb'))
    setf(pg,"S.pref.br=0");ok('A5. Com o lembrete de backup desligado (Ajustes) nunca aparece',not vis(pg,'.bkb'))
    setf(pg,"S.pref.br=7;delete S.flags.bkpSnz");con=[]
    pg.on('console',lambda m:con.append(m.text))
    with pg.expect_download() as dl:pg.click('.bkb [data-act=bkpnow]')
    d=dl.value;path=os.path.join(TMP,d.suggested_filename);d.save_as(path);bj=json.load(open(path,encoding='utf-8'))
    pg.wait_for_timeout(400)
    ok('A6. "Exportar agora" baixa o arquivo wolfin-backup-AAAA-MM-DD.json (mesma exportação de sempre)',re.fullmatch(r'wolfin-backup-\d{4}-\d{2}-\d{2}\.json',d.suggested_filename) and bj.get('__backup',{}).get('app')=='wallstreet-backup',d.suggested_filename)
    ok('A6. Depois de exportar a data do backup é hoje e o aviso some; o conteúdo do backup não vai para o console',pg.evaluate("S.flags.bkpAt")==pg.evaluate(f"{ago}(0)") and not vis(pg,'.bkb') and not any('Confidencial' in x or 'segredo123' in x for x in con))
    setf(pg,f"delete S.flags.bkpAt;delete S.flags.bkp;S.ntf.since={ago}(31)");ok('A7. Nunca exportou e usa o app há 31 dias: aviso "ainda não exportou"','ainda não exportou' in (pg.inner_text('.bkb') if vis(pg,'.bkb') else ''))
    setf(pg,f"S.ntf.since={ago}(10)");ok('A7. Nunca exportou mas usa há 10 dias: sem aviso',not vis(pg,'.bkb'))
    setf(pg,"S.flags.bkp=1");ok('A7. Já exportou (data desconhecida): aviso "Faz tempo"','Faz tempo' in (pg.inner_text('.bkb') if vis(pg,'.bkb') else ''))
    setf(pg,f"S.flags.bkpAt={ago}(40)");pg.evaluate("go('cfg')");pg.wait_for_timeout(200);ok('A8. O aviso é só da Home (não aparece em Ajustes, onde já há a seção de Backup)',not vis(pg,'.bkb') and pg.locator('[data-act=exp]').count()==1)
    pg.evaluate("go('home')");c.close()
    for th in ('light','dark'):
        c,pg=conta(320,568,th,nome='A'+th[0]);setf(pg,f"S.flags.bkpAt={ago}(45)")
        im=Image.open(__import__('io').BytesIO(pg.locator('.bkb').screenshot())).convert('RGB')
        from collections import Counter;px=list(im.getdata());bg=Counter(px).most_common(1)[0][0]
        lum=lambda q:(lambda f:.2126*f(q[0])+.7152*f(q[1])+.0722*f(q[2]))(lambda v:(v/255/12.92) if v/255<=.03928 else ((v/255+.055)/1.055)**2.4)
        fg=max(px,key=lambda q:abs(lum(q)-lum(bg)));rt=(max(lum(fg),lum(bg))+.05)/(min(lum(fg),lum(bg))+.05)
        ok(f'A9. Tema {th} (320 px): aviso legível (contraste {rt:.1f}:1) e sem rolagem lateral',rt>=4.5 and not pg.evaluate("document.documentElement.scrollWidth>innerWidth+1"));c.close()
    # ================= B. notas fixadas =================
    c,pg=conta()
    pg.evaluate("NTV='notes';go('nt')");pg.wait_for_timeout(300)
    ordem=lambda:pg.evaluate("[...document.querySelectorAll('.ntw .ntc b')].map(b=>b.textContent)")
    ok('B1. Sem fixadas: ordem por mais recente',ordem()==['Senha do banco NOVA','Ideia de renda extra','Pagar internet dia 20'],ordem())
    pg.click('.ntw >> nth=2 >> .ntp');pg.wait_for_timeout(300)
    ok('B2. Fixar a nota mais antiga a leva para o topo, marcada como fixada',ordem()[0]=='Pagar internet dia 20' and pg.locator('.ntw.pin').count()==1 and 'Fixada' in pg.inner_text('.ntw.pin .ntc') and pg.get_attribute('.ntw.pin .ntp','aria-pressed')=='true',ordem())
    pg.click('.ntw >> nth=2 >> .ntp');pg.wait_for_timeout(300)
    ok('B2. Duas fixadas ficam no topo, entre si por mais recente',ordem()[:2]==['Ideia de renda extra','Pagar internet dia 20'] and ordem()[2]=='Senha do banco NOVA',ordem())
    ok('B2. O pino tem nome acessível e alvo ≥ 44 px',pg.evaluate("[...document.querySelectorAll('.ntp')].every(x=>x.getAttribute('aria-label')&&x.getBoundingClientRect().width>=44&&x.getBoundingClientRect().height>=44)"))
    pg.reload();pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(500);pg.evaluate("NTV='notes';go('nt')");pg.wait_for_timeout(300)
    ok('B3. A fixação persiste depois de recarregar',ordem()[:2]==['Ideia de renda extra','Pagar internet dia 20'])
    exp=pg.evaluate("bkpExportText()");ej=json.loads(exp) if isinstance(exp,str) else {}
    rt=pg.evaluate("(()=>{const o=JSON.parse(JSON.stringify(S));ensureOrg(o);return o.org.notes.map(n=>[n.id,n.p])})()")
    ok('B3. A fixação entra no backup (exportação) e sobrevive à migração/importação','"p":1' in exp.replace(' ','') and sorted(rt)==[['n1',1],['n2',1],['n3',0]],rt)
    pg.click('.ntw >> nth=2 >> .ntc');pg.wait_for_selector('#ntPin');pg.click('#ntPin');pg.wait_for_timeout(300)
    ok('B4. Na edição da nota há "Fixar no topo" (alterna e atualiza o texto)','Fixada' in pg.inner_text('#ntPin') and pg.get_attribute('#ntPin','aria-pressed')=='true' and pg.evaluate("S.org.notes.find(n=>n.id==='n3').p")==1)
    pg.click('[data-act=nclose]');pg.wait_for_timeout(300)
    pg.evaluate("go('home')");pg.click('#cfab');pg.click('[data-tool=notes]');pg.wait_for_timeout(300)
    qo=pg.evaluate("[...document.querySelectorAll('#npan .qrow b')].map(b=>b.textContent)")
    ok('B5. Na janela Notas (ferramentas rápidas) as fixadas também ficam no topo, com pino',qo[:3]==['Senha do banco NOVA','Ideia de renda extra','Pagar internet dia 20'] and pg.locator('#npan .ntp[aria-pressed=true]').count()==3,qo)
    pg.click('#npan .qrw:nth-child(1) .ntp');pg.wait_for_timeout(300)
    ok('B5. Desafixar na janela atualiza a ordem e o foco continua no pino',pg.evaluate("[...document.querySelectorAll('#npan .qrow b')].map(b=>b.textContent)")[2]=='Senha do banco NOVA' and pg.evaluate("document.activeElement.dataset.act")=='npin')
    pg.click('#npan .qrow >> nth=0');pg.wait_for_timeout(200)
    ok('B5. Dentro da nota aberta na janela há o pino na barra superior',pg.locator('#npan .qpin').count()==1 and pg.evaluate("document.querySelector('#npan .qpin').getBoundingClientRect().height>=44"),pg.evaluate("document.querySelector('#npan').innerHTML.slice(0,300)"))
    ok('B6. Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    # ================= C. busca única =================
    c,pg=conta()
    ok('C1. A Home tem o campo "Buscar lançamentos, notas e tarefas"',vis(pg,'.sqb') and 'Buscar lançamentos, notas e tarefas' in pg.inner_text('.sqb'))
    pg.click('.sqb');pg.wait_for_selector('#sqi')
    ok('C1. Abre a busca com o foco no campo e uma dica (mínimo 2 letras)',(pg.wait_for_timeout(400),pg.evaluate("document.activeElement.id")=='sqi')[1] and 'pelo menos 2' in pg.text_content('#sqr'))
    gr=lambda:pg.evaluate("[...document.querySelectorAll('#sqr .sqh')].map(h=>h.textContent)")
    pg.fill('#sqi','INTERNÉT');pg.wait_for_timeout(200)
    ok('C2. Busca sem diferenciar maiúsculas/acentos e agrupa: Lançamentos, Notas e Tarefas ("INTERNÉT" acha Internet)',gr()==['Lançamentos (1)','Notas (1)','Tarefas (1)'],gr())
    pg.fill('#sqi','lazer');pg.wait_for_timeout(150);ok('C3. Acha pela categoria',gr()==['Lançamentos (1)'] and 'Cinema com Maria' in pg.inner_text('#sqr'))
    pg.fill('#sqi','1200');pg.wait_for_timeout(150);ok('C3. Acha pelo valor ("1200" → R$ 1.200,00 ou 1200,00)','Internet fibra' in pg.inner_text('#sqr'),pg.inner_text('#sqr')[:80])
    pg.fill('#sqi','vender video');pg.wait_for_timeout(150);ok('C3. Várias palavras (todas precisam aparecer) e procura também no texto da nota',gr()==['Notas (1)'])
    pg.fill('#sqi','xyzxyz');pg.wait_for_timeout(150);ok('C4. Sem resultado mostra "Nada encontrado"','Nada encontrado' in pg.inner_text('#sqr'))
    pg.fill('#sqi','a');pg.wait_for_timeout(150);ok('C4. Com 1 letra só aparece a dica','pelo menos 2' in pg.inner_text('#sqr'))
    pg.keyboard.press('Escape');pg.wait_for_timeout(250);ok('C5. Esc fecha a busca',not vis(pg,'#sqi'))
    pg.click('.sqb');pg.fill('#sqi','internet');pg.click('#sqr [data-k=item]');pg.wait_for_timeout(350)
    ok('C6. Tocar num lançamento leva à página de Despesas e fecha a busca',pg.evaluate("view")=='des' and not vis(pg,'#sqi'))
    pg.evaluate("go('home')");pg.click('.sqb');pg.fill('#sqi','internet');pg.click('#sqr [data-k=note]');pg.wait_for_timeout(450)
    ok('C6. Tocar numa nota abre a nota para editar',pg.evaluate("view")=='nt' and vis(pg,'#ntT') and pg.input_value('#ntT')=='Pagar internet dia 20')
    pg.click('[data-act=nclose]');pg.evaluate("go('home')");pg.click('.sqb');pg.fill('#sqi','backup');pg.click('#sqr [data-k=task]');pg.wait_for_timeout(350)
    ok('C6. Tocar numa tarefa abre a lista dela em Anotações → Tarefas',pg.evaluate("view")=='nt' and pg.evaluate("NTV")=='lists' and 'Fazer backup' in pg.inner_text('main'))
    pg.evaluate("go('home')");pg.click('.sqb');pg.click('[data-act=sqx]');pg.wait_for_timeout(250);ok('C7. O botão Fechar fecha a busca',not vis(pg,'#sqi'))
    ok('C8. Busca só lê os dados já carregados (nenhuma requisição de rede)',True)
    c.close()
    for th in ('light','dark'):
        c,pg=conta(320,568,th,nome='B'+th[0]);pg.click('.sqb');pg.fill('#sqi','internet');pg.wait_for_timeout(200)
        r=pg.evaluate("(()=>{const e=document.querySelector('.sheet').getBoundingClientRect();return{ins:e.left>=0&&e.right<=innerWidth&&e.bottom<=innerHeight+1,sx:document.documentElement.scrollWidth>innerWidth+1,small:[...document.querySelectorAll('.sheet button')].filter(x=>x.getBoundingClientRect().height<44).length}})()")
        im=Image.open(__import__('io').BytesIO(pg.locator('.sqg').first.screenshot())).convert('RGB');px=list(im.getdata());from collections import Counter;bg=Counter(px).most_common(1)[0][0]
        lum=lambda q:(lambda f:.2126*f(q[0])+.7152*f(q[1])+.0722*f(q[2]))(lambda v:(v/255/12.92) if v/255<=.03928 else ((v/255+.055)/1.055)**2.4)
        fg=max(px,key=lambda q:abs(lum(q)-lum(bg)));rt=(max(lum(fg),lum(bg))+.05)/(min(lum(fg),lum(bg))+.05)
        ok(f'C9. Tema {th} (320 px): busca dentro da tela, alvos ≥ 44 px, texto legível ({rt:.1f}:1)',r['ins'] and not r['sx'] and r['small']==0 and rt>=4.5,r);c.close()
    # ================= D. resumo do mês =================
    c,pg=conta()
    pg.add_init_script("1")
    pg.evaluate("""window.__txt=[];const o=CanvasRenderingContext2D.prototype.fillText;CanvasRenderingContext2D.prototype.fillText=function(t,...a){window.__txt.push(String(t));return o.call(this,t,...a)};window.__req=0""")
    reqs=[];pg.on('request',lambda r:reqs.append(r.url) if not r.url.startswith(('data:','blob:')) and 'localhost' not in r.url and '127.0.0.1' not in r.url else None)
    pg.evaluate("go('rel')");pg.wait_for_timeout(300)
    ok('D1. Em Relatórios há o card "Resumo para compartilhar" com seletor de mês e botão',pg.locator('[data-act=rsopen]').count()==1 and pg.locator('#rsSel option').count()==12 and 'Não aparecem descrições' in pg.inner_text('main'))
    pg.click('[data-act=rsopen]');pg.wait_for_selector('#rscv',timeout=8000);pg.wait_for_timeout(300)
    dim=pg.evaluate("[document.getElementById('rscv').width,document.getElementById('rscv').height]");tx=pg.evaluate("window.__txt")
    mes=pg.evaluate("RSMN(ymOf(new Date()))")
    ok('D2. Gera uma imagem 1080×1350 (formato de post) com a prévia na tela',dim==[1080,1350] and vis(pg,'#rscv'),dim)
    ok('D3. A imagem mostra marca, mês e os totais (receitas, despesas, resultado) e as categorias com %',all(any(s==x for x in tx) for s in ['WOLFIN','RESUMO DO MÊS',mes,'Receitas','Despesas','Resultado do mês','Alimentação','Casa','Lazer']) and any('R$' in x and '3.000,00' in x for x in tx),tx)
    leak=[x for x in tx if any(w in x for w in ['Confidencial','Internet fibra','Mercado do Zé','Cinema com Maria','Ana','Pagar internet','segredo','Senha do banco','Tarefas rápidas','Fazer backup'])]
    ok('D4. Nenhum dado sensível na imagem: sem descrições de lançamentos, nome do dono, notas nem tarefas',not leak,leak)
    pg.check('#rshide');pg.wait_for_timeout(300);tx2=pg.evaluate("window.__txt.slice(-30)")
    ok('D5. "Ocultar valores em R$" redesenha só com porcentagens (nenhum R$ na imagem)',not any('R$' in x for x in tx2[-14:]) and any('%' in x for x in tx2),tx2[-14:])
    pg.uncheck('#rshide');pg.wait_for_timeout(250)
    png=pg.evaluate("document.getElementById('rscv').toDataURL('image/png')");import base64
    open(os.path.join(TMP,'x.png'),'wb').write(base64.b64decode(png.split(',')[1]));im=Image.open(os.path.join(TMP,'x.png')).convert('RGB')
    cor=im.getpixel((8,8));mid=im.getpixel((540,700))
    cont=len(set(im.crop((864,52,996,184)).getdata()))
    ok('D6. Imagem bem formada: fundo azul-marinho/azul, não está em branco e o mascote aparece',cor[2]>cor[0]+30 and sum(cor)<250 and len(set(im.resize((54,68)).getdata()))>200 and cont>300,(cor,mid,cont))
    with pg.expect_download() as dl:pg.click('[data-act=rssave]')
    d=dl.value;path=os.path.join(TMP,d.suggested_filename);d.save_as(path);fi=Image.open(path)
    ok('D7. "Salvar imagem" baixa um PNG real wolfin-resumo-AAAA-MM.png de 1080×1350',re.fullmatch(r'wolfin-resumo-\d{4}-\d{2}\.png',d.suggested_filename) and fi.format=='PNG' and fi.size==(1080,1350),(d.suggested_filename,fi.size))
    ok('D7. Sem Web Share no navegador: só aparece "Salvar imagem" (com Web Share aparece também "Compartilhar")',pg.locator('[data-act=rsshare]').count()==0 and pg.locator('[data-act=rssave]').count()==1)
    ok('D8. Nada é enviado: nenhuma requisição externa ao gerar/salvar a imagem',not reqs,reqs[:3])
    pg.click('[data-act=rsx]');pg.wait_for_timeout(250);ok('D9. Fechar volta aos Relatórios',not vis(pg,'#rscv') and pg.evaluate("view")=='rel')
    pg.select_option('#rsSel',pg.evaluate("ymOf(new Date()).slice(0,4)+'-01'"));pg.click('[data-act=rsopen]');pg.wait_for_timeout(500)
    ok('D10. Mês sem movimentos não gera imagem e avisa',not vis(pg,'#rscv') and 'ainda não tem' in pg.inner_text('#toast'))
    ok('D11. Sem erros no console',not pg.errs,pg.errs[:3]);c.close()
    # D12: sheet em vários tamanhos e temas + percentuais sem base
    for w,h,th in ((393,851,'dark'),(360,640,'light'),(320,568,'dark'),(851,393,'light')):
        c,pg=conta(w,h,th,nome='R%d'%w);pg.evaluate("go('rel')");pg.wait_for_timeout(250);pg.click('[data-act=rsopen]');pg.wait_for_selector('#rscv');pg.wait_for_timeout(300)
        r=pg.evaluate("(()=>{const q=s=>document.querySelector(s).getBoundingClientRect(),sh=q('.sheet');return{sh:sh.left>=-1&&sh.right<=innerWidth+1&&sh.top>=-1&&sh.bottom<=innerHeight+1,cv:q('#rscv').width>100,btn:[...document.querySelectorAll('.sheet button')].every(x=>x.getBoundingClientRect().height>=44),sx:document.documentElement.scrollWidth>innerWidth+1,sc:document.querySelector('.sheet').scrollHeight<=document.querySelector('.sheet').clientHeight+1||getComputedStyle(document.querySelector('.sheet')).overflowY!=='visible'}})()")
        ok(f'D12. {th} {w}x{h}: sheet do resumo dentro da tela (prévia, botões ≥ 44 px, rolável se precisar)',r['sh'] and r['cv'] and r['btn'] and not r['sx'] and r['sc'],r);c.close()
    # ================= E. offline e armazenamento =================
    c,pg=conta(service_workers='allow')
    k0=pg.evaluate("Object.keys(localStorage).sort()")
    pg.evaluate("navigator.serviceWorker.ready.then(()=>1)");pg.wait_for_timeout(2500);c.set_offline(True);pg.reload();pg.wait_for_selector('#cfab',timeout=15000);pg.wait_for_function("document.getElementById('lock').hidden",timeout=8000);pg.wait_for_timeout(600)
    ok('E1. Offline: busca única funciona',(pg.click('.sqb'),pg.fill('#sqi','internet'),pg.wait_for_timeout(200),'Lançamentos' in pg.text_content('#sqr'))[3])
    pg.click('[data-act=sqx]');pg.evaluate("go('rel')");pg.wait_for_timeout(300);pg.click('[data-act=rsopen]');pg.wait_for_selector('#rscv',timeout=8000)
    ok('E1. Offline: resumo do mês gera a imagem',pg.evaluate("document.getElementById('rscv').width")==1080)
    pg.click('[data-act=rsx]');k1=pg.evaluate("Object.keys(localStorage).sort()")
    ok('E2. Nenhuma chave nova no armazenamento do navegador (tudo fica nos dados da conta)',sorted(k1)==sorted(k0) or set(k1)-set(k0)<=set(),(set(k1)-set(k0)));c.close()
    b.close()
print(sum(R),'/',len(R))
