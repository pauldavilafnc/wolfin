#!/usr/bin/env python3
"""v7.29: gera o estilo Padrão (novo Wolfin) e o anexa a wolfin-brasil.js (arquivo carregado já na abertura). Uso: gerar_estilo_padrao.py DIR_IMAGENS DIR_SITE"""
import sys,io,base64,json,re
import numpy as np,cv2
from PIL import Image
A=sys.argv[1].rstrip('/')+'/'   # pasta com wolfin.png (corpo inteiro) e wolfin_busto.png
SITE=sys.argv[2].rstrip('/')+'/'  # pasta do site (onde está wolfin-brasil.js)
def load(f):return np.array(Image.open(A+f).convert('RGBA'))
def clean(a):
    al=a[...,3].copy();al[al<26]=0
    n,lab,st,_=cv2.connectedComponentsWithStats((al>0).astype(np.uint8),connectivity=8)
    for i in range(1,n):
        if st[i,4]<60:al[lab==i]=0
    rgb=a[...,:3].copy();core=cv2.erode((al>=250).astype(np.uint8),np.ones((5,5),np.uint8))
    bad=((al>0)&(core==0)).astype(np.uint8)*255
    if bad.any():rgb=cv2.inpaint(rgb,bad,3,cv2.INPAINT_TELEA)
    al=cv2.GaussianBlur(al,(0,0),0.6);al=np.where(al<40,0,al).astype(np.uint8)
    return np.dstack([rgb,al])
def bbox(a):
    ys,xs=np.where(a[...,3]>10);return xs.min(),ys.min(),xs.max()+1,ys.max()+1
def rsp(a,W,H):
    f=a.astype(np.float32);f[...,:3]*=f[...,3:]/255;f=cv2.resize(f,(W,H),interpolation=cv2.INTER_AREA)
    al=f[...,3:];f[...,:3]=np.where(al>0,f[...,:3]*255/np.maximum(al,1),0);return np.clip(f,0,255).astype(np.uint8)
def enc(a,q=80,aq=88):
    bio=io.BytesIO();Image.fromarray(a,'RGBA').save(bio,'WEBP',quality=q,alpha_quality=aq,method=6);return 'data:image/webp;base64,'+base64.b64encode(bio.getvalue()).decode(),len(bio.getvalue())
n=clean(load('wolfin.png'));x0,y0,x1,y1=bbox(n);n=n[y0:y1,x0:x1];h,w=n.shape[:2];W=340;H=round(h*W/w)
b=clean(load('wolfin_busto.png'));x0,y0,x1,y1=bbox(b);b=b[y0:y1,x0:x1];bh,bw=b.shape[:2];BW=240;BH=round(bh*BW/bw)
e={'w':W,'h':H,'bw':BW,'bh':BH};e['n'],s1=enc(rsp(n,W,H));e['b'],s2=enc(rsp(b,BW,BH),q=82)
print(e['w'],e['h'],e['bw'],e['bh'],s1,s2)
p=SITE+'wolfin-brasil.js';t=open(p,encoding='utf-8').read()
t=re.sub(r'\n?/\* estilo-padrao \*/.*?\n','\n',t,flags=re.S) if '/* estilo-padrao */' in t else t
t=t.rstrip('\n')+'\n/* estilo-padrao */window.WOLFIMG.sty=window.WOLFIMG.sty||{};window.WOLFIMG.sty.padrao='+json.dumps(e,separators=(',',':'))+';\n'
open(p,'w',encoding='utf-8').write(t);print(len(t))
