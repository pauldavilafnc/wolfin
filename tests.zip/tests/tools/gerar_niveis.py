#!/usr/bin/env python3
"""v7.30: gera wolfin-niveis.js com os 4 mascotes dos níveis da "Minha situação financeira" (crítica, atenção, estável, saudável).
Uso: gerar_niveis.py critico.png atencao.png estavel.png saudavel.png SAIDA.js   (PNGs com fundo transparente; só recorte pela borda, limpeza do 'fiapo' de alfa e WebP)."""
import sys,io,base64,json
import numpy as np,cv2
from PIL import Image
A=sys.argv[1:5];OUT=sys.argv[5];K=['crt','atn','est','ok'];W=300
def clean(a):
    al=a[...,3].copy();al[al<26]=0
    n,lab,st,_=cv2.connectedComponentsWithStats((al>0).astype(np.uint8),connectivity=8)
    for i in range(1,n):
        if st[i,4]<60:al[lab==i]=0
    rgb=a[...,:3].copy();core=cv2.erode((al>=250).astype(np.uint8),np.ones((5,5),np.uint8))
    bad=((al>0)&(core==0)).astype(np.uint8)*255
    if bad.any():rgb=cv2.inpaint(rgb,bad,3,cv2.INPAINT_TELEA)
    al=cv2.GaussianBlur(al,(0,0),0.6);al=np.where(al<40,0,al).astype(np.uint8)
    return np.dstack([rgb,al])
def rsp(a,w,h):
    f=a.astype(np.float32);f[...,:3]*=f[...,3:]/255;f=cv2.resize(f,(w,h),interpolation=cv2.INTER_AREA)
    al=f[...,3:];f[...,:3]=np.where(al>0,f[...,:3]*255/np.maximum(al,1),0);return np.clip(f,0,255).astype(np.uint8)
res={};tot=0
for k,p in zip(K,A):
    a=clean(np.array(Image.open(p).convert('RGBA')));ys,xs=np.where(a[...,3]>10);a=a[ys.min():ys.max()+1,xs.min():xs.max()+1]
    h,w=a.shape[:2];H=round(h*W/w);bio=io.BytesIO();Image.fromarray(rsp(a,W,H),'RGBA').save(bio,'WEBP',quality=82,alpha_quality=90,method=6)
    res[k]={'w':W,'h':H,'s':'data:image/webp;base64,'+base64.b64encode(bio.getvalue()).decode()};tot+=len(bio.getvalue());print(k,W,H,len(bio.getvalue()))
open(OUT,'w',encoding='utf-8').write('/* Wolfin · mascotes dos níveis da situação financeira (gerado por tests/tools/gerar_niveis.py) */\nwindow.WOLFIMG=window.WOLFIMG||{};window.WOLFIMG.niv='+json.dumps(res,separators=(',',':'))+';\n')
print('KB',tot//1024)
