#!/usr/bin/env python3
"""Gera wolfin-estilos.js (+ par do Brasil anexado a wolfin-brasil.js) a partir das imagens
corpo inteiro (normal) e busto de cada estilo (v7.28: sem versão vendada; Árabe: busto recortado do corpo inteiro). Uso: gerar_wolfin_estilos.py DIR_IMAGENS SAIDA_DIR
Mapa: nome -> (normal, vendado, busto) = arquivos <hash>-image.png em DIR_IMAGENS."""
import sys,io,base64,json,re,os
import numpy as np,cv2
from PIL import Image
D=sys.argv[1];OUT=sys.argv[2]
M={'shelby':('0115a9f0','fb9b9d1b','936dedcc'),'cafetao':('7465b283','2124e729','5a4c0461'),'tommy':('c84d8fae','8d6ae91e','04e97990'),
'meme':('dedadfb8','11d3bf56','82ed7395'),'kratos':('7ae2528e','fba5c5c5','0d18b858'),'morgan':('dc8b6d43','e33c85a8','862a19c9'),
'brasil':('770fa19f','723bc31c','f0d0c5c2'),'cj':('ca2c57d2','c061ae24','b40fddf9'),'tyler':('1bff182a','cf1701f7','594ad404'),
'heisenberg':('ac33122c','65d31126','8c896f45'),'arabe':('0fd01188',None,None)}
BW=340;BUW=240
def load(h):return np.array(Image.open(f'{D}/{h}-image.png').convert('RGBA'))
def clean(a):
    """tira o 'fiapo' de alfa baixo e descontamina a cor das bordas (magenta/amarelo)"""
    al=a[...,3].copy()
    al[al<26]=0
    # remove ilhas minúsculas
    n,lab,st,_=cv2.connectedComponentsWithStats((al>0).astype(np.uint8),connectivity=8)
    for i in range(1,n):
        if st[i,4]<60:al[lab==i]=0
    rgb=a[...,:3].copy()
    core=(al>=250).astype(np.uint8)
    core=cv2.erode(core,np.ones((5,5),np.uint8))
    bad=((al>0)&(core==0)).astype(np.uint8)*255
    if bad.any():
        # preenche cor da borda a partir do interior sólido
        rgb=cv2.inpaint(np.dstack([rgb]),bad,3,cv2.INPAINT_TELEA)
    # encolhe levemente o alfa da borda para sumir com halo
    al=cv2.GaussianBlur(al,(0,0),0.6)
    al=np.where(al<40,0,al).astype(np.uint8)
    return np.dstack([rgb,al])
def bbox(a):
    ys,xs=np.where(a[...,3]>10);return xs.min(),ys.min(),xs.max()+1,ys.max()+1
def enc(a,q=80,aq=88):
    im=Image.fromarray(a,'RGBA');bio=io.BytesIO();im.save(bio,'WEBP',quality=q,alpha_quality=aq,method=6)
    return 'data:image/webp;base64,'+base64.b64encode(bio.getvalue()).decode(),len(bio.getvalue())
def align(n,v):
    """encaixa o vendado no canvas do normal e alinha pelos pés/pernas (metade de baixo)"""
    if v.shape[:2]!=n.shape[:2]:v=cv2.resize(v,(n.shape[1],n.shape[0]),interpolation=cv2.INTER_AREA)
    h=n.shape[0];s=slice(int(h*.55),h)
    g1=n[s,:,3].astype(np.float32)/255;g2=v[s,:,3].astype(np.float32)/255
    win=cv2.createHanningWindow((g1.shape[1],g1.shape[0]),cv2.CV_32F)
    (dx,dy),_=cv2.phaseCorrelate(g1,g2,win)
    if abs(dx)>40 or abs(dy)>40:dx=dy=0
    Mx=np.float32([[1,0,-dx],[0,1,-dy]])
    v=cv2.warpAffine(v,Mx,(v.shape[1],v.shape[0]),flags=cv2.INTER_LINEAR,borderValue=(0,0,0,0))
    return v,(dx,dy)
res={};tot=0
for k,(hn,hv,hb) in M.items():
    n=clean(load(hn));e={}
    x0,y0,x1,y1=bbox(n);nfull=n.copy();n=n[y0:y1,x0:x1]
    h,w=n.shape[:2];W=BW;H=round(h*W/w)
    def rsp(a,W,H):
        f=a.astype(np.float32);f[...,:3]*=f[...,3:]/255;f=cv2.resize(f,(W,H),interpolation=cv2.INTER_AREA)
        al=f[...,3:];f[...,:3]=np.where(al>0,f[...,:3]*255/np.maximum(al,1),0);return np.clip(f,0,255).astype(np.uint8)
    e['w']=W;e['h']=H
    e['n'],s=enc(rsp(n,W,H));tot+=s
    if hb:b=clean(load(hb))
    else:  # Árabe: sem busto enviado -> recorte (cabeça, ombros e tronco) do próprio corpo inteiro
        b=nfull[0:690,190:790].copy()
    x0,y0,x1,y1=bbox(b);b=b[y0:y1,x0:x1];bh,bw=b.shape[:2];BH=round(bh*BUW/bw)
    e['b'],s=enc(rsp(b,BUW,BH),q=82);tot+=s;e['bw']=BUW;e['bh']=BH
    res[k]=e;print(k,e['w'],e['h'],e['bw'],e['bh'],flush=True)
os.makedirs(OUT,exist_ok=True)
br=res.pop('brasil')
p=f'{OUT}/wolfin-brasil.js';t=open(p).read()
t=re.sub(r'\n?/\* estilo-brasil \*/.*','',t,flags=re.S)
t=t.rstrip('\n')+'\n/* estilo-brasil */window.WOLFIMG.sty=window.WOLFIMG.sty||{};window.WOLFIMG.sty.brasil='+json.dumps(br,separators=(',',':'))+';\n'
open(p,'w').write(t)
open(f'{OUT}/wolfin-estilos.js','w').write('/* Wolfin · estilos (gerado por tests/tools/gerar_wolfin_estilos.py) */\nwindow.WOLFIMG=window.WOLFIMG||{};window.WOLFIMG.sty=window.WOLFIMG.sty||{};Object.assign(window.WOLFIMG.sty,'+json.dumps(res,separators=(',',':'))+');\n')
print('total KB',tot//1024)
