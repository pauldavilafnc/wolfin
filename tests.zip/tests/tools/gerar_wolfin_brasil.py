"""Gera wolfin-brasil.js (camadas do mascote Wolfin · visual Brasil) a partir das imagens PNG com fundo transparente.
Uso: python3 tests/tools/gerar_wolfin_brasil.py <pasta_com_pngs> <saida.js> [moeda.png]
Etapas: limpa neblina do alfa → alinha o rosto de cada variação à base (sub-pixel) → recorta "olhos/sobrancelhas" e "boca" →
abre um furo (com borda suave) nos corpos nessas regiões → separa a cauda → reduz p/ 60% → WebP leve → data-URIs em um .js.
Só usa as imagens que a pessoa forneceu; nada é inventado."""
import sys,io,json,base64,os
import numpy as np,cv2
from PIL import Image
SRC=sys.argv[1];OUT=sys.argv[2]
IDS={'base':'e70dda64','acolhedor':'a126d051','apontando':'77e0571c','boca_aberta':'f0087847','boca_meia':'55fc1c16','comemorando':'c0b6474b','mao_dir':'ca369fdf','mao_esq':'bd2cba4d','olhar_esq':'775953dc','olhar_dir':'ae3c896b','olhos_fechados':'39ebea38','olhos_felizes':'04c43385','olhos_meio':'1037369d','piscando':'6b6ce266','preocupado':'e689d2c2','sem_calda':'6b30699a','sobr_baixa':'e6aac635','sobr_erguida':'272ae21a','sorriso_largo':'f152bdb0','surpreso':'fd922f89'}
W,H=1024,1536
def load(k):
    im=Image.open(os.path.join(SRC,IDS[k]+'-image.png')).convert('RGBA')
    if im.size!=(W,H):im=im.resize((W,H),Image.LANCZOS)
    a=np.array(im).astype(np.float32)/255.
    al=np.clip((a[...,3]-0.30)/0.45,0,1)            # remove a neblina (alfa baixo) mantendo a borda macia da pelagem
    a[...,3]=al;a[...,:3]*=al[...,None]            # pré-multiplicado
    return a
def gray(a):
    return cv2.cvtColor((np.clip(a[...,:3]+0.5*(1-a[...,3:4]),0,1)*255).astype(np.uint8),cv2.COLOR_RGB2GRAY).astype(np.float32)
CAP=(0,130,330,700)
def align(a,gb):
    y0,y1,x0,x1=CAP;dx,dy=cv2.phaseCorrelate(gb[y0:y1,x0:x1],gray(a)[y0:y1,x0:x1])[0]
    M=np.float32([[1,0,-dx],[0,1,-dy]]);return cv2.warpAffine(a,M,(W,H),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=0),(dx,dy)
img={k:load(k) for k in IDS}
gb=gray(img['base']);shift={}
for k in img:
    if k not in('base',):img[k],shift[k]=align(img[k],gb)
print('deslocamentos corrigidos (px):',{k:tuple(round(float(x),2) for x in v) for k,v in shift.items()})
# regiões do rosto (coordenadas 1024x1536)
RE=(456,92,642,190);RM=(468,182,650,282);FE=9
def fmask(r):
    x0,y0,x1,y1=r;m=np.zeros((H,W),np.float32);m[y0:y1,x0:x1]=1
    return cv2.GaussianBlur(cv2.erode(m,np.ones((2*FE,2*FE),np.uint8)),(0,0),FE/2.2)
fe,fm=fmask(RE),fmask(RM);hole=1-np.maximum(fe,fm)
def holed(a):return a*hole[...,None]
# cauda: pixels da base que a imagem "sem cauda" não tem
b=img['base'];sc=img['sem_calda']
reg=np.zeros((H,W),bool);reg[690:1260,150:450]=True
tm=(reg&(b[...,3]>0.05)&(sc[...,3]<0.5)).astype(np.uint8)
tm=cv2.morphologyEx(tm,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
tm=cv2.morphologyEx(tm,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
tail_keep=cv2.dilate(tm,np.ones((21,21),np.uint8))*reg      # inclui um pouco "por baixo" do corpo, p/ não abrir fresta ao balançar
tail=b*tail_keep[...,None].astype(np.float32)
body_base=b*(1-tm[...,None].astype(np.float32))  # corpo sem a cauda
bodies={'base':body_base,'acolhedor':img['acolhedor'],'apontando':img['apontando'],'comemorando':img['comemorando'],'mao_dir':img['mao_dir'],'mao_esq':img['mao_esq']}
# caixa comum
bb=None
for a in list(bodies.values())+[tail]:
    ys,xs=np.where(a[...,3]>0.05);r=(int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max()));bb=r if bb is None else (min(bb[0],r[0]),min(bb[1],r[1]),max(bb[2],r[2]),max(bb[3],r[3]))
PAD=6;X0,Y0,X1,Y1=max(0,bb[0]-PAD),max(0,bb[1]-PAD),min(W,bb[2]+PAD),min(H,bb[3]+PAD)
SC=float(os.environ.get('WOLF_ESCALA','0.6'))
CW,CH=round((X1-X0)*SC),round((Y1-Y0)*SC)
print('caixa',X0,Y0,X1,Y1,'->',CW,'x',CH)
def small(a,box=None):
    if box:x0,y0,x1,y1=box;a=a[y0:y1,x0:x1]
    h,w=a.shape[:2];return cv2.resize(a,(max(1,round(w*SC)),max(1,round(h*SC))),interpolation=cv2.INTER_AREA)
def enc(a,q=82,alpha_q=90):
    al=a[...,3:4];rgb=np.where(al>1e-4,a[...,:3]/np.maximum(al,1e-4),0)
    out=np.concatenate([np.clip(rgb,0,1),al],2);im=Image.fromarray((out*255+0.5).astype(np.uint8),'RGBA')
    bio=io.BytesIO();im.save(bio,'WEBP',quality=q,alpha_quality=alpha_q,method=6)
    return 'data:image/webp;base64,'+base64.b64encode(bio.getvalue()).decode(),len(bio.getvalue())
res={'w':CW,'h':CH};tot=0
def put(d,k,a,**kw):
    global tot
    s,n=enc(a,**kw);d[k]=s;tot+=n;return n
res['body']={};res['tail']=None
for k,a in bodies.items():put(res['body'],k,small(holed(a),(X0,Y0,X1,Y1)),q=80)
put(res,'tail_',small(tail,(X0,Y0,X1,Y1)),q=80);res['tail']=res.pop('tail_')
# pivô da cauda (em % do quadro)
res['pivot']=[round((410-X0)/(X1-X0)*100,2),round((770-Y0)/(Y1-Y0)*100,2)]
def rect_pct(r):x0,y0,x1,y1=r;return [round((x0-X0)/(X1-X0)*100,3),round((y0-Y0)/(Y1-Y0)*100,3),round((x1-x0)/(X1-X0)*100,3),round((y1-y0)/(Y1-Y0)*100,3)]
res['E']={};res['M']={};res['rE']=rect_pct(RE);res['rM']=rect_pct(RM)
def patch(a,r,f):
    x0,y0,x1,y1=r;p=a*f[...,None];return small(p,(x0,y0,x1,y1))
EP={'base':'base','meio':'olhos_meio','fechado':'olhos_fechados','feliz':'olhos_felizes','pisca':'piscando','esq':'olhar_esq','dir':'olhar_dir','baixa':'sobr_baixa','erguida':'sobr_erguida','preocup':'preocupado','surpreso':'surpreso','serio':'apontando','acolhe':'acolhedor','festa':'comemorando','mdir':'mao_dir','mesq':'mao_esq'}
MP={'base':'base','meia':'boca_meia','aberta':'boca_aberta','largo':'sorriso_largo','grin':'comemorando','surpreso':'surpreso','preocup':'preocupado','serio':'apontando','acolhe':'acolhedor','mdir':'mao_dir','mesq':'mao_esq'}
for k,src in EP.items():put(res['E'],k,patch(img[src],RE,fe),q=85)
for k,src in MP.items():put(res['M'],k,patch(img[src],RM,fm),q=85)
coin=None
if len(sys.argv)>3:      # moeda WolfCoin (PNG com fundo escuro): recorta pela elipse da moeda
    a=np.array(Image.open(sys.argv[3]).convert('RGBA')).astype(np.float32);rgb=a[...,:3]
    lum=rgb.max(2);m=((lum>105)&(a[...,3]>120)).astype(np.uint8);m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((9,9),np.uint8))
    n,lab,st,_=cv2.connectedComponentsWithStats(m);m=(lab==1+np.argmax(st[1:,4])).astype(np.uint8)
    (cx,cy),(ax,ay),ang=cv2.fitEllipse(max(cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)[0],key=cv2.contourArea))
    mk=np.zeros(m.shape,np.uint8);cv2.ellipse(mk,((cx,cy),(ax*0.992,ay*0.992),ang),1,-1)
    al=cv2.GaussianBlur(mk.astype(np.float32),(0,0),1.4);ys,xs=np.where(mk>0);x0,x1,y0,y1=xs.min()-3,xs.max()+4,ys.min()-3,ys.max()+4
    ci=Image.fromarray((np.dstack([rgb/255.,al])[y0:y1,x0:x1]*255).astype(np.uint8),'RGBA');ci=ci.resize((256,round(256*ci.size[1]/ci.size[0])),Image.LANCZOS)
    bio=io.BytesIO();ci.save(bio,'WEBP',quality=86,alpha_quality=95,method=6);coin='data:image/webp;base64,'+base64.b64encode(bio.getvalue()).decode();tot+=len(bio.getvalue())
open(OUT,'w',encoding='utf-8').write('/* Wolfin · visual Brasil (camadas geradas por tests/tools/gerar_wolfin_brasil.py) */\nwindow.WOLFIMG=window.WOLFIMG||{};window.WOLFIMG.brasil='+json.dumps(res,separators=(',',':'))+';\n'+("window.WOLFIMG.coin='"+coin+"';\n" if coin else ''))
print('total imagens ≈ %.0f KB; arquivo %.0f KB'%(tot/1024,os.path.getsize(OUT)/1024))
